"""Gap-link supervision (Section 3.6).

The link loss applies the Bayes-risk evidential loss (Eq. 5) with
positive-class weighting, averaged over *every* candidate gap edge (no
thresholding or discarding at training time -- Eq. (11)'s hard decision is
an inference-only rule).

A candidate ``(i, j)`` is labelled positive when both nodes project onto
the ground-truth skeleton within 2 px and the geodesic distance between
the projections is at most 1.5 times their Euclidean distance; projections
on different ground-truth components -- or either node failing to project
within 2 px -- are negative.
"""

from __future__ import annotations

from typing import Tuple

import numpy as np
import torch
from scipy.ndimage import label as cc_label
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra

from evitopo_gnn.losses.evidential_loss import evidential_bayes_risk_loss, to_one_hot_binary


def _build_skeleton_graph(skeleton: np.ndarray):
    """8-connected sparse adjacency over skeleton pixels, Euclidean-weighted,
    plus a lookup from (y, x) to graph-node index."""
    ys, xs = np.nonzero(skeleton)
    index_of = {(int(y), int(x)): i for i, (y, x) in enumerate(zip(ys, xs))}
    rows, cols, weights = [], [], []
    h, w = skeleton.shape
    for y, x in zip(ys, xs):
        i = index_of[(y, x)]
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and skeleton[ny, nx]:
                    j = index_of[(ny, nx)]
                    rows.append(i)
                    cols.append(j)
                    weights.append((dy ** 2 + dx ** 2) ** 0.5)
    n = len(ys)
    adj = coo_matrix((weights, (rows, cols)), shape=(n, n)).tocsr()
    return adj, index_of, np.stack([ys, xs], axis=1) if n else np.zeros((0, 2))


def _nearest_skeleton_pixel(point: np.ndarray, skel_coords: np.ndarray, max_dist: float):
    if skel_coords.shape[0] == 0:
        return None, None
    d = np.linalg.norm(skel_coords - point[None, :], axis=1)
    k = int(np.argmin(d))
    if d[k] > max_dist:
        return None, None
    return k, d[k]


def make_synthetic_gap_candidate_labels(
    node_pos: torch.Tensor,            # [N, 2]
    gap_edge_index: torch.Tensor,      # [2, E]
    gt_skeleton: np.ndarray,           # [H, W] bool, ground-truth (undegraded) skeleton
    max_proj_dist: float = 2.0,
    geodesic_ratio: float = 1.5,
) -> torch.Tensor:
    """Returns a ``[E]`` float tensor of {0, 1} labels for each candidate
    gap edge, following the positive-candidate rule of Section 3.6."""
    e = gap_edge_index.shape[1]
    if e == 0:
        return torch.zeros(0)

    components, _ = cc_label(gt_skeleton, structure=np.ones((3, 3)))
    adj, index_of, skel_coords = _build_skeleton_graph(gt_skeleton)

    pos = node_pos.detach().cpu().numpy()
    labels = np.zeros(e, dtype=np.float32)

    # Cache per-node projection (pixel index into skel_coords, component id)
    proj_cache = {}

    def project(node_idx: int):
        if node_idx in proj_cache:
            return proj_cache[node_idx]
        k, dist = _nearest_skeleton_pixel(pos[node_idx], skel_coords, max_proj_dist)
        if k is None:
            proj_cache[node_idx] = None
            return None
        y, x = skel_coords[k]
        comp = int(components[y, x])
        result = (k, comp)
        proj_cache[node_idx] = result
        return result

    # Group candidates by source component to batch Dijkstra calls.
    for e_idx in range(e):
        i = int(gap_edge_index[0, e_idx])
        j = int(gap_edge_index[1, e_idx])
        proj_i = project(i)
        proj_j = project(j)
        if proj_i is None or proj_j is None:
            continue
        k_i, comp_i = proj_i
        k_j, comp_j = proj_j
        if comp_i != comp_j or comp_i == 0:
            continue
        dist_matrix = dijkstra(adj, directed=False, indices=[k_i], unweighted=False)
        geodesic = dist_matrix[0, k_j]
        if not np.isfinite(geodesic):
            continue
        euclidean = float(np.linalg.norm(pos[i] - pos[j])) + 1e-6
        if geodesic <= geodesic_ratio * euclidean:
            labels[e_idx] = 1.0

    return torch.as_tensor(labels)


def link_supervision_loss(
    alpha_lnk: torch.Tensor,   # [E, 2]
    labels: torch.Tensor,      # [E] in {0, 1}
    lambda_kl: float,
    positive_weight: float = 5.0,
) -> torch.Tensor:
    """Eq. (5) applied to the per-candidate link evidence, with positive-
    class weighting to counter the heavy class imbalance (most candidates
    are not true gaps)."""
    if alpha_lnk.shape[0] == 0:
        return alpha_lnk.sum() * 0.0
    target_onehot = to_one_hot_binary(labels.view(-1, 1).to(alpha_lnk.dtype), class_dim=1)
    class_weight = torch.tensor([1.0, positive_weight], device=alpha_lnk.device, dtype=alpha_lnk.dtype)
    return evidential_bayes_risk_loss(alpha_lnk, target_onehot, lambda_kl, class_dim=1, class_weight=class_weight)
