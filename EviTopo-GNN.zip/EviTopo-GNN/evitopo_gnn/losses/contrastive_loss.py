"""Topology-aware, uncertainty-guided contrastive loss (Section 3.8, Eq. 13-14).

A projection head on the decoder features produces L2-normalised
embeddings ``z``. The ground-truth skeleton is split into branches at
junctions and endpoints, and each vessel pixel is assigned to its nearest
branch. Per image, ``num_anchors`` anchors ``A`` are drawn from vessel
pixels and a 3 px background ring with probability that favours uncertain
pixels (Eq. 13):

    Pr(a) ~ (sg(U_c(a)) + xi) ^ eta

where the sampling weight ramps from zero (uniform) to one
(uncertainty-weighted) over epochs 101-150, a curriculum from easy to hard
pixels. For a vessel anchor the positives are pixels on the same
ground-truth branch within a geodesic distance ``r_p`` along the skeleton;
the negatives are background pixels 1-3 px from the vessel edge, vessel
pixels within 10 px on a different branch, high-gradient non-vessel pixels
(lesion edges) and a queue of background embeddings. The loss (Eq. 14),
with the detached anchor weight ``w_a = 1 + sg(U_c(a))``:

    L_con = -(1/|A|) sum_a w_a / |Z+_a| sum_{p in Z+_a} log(
                exp(z_a . z_p / kappa) / sum_{q in Z_a} exp(z_a . z_q / kappa) )

Two queues of ``queue_size`` detached embeddings and two prototypes updated
by exponential moving average supply stable negatives.

Implementation notes (stated simplifications, not part of the paper's
equations): branch decomposition reuses the same inter-junction walk as
the inference-time graph builder (``models/graph_builder.py``), applied to
the *ground-truth* skeleton; every ground-truth vessel pixel is then
assigned to its nearest skeleton branch and given an arc-length coordinate
along it via a Euclidean nearest-neighbour projection
(``scipy.ndimage.distance_transform_edt`` with indices), and "same branch
within geodesic distance ``r_p``" is approximated as "same branch id and
arc-length difference <= ``r_p``". High-gradient non-vessel pixels are
approximated from the Sobel gradient magnitude of the input probability
map, thresholded at its 90th percentile outside the vessel mask.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import distance_transform_edt, sobel

from evitopo_gnn.models.graph_builder import _walk_branches
from evitopo_gnn.models.skeleton import hard_skeletonize_and_prune, skeleton_degree_map


def contrastive_ramp(epoch: int, start: int = 101, end: int = 150) -> float:
    if epoch <= start:
        return 0.0
    if epoch >= end:
        return 1.0
    return (epoch - start) / float(end - start)


def _decompose_gt_branches(gt_mask: np.ndarray, min_spur_len: int = 0):
    """Branch id and arc-length position for every *skeleton* pixel of the
    ground-truth mask."""
    skeleton = hard_skeletonize_and_prune(gt_mask.astype(np.float32), threshold=0.5, min_spur_len=min_spur_len)
    degree = skeleton_degree_map(skeleton)
    branches = _walk_branches(skeleton, degree)

    branch_id_map = -np.ones(gt_mask.shape, dtype=np.int32)
    arc_pos_map = np.zeros(gt_mask.shape, dtype=np.float32)
    for bid, branch in enumerate(branches):
        cum = 0.0
        prev = None
        for (y, x) in branch:
            if prev is not None:
                cum += float(np.hypot(y - prev[0], x - prev[1]))
            branch_id_map[y, x] = bid
            arc_pos_map[y, x] = cum
            prev = (y, x)
    return skeleton, branch_id_map, arc_pos_map


def _assign_pixels_to_branches(vessel_mask: np.ndarray, skeleton: np.ndarray, branch_id_map: np.ndarray, arc_pos_map: np.ndarray):
    """Nearest-skeleton-pixel projection extends the skeleton's branch id /
    arc-length to every foreground pixel of ``vessel_mask``."""
    if not skeleton.any():
        return -np.ones_like(branch_id_map), np.zeros_like(arc_pos_map)
    _, (iy, ix) = distance_transform_edt(~skeleton, return_indices=True)
    full_branch = branch_id_map[iy, ix]
    full_arc = arc_pos_map[iy, ix]
    full_branch = np.where(vessel_mask, full_branch, -1)
    full_arc = np.where(vessel_mask, full_arc, 0.0)
    return full_branch, full_arc


class _EmbeddingQueue(nn.Module):
    """Fixed-size FIFO queue of detached embeddings plus an EMA prototype."""

    def __init__(self, size: int, dim: int, momentum: float = 0.99):
        super().__init__()
        self.register_buffer("queue", F.normalize(torch.randn(size, dim), dim=-1))
        self.register_buffer("ptr", torch.zeros(1, dtype=torch.long))
        self.register_buffer("prototype", F.normalize(torch.randn(dim), dim=-1))
        self.momentum = momentum
        self.size = size

    @torch.no_grad()
    def enqueue(self, embeddings: torch.Tensor) -> None:
        if embeddings.shape[0] == 0:
            return
        embeddings = embeddings.detach()
        n = embeddings.shape[0]
        ptr = int(self.ptr.item())
        if n >= self.size:
            self.queue.copy_(embeddings[-self.size :])
            ptr = 0
        else:
            idx = (torch.arange(n, device=self.queue.device) + ptr) % self.size
            self.queue[idx] = embeddings
            ptr = (ptr + n) % self.size
        self.ptr[0] = ptr
        new_proto = F.normalize(embeddings.mean(dim=0), dim=-1)
        self.prototype.mul_(self.momentum).add_(new_proto * (1 - self.momentum))
        self.prototype.copy_(F.normalize(self.prototype, dim=-1))


@dataclass
class ContrastiveConfig:
    num_anchors: int = 512
    geodesic_radius: float = 32.0
    temperature: float = 0.1
    xi: float = 0.05
    eta: float = 1.0
    queue_size: int = 4096
    edge_band_px: int = 3
    diff_branch_px: int = 10
    max_positives: int = 32
    max_negatives: int = 64


class TopologyAwareContrastiveLoss(nn.Module):
    def __init__(self, proj_dim: int = 128, cfg: ContrastiveConfig | None = None):
        super().__init__()
        self.cfg = cfg or ContrastiveConfig()
        self.bg_queue = _EmbeddingQueue(self.cfg.queue_size, proj_dim)
        self.cross_queue = _EmbeddingQueue(self.cfg.queue_size, proj_dim)

    def forward(
        self,
        z_map: torch.Tensor,           # [1, D, H, W] L2-normalised embeddings
        prob_map: torch.Tensor,        # [1, 1, H, W] predicted probability (for gradient proxy)
        uncertainty_map: torch.Tensor, # [1, 1, H, W]
        gt_mask: np.ndarray,           # [H, W] bool ground-truth vessel mask
        epoch: int,
    ) -> torch.Tensor:
        device = z_map.device
        _, d, h, w = z_map.shape
        skeleton, branch_id_map, arc_pos_map = _decompose_gt_branches(gt_mask)
        full_branch, full_arc = _assign_pixels_to_branches(gt_mask, skeleton, branch_id_map, arc_pos_map)

        dist_to_vessel = distance_transform_edt(~gt_mask)
        bg_ring = (dist_to_vessel > 0) & (dist_to_vessel <= self.cfg.edge_band_px)

        prob_np = prob_map.detach().cpu().numpy().squeeze()
        grad_mag = np.hypot(sobel(prob_np, axis=0), sobel(prob_np, axis=1))
        non_vessel = ~gt_mask
        if non_vessel.any() and grad_mag[non_vessel].size:
            thresh = np.percentile(grad_mag[non_vessel], 90)
        else:
            thresh = np.inf
        lesion_edge = non_vessel & (grad_mag >= thresh)

        unc_np = uncertainty_map.detach().cpu().numpy().squeeze()

        candidate_mask = gt_mask | bg_ring
        ys, xs = np.nonzero(candidate_mask)
        if len(ys) == 0:
            return z_map.sum() * 0.0

        ramp = contrastive_ramp(epoch)
        unc_vals = unc_np[ys, xs]
        weighted_p = (unc_vals + self.cfg.xi) ** self.cfg.eta
        weighted_p = weighted_p / weighted_p.sum()
        uniform_p = np.full_like(weighted_p, 1.0 / len(weighted_p))
        sample_p = (1 - ramp) * uniform_p + ramp * weighted_p
        sample_p = sample_p / sample_p.sum()

        n_anchor = min(self.cfg.num_anchors, len(ys))
        rng = np.random.default_rng()
        chosen = rng.choice(len(ys), size=n_anchor, replace=False, p=sample_p)

        total_loss = 0.0
        valid_anchors = 0
        new_bg_negs, new_cross_negs = [], []

        z_flat = z_map[0].permute(1, 2, 0)  # [H, W, D]

        for idx in chosen:
            ay, ax = int(ys[idx]), int(xs[idx])
            z_a = z_flat[ay, ax]
            u_a = float(unc_np[ay, ax])
            w_a = 1.0 + u_a  # detached scalar weight

            if gt_mask[ay, ax]:
                bid = full_branch[ay, ax]
                if bid < 0:
                    continue
                same_branch = full_branch == bid
                arc_diff = np.abs(full_arc - full_arc[ay, ax])
                pos_mask = same_branch & (arc_diff <= self.cfg.geodesic_radius)
                pos_mask[ay, ax] = False
                py, px = np.nonzero(pos_mask)
                if len(py) == 0:
                    continue
                if len(py) > self.cfg.max_positives:
                    sel = rng.choice(len(py), size=self.cfg.max_positives, replace=False)
                    py, px = py[sel], px[sel]

                diff_branch_vessel = gt_mask & (full_branch != bid) & (full_branch >= 0)
                # restrict to within diff_branch_px of the anchor for locality
                local = np.zeros_like(gt_mask)
                y0, y1 = max(0, ay - self.cfg.diff_branch_px), min(h, ay + self.cfg.diff_branch_px + 1)
                x0, x1 = max(0, ax - self.cfg.diff_branch_px), min(w, ax + self.cfg.diff_branch_px + 1)
                local[y0:y1, x0:x1] = True
                neg_mask = (diff_branch_vessel | bg_ring | lesion_edge) & local
                ny, nx = np.nonzero(neg_mask)
            else:
                # background-ring anchor: positives are other nearby ring pixels (same local patch)
                local_half = 8
                y0, y1 = max(0, ay - local_half), min(h, ay + local_half)
                x0, x1 = max(0, ax - local_half), min(w, ax + local_half)
                local_pos = np.zeros_like(bg_ring)
                local_pos[y0:y1, x0:x1] = True
                pos_mask = bg_ring & local_pos
                pos_mask[ay, ax] = False
                py, px = np.nonzero(pos_mask)
                if len(py) > self.cfg.max_positives:
                    sel = rng.choice(len(py), size=self.cfg.max_positives, replace=False)
                    py, px = py[sel], px[sel]
                neg_mask = gt_mask | lesion_edge
                ny, nx = np.nonzero(neg_mask)

            if len(py) == 0:
                continue

            if len(ny) > self.cfg.max_negatives:
                sel = rng.choice(len(ny), size=self.cfg.max_negatives, replace=False)
                ny, nx = ny[sel], nx[sel]

            z_pos = z_flat[py, px]       # [P, D]
            z_neg = z_flat[ny, nx] if len(ny) else torch.zeros(0, d, device=device)

            queue_negs = torch.cat([self.bg_queue.queue, self.cross_queue.queue], dim=0)
            z_all_neg = torch.cat([z_neg, queue_negs], dim=0)

            z_candidates = torch.cat([z_pos, z_all_neg], dim=0)  # [P+N, D]
            logits = (z_a.unsqueeze(0) * z_candidates).sum(-1) / self.cfg.temperature  # [P+N]
            log_denom = torch.logsumexp(logits, dim=0)
            pos_logits = logits[: z_pos.shape[0]]
            per_pos_loss = -(pos_logits - log_denom)
            anchor_loss = w_a * per_pos_loss.mean()
            total_loss = total_loss + anchor_loss
            valid_anchors += 1

            if gt_mask[ay, ax]:
                new_cross_negs.append(z_a.detach())
            else:
                new_bg_negs.append(z_a.detach())

        if new_bg_negs:
            self.bg_queue.enqueue(torch.stack(new_bg_negs, dim=0))
        if new_cross_negs:
            self.cross_queue.enqueue(torch.stack(new_cross_negs, dim=0))

        if valid_anchors == 0:
            return z_map.sum() * 0.0
        return total_loss / valid_anchors
