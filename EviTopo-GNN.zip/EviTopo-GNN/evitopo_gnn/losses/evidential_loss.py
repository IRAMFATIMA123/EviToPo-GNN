"""Bayes-risk evidential loss (Section 3.3, Eq. 5).

    L_evid = sum_k [ (y_k - p_k)^2 + p_k(1-p_k)/(S+1) ]
             + lambda_KL * KL( Dir(alpha~) || Dir(1) )

where ``y`` is the one-hot label, ``alpha~ = y + (1 - y) * alpha`` removes
the evidence of the true class (so the KL term only discourages misleading
evidence on the *wrong* classes), and ``lambda_KL`` ramps linearly from 0
to 1 over the first ten epochs (Section 3.9).

Used identically for the coarse head (Section 3.3) and the final head
(Section 3.7), and -- with positive-class weighting -- for the gap-link
head (Section 3.6, see ``link_loss.py``).
"""

from __future__ import annotations

import torch
import torch.nn.functional as F


def kl_dirichlet_uniform(alpha: torch.Tensor, dim: int = 1) -> torch.Tensor:
    """KL( Dir(alpha) || Dir(1) ), closed form (Sensoy et al., 2018).
    ``alpha``: Dirichlet strengths with the class dimension at ``dim``.
    Returns a tensor with that dimension reduced (kept as size 1)."""
    beta = torch.ones_like(alpha)
    s_alpha = alpha.sum(dim=dim, keepdim=True)
    s_beta = beta.sum(dim=dim, keepdim=True)

    ln_b_alpha = torch.lgamma(s_alpha) - torch.lgamma(alpha).sum(dim=dim, keepdim=True)
    ln_b_beta = torch.lgamma(s_beta) - torch.lgamma(beta).sum(dim=dim, keepdim=True)

    dg_alpha = torch.digamma(alpha)
    dg_s_alpha = torch.digamma(s_alpha)

    kl = (ln_b_alpha - ln_b_beta) + ((alpha - beta) * (dg_alpha - dg_s_alpha)).sum(dim=dim, keepdim=True)
    return kl


def lambda_kl_schedule(epoch: int, ramp_epochs: int = 10) -> float:
    """Linear ramp of ``lambda_KL`` from 0 to 1 over the first
    ``ramp_epochs`` epochs (Section 3.9)."""
    return float(min(1.0, max(0.0, epoch) / max(ramp_epochs, 1)))


def evidential_bayes_risk_loss(
    alpha: torch.Tensor,            # [B, K, ...] or [E, K]
    target_onehot: torch.Tensor,    # same shape as alpha
    lambda_kl: float,
    class_dim: int = 1,
    mask: torch.Tensor | None = None,
    class_weight: torch.Tensor | None = None,
) -> torch.Tensor:
    """Eq. (5). Returns a scalar loss (mean over the masked region, or over
    all elements if ``mask`` is ``None``).

    ``class_weight``: optional per-class multiplier (``[K]``), used by the
    link loss for positive-class weighting of the rare "bridge" class.
    """
    s = alpha.sum(dim=class_dim, keepdim=True)
    p = alpha / s

    err = (target_onehot - p) ** 2
    var = p * (1 - p) / (s + 1)
    per_class = err + var
    if class_weight is not None:
        shape = [1] * alpha.dim()
        shape[class_dim] = -1
        per_class = per_class * class_weight.view(*shape)
    main_term = per_class.sum(dim=class_dim)  # reduce class dim

    alpha_tilde = target_onehot + (1 - target_onehot) * alpha
    kl = kl_dirichlet_uniform(alpha_tilde, dim=class_dim).squeeze(class_dim)

    loss_map = main_term + lambda_kl * kl

    if mask is not None:
        mask = mask.to(loss_map.dtype)
        denom = mask.sum().clamp(min=1.0)
        return (loss_map * mask).sum() / denom
    return loss_map.mean()


def to_one_hot_binary(y: torch.Tensor, class_dim: int = 1) -> torch.Tensor:
    """``y``: binary {0,1} foreground indicator with a singleton class
    dimension at ``class_dim`` (e.g. ``[B, 1, H, W]``). Returns the
    two-class one-hot tensor ``[background, foreground]`` concatenated
    along ``class_dim`` (e.g. ``[B, 2, H, W]``)."""
    background = 1.0 - y
    return torch.cat([background, y], dim=class_dim)
