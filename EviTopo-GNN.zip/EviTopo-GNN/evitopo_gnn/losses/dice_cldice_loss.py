"""Overlap and connectivity losses used in the segmentation term of Eq. (15):
``L_Dice`` (standard soft Dice) and ``L_clDice``, the centreline-Dice loss
of Shit et al. [18], computed from the differentiable soft skeleton
(``models/skeleton.py::soft_skeletonize``).
"""

from __future__ import annotations

import torch

from evitopo_gnn.models.skeleton import soft_skeletonize


def dice_loss(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None, smooth: float = 1.0) -> torch.Tensor:
    if mask is not None:
        pred = pred * mask
        target = target * mask
    intersection = (pred * target).sum(dim=(-2, -1))
    denom = pred.sum(dim=(-2, -1)) + target.sum(dim=(-2, -1))
    dice = (2 * intersection + smooth) / (denom + smooth)
    return (1 - dice).mean()


def cl_dice_loss(
    pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None, num_iter: int = 10, eps: float = 1e-6
) -> torch.Tensor:
    """Soft clDice loss: ``1 - clDice`` using the differentiable soft
    skeletons of both the prediction and the ground truth (Eq. 17 uses the
    hard-skeleton version at evaluation time; this is its training-time,
    differentiable counterpart, matching [18])."""
    skel_pred = soft_skeletonize(pred, num_iter=num_iter)
    skel_true = soft_skeletonize(target, num_iter=num_iter)
    if mask is not None:
        pred = pred * mask
        target = target * mask
        skel_pred = skel_pred * mask
        skel_true = skel_true * mask

    t_prec = (skel_pred * target).sum(dim=(-2, -1)) / (skel_pred.sum(dim=(-2, -1)) + eps)
    t_sens = (skel_true * pred).sum(dim=(-2, -1)) / (skel_true.sum(dim=(-2, -1)) + eps)
    cl_dice = 2 * t_prec * t_sens / (t_prec + t_sens + eps)
    return (1 - cl_dice).mean()
