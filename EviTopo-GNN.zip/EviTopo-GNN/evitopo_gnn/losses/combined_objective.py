"""Full training objective and three-stage schedule (Section 3.9, Eq. 15).

    L = lambda1 * (L_evid + L_Dice + L_clDice)
        + lambda2 * L_evid^c
        + lambda3 * L_link
        + lambda4 * L_con

with ``lambda1..lambda4 = 1.0, 0.5, 0.5, 0.1``. Training proceeds in three
stages because the skeleton of an untrained network is noise:

* **warm-up** (epochs 1-40): encoder + coarse head only.
* **graph** (epochs 41-100): adds the graph module, link loss and synthetic
  gaps.
* **full** (epochs 101-200): adds the contrastive loss.

:class:`StageSchedule` exposes the active stage, the KL ramp (Eq. 5) and
the contrastive sampling ramp (Eq. 13) for a given epoch; :class:`CombinedObjective`
combines already-computed per-term losses according to the stage and the
fixed lambda weights.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import torch

from evitopo_gnn.losses.evidential_loss import lambda_kl_schedule
from evitopo_gnn.losses.contrastive_loss import contrastive_ramp

STAGE_WARMUP = "warmup"
STAGE_GRAPH = "graph"
STAGE_FULL = "full"


@dataclass
class StageSchedule:
    warmup_end: int = 40
    graph_end: int = 100
    full_end: int = 200
    kl_ramp_epochs: int = 10
    contrastive_ramp_start: int = 101
    contrastive_ramp_end: int = 150

    def stage(self, epoch: int) -> str:
        if epoch <= self.warmup_end:
            return STAGE_WARMUP
        if epoch <= self.graph_end:
            return STAGE_GRAPH
        return STAGE_FULL

    def lambda_kl(self, epoch: int) -> float:
        return lambda_kl_schedule(epoch, self.kl_ramp_epochs)

    def contrastive_anchor_weight(self, epoch: int) -> float:
        return contrastive_ramp(epoch, self.contrastive_ramp_start, self.contrastive_ramp_end)

    def use_graph(self, epoch: int) -> bool:
        return self.stage(epoch) in (STAGE_GRAPH, STAGE_FULL)

    def use_contrastive(self, epoch: int) -> bool:
        return self.stage(epoch) == STAGE_FULL

    def use_synthetic_gaps(self, epoch: int) -> bool:
        return self.stage(epoch) in (STAGE_GRAPH, STAGE_FULL)


class CombinedObjective:
    """Stateless combiner: takes a dict of already-computed scalar losses
    and returns the weighted total plus a logging breakdown, zeroing out
    terms that are not yet active for the given epoch's stage."""

    def __init__(self, lambda1: float = 1.0, lambda2: float = 0.5, lambda3: float = 0.5, lambda4: float = 0.1, schedule: StageSchedule | None = None):
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.lambda3 = lambda3
        self.lambda4 = lambda4
        self.schedule = schedule or StageSchedule()

    def combine(self, losses: Dict[str, torch.Tensor], epoch: int) -> tuple[torch.Tensor, Dict[str, float]]:
        """``losses`` expected keys: ``evid_final``, ``dice``, ``cldice``
        (always present), and, once their stage is active,
        ``evid_coarse``, ``link``, ``contrastive``."""
        stage = self.schedule.stage(epoch)
        zero = next(iter(losses.values())).new_zeros(())

        seg_term = losses["evid_final"] + losses["dice"] + losses["cldice"]
        coarse_term = losses.get("evid_coarse", zero)
        link_term = losses.get("link", zero) if self.schedule.use_graph(epoch) else zero
        contrastive_term = losses.get("contrastive", zero) if self.schedule.use_contrastive(epoch) else zero

        total = (
            self.lambda1 * seg_term
            + self.lambda2 * coarse_term
            + self.lambda3 * link_term
            + self.lambda4 * contrastive_term
        )

        breakdown = {
            "stage": stage,
            "seg_term": float(seg_term.detach()),
            "coarse_term": float(coarse_term.detach()) if torch.is_tensor(coarse_term) else float(coarse_term),
            "link_term": float(link_term.detach()) if torch.is_tensor(link_term) else float(link_term),
            "contrastive_term": float(contrastive_term.detach()) if torch.is_tensor(contrastive_term) else float(contrastive_term),
            "total": float(total.detach()),
        }
        return total, breakdown
