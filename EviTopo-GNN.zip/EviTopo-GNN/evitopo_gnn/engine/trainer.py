"""Three-stage training loop (Section 3.9).

    warm-up (epochs 1-40):  encoder + coarse head
    graph   (epochs 41-100): + graph module, link loss, synthetic gaps
    full    (epochs 101-200): + contrastive loss

Optimisation uses AdamW with cosine decay on 512x512 patches (Section 3.9).
The per-image graph construction means batching is handled by looping over
the batch dimension inside :meth:`EviTopoGNN.forward`; this trainer loops
over images within a batch for the parts of the loss that also need
per-image ground truth (link labels, contrastive mining), which mirrors
the model's own per-image graph handling.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Optional

import numpy as np
import torch
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

from evitopo_gnn.models.evitopo_gnn import EviTopoGNN
from evitopo_gnn.models.graph_builder import NODE_ENDPOINT
from evitopo_gnn.losses.evidential_loss import evidential_bayes_risk_loss, to_one_hot_binary
from evitopo_gnn.losses.dice_cldice_loss import dice_loss, cl_dice_loss
from evitopo_gnn.losses.link_loss import make_synthetic_gap_candidate_labels, link_supervision_loss
from evitopo_gnn.losses.contrastive_loss import TopologyAwareContrastiveLoss
from evitopo_gnn.losses.combined_objective import CombinedObjective, StageSchedule
from evitopo_gnn.data.synthetic_gaps import apply_synthetic_gaps


@dataclass
class TrainerConfig:
    total_epochs: int = 200
    base_lr: float = 2e-4
    weight_decay: float = 1e-4
    tau_link: float = 0.5
    link_positive_weight: float = 5.0
    grad_clip_norm: Optional[float] = 1.0
    schedule: StageSchedule = field(default_factory=StageSchedule)


class Trainer:
    def __init__(self, model: EviTopoGNN, cfg: TrainerConfig | None = None, device: str = "cpu"):
        self.model = model.to(device)
        self.cfg = cfg or TrainerConfig()
        self.device = device
        self.objective = CombinedObjective(schedule=self.cfg.schedule)
        self.contrastive_loss_fn = TopologyAwareContrastiveLoss(proj_dim=model.contrastive_head.net[-1].out_channels).to(device)

        self.optimizer = AdamW(self.model.parameters(), lr=self.cfg.base_lr, weight_decay=self.cfg.weight_decay)
        self.scheduler = CosineAnnealingLR(self.optimizer, T_max=self.cfg.total_epochs)
        self._rng = np.random.default_rng(0)

    def _prepare_batch(self, images: torch.Tensor, masks: torch.Tensor, epoch: int):
        """Applies synthetic-gap augmentation (image-only) when the current
        stage calls for it (Section 3.6), returning the (possibly
        degraded) images and the unmodified labels."""
        if not self.cfg.schedule.use_synthetic_gaps(epoch):
            return images, masks, [[] for _ in range(images.shape[0])]

        degraded = images.clone()
        all_gap_records = []
        for b in range(images.shape[0]):
            img_np = images[b].permute(1, 2, 0).cpu().numpy()
            mask_np = masks[b, 0].cpu().numpy()
            out_img, records = apply_synthetic_gaps(img_np, mask_np, self._rng)
            degraded[b] = torch.from_numpy(out_img).permute(2, 0, 1).to(images.device)
            all_gap_records.append(records)
        return degraded, masks, all_gap_records

    def train_one_epoch(self, dataloader: Iterable, epoch: int) -> dict:
        self.model.train()
        schedule = self.cfg.schedule
        lambda_kl = schedule.lambda_kl(epoch)
        running = {"total": 0.0, "n_batches": 0}

        for images, masks, fov_masks, _stems in dataloader:
            images = images.to(self.device)
            masks = masks.to(self.device)
            fov_masks = fov_masks.to(self.device)

            images, masks, gap_records = self._prepare_batch(images, masks, epoch)

            out = self.model(images, inference=False)
            batch_losses = {"evid_final": [], "dice": [], "cldice": [], "evid_coarse": [], "link": [], "contrastive": []}

            for b in range(images.shape[0]):
                target = masks[b : b + 1]
                fov = fov_masks[b : b + 1]
                target_onehot_final = to_one_hot_binary(target, class_dim=1)
                target_onehot_coarse = target_onehot_final

                batch_losses["evid_final"].append(
                    evidential_bayes_risk_loss(out.final[b].alpha, target_onehot_final, lambda_kl, mask=fov)
                )
                batch_losses["dice"].append(dice_loss(out.final[b].prob, target, mask=fov))
                batch_losses["cldice"].append(cl_dice_loss(out.final[b].prob, target, mask=fov))
                batch_losses["evid_coarse"].append(
                    evidential_bayes_risk_loss(out.coarse[b].alpha, target_onehot_coarse, lambda_kl, mask=fov)
                )

                if schedule.use_graph(epoch):
                    graph = out.graphs[b]
                    gt_skel_mask = target[0, 0].detach().cpu().numpy() > 0.5
                    labels = make_synthetic_gap_candidate_labels(graph.node_pos, graph.gap_edge_index, gt_skel_mask)
                    labels = labels.to(self.device)
                    link_out = out.link_outputs[b]
                    batch_losses["link"].append(
                        link_supervision_loss(link_out.alpha, labels, lambda_kl, self.cfg.link_positive_weight)
                    )

                if schedule.use_contrastive(epoch):
                    z_map = out.contrastive_embeddings[b : b + 1]
                    gt_mask_np = target[0, 0].detach().cpu().numpy() > 0.5
                    batch_losses["contrastive"].append(
                        self.contrastive_loss_fn(
                            z_map, out.final[b].prob, out.final[b].uncertainty, gt_mask_np, epoch
                        )
                    )

            losses = {}
            for key in ["evid_final", "dice", "cldice", "evid_coarse"]:
                losses[key] = torch.stack(batch_losses[key]).mean()
            if batch_losses["link"]:
                losses["link"] = torch.stack(batch_losses["link"]).mean()
            if batch_losses["contrastive"]:
                losses["contrastive"] = torch.stack(batch_losses["contrastive"]).mean()

            total, breakdown = self.objective.combine(losses, epoch)

            self.optimizer.zero_grad()
            total.backward()
            if self.cfg.grad_clip_norm:
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.grad_clip_norm)
            self.optimizer.step()

            running["total"] += float(total.detach())
            running["n_batches"] += 1

        self.scheduler.step()
        running["mean_total_loss"] = running["total"] / max(running["n_batches"], 1)
        running["stage"] = schedule.stage(epoch)
        running["lambda_kl"] = lambda_kl
        return running
