"""Evaluation loop producing per-image (or per-child, CHASE_DB1) metrics,
and the aggregation protocol of Sections 4.2 / 4.4.

Two aggregation styles, matching the paper's distinction between estimands
(never mixed, Section 4.4):

* ``pool_counts_across_images`` + ``pixel_metrics_from_counts`` gives the
  **pooled estimand** (Table 1): micro-average confusion counts over every
  FOV pixel of the test set *within one seed*, compute the ratio metric
  once, then average that ratio over the five seeds
  (``aggregate_pooled_over_seeds``).
* Per-image clDice / Betti-0 / ECE values, kept as a list indexed by test
  unit, are the **per-unit estimand** (Table 2) fed straight into
  ``stats/significance.py``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np
import torch

from evitopo_gnn.models.evitopo_gnn import EviTopoGNN
from evitopo_gnn.graph.topology_metrics import cl_dice_score, betti0_error
from evitopo_gnn.metrics.segmentation_metrics import ConfusionCounts, pooled_confusion_counts, pixel_metrics_from_counts
from evitopo_gnn.metrics.calibration import expected_calibration_error, brier_score, negative_log_likelihood
from evitopo_gnn.metrics.uncertainty_metrics import auroc_error_detection, aurc
from evitopo_gnn.inference.tiled_inference import TiledInferenceEngine


@dataclass
class PerImageResult:
    stem: str
    counts: ConfusionCounts
    cl_dice: float
    betti0: float
    ece: float
    brier: float
    nll: float
    auroc_err: float
    aurc: float


class Evaluator:
    def __init__(self, model: EviTopoGNN, device: str = "cpu", window: int = 512, stride: int = 256, threshold: float = 0.5):
        self.model = model.to(device)
        self.device = device
        self.engine = TiledInferenceEngine(model, window=window, stride=stride)
        self.threshold = threshold

    @torch.no_grad()
    def evaluate_image(self, image: torch.Tensor, vessel_mask: torch.Tensor, fov_mask: torch.Tensor, stem: str) -> PerImageResult:
        self.model.eval()
        image = image.unsqueeze(0).to(self.device)
        fov = fov_mask.unsqueeze(0).to(self.device)
        result = self.engine.run(image, fov)

        prob_np = result.prob[0].cpu().numpy()
        unc_np = result.uncertainty[0].cpu().numpy()
        gt_np = vessel_mask[0].cpu().numpy()
        fov_np = fov_mask[0].cpu().numpy()
        pred_binary = (prob_np >= self.threshold).astype(np.float32)

        counts = pooled_confusion_counts(pred_binary, gt_np, fov_np)
        cl = cl_dice_score(pred_binary, gt_np, fov_np)
        b0 = betti0_error(pred_binary, gt_np, fov_np)

        region = fov_np > 0.5
        ece = expected_calibration_error(prob_np, gt_np, region_mask=region)
        brier = brier_score(prob_np[region], gt_np[region])
        nll = negative_log_likelihood(prob_np[region], gt_np[region])
        auc_err = auroc_error_detection(pred_binary, gt_np, unc_np, region_mask=region)
        aurc_val = aurc(pred_binary, gt_np, unc_np, region_mask=region)

        return PerImageResult(
            stem=stem, counts=counts, cl_dice=cl, betti0=b0, ece=ece, brier=brier, nll=nll,
            auroc_err=auc_err, aurc=aurc_val,
        )

    def evaluate_dataset(self, dataset) -> List[PerImageResult]:
        results = []
        for image, vessel_mask, fov_mask, stem in dataset:
            results.append(self.evaluate_image(image, vessel_mask, fov_mask, stem))
        return results


def pool_counts_across_images(results: List[PerImageResult]) -> ConfusionCounts:
    total = ConfusionCounts(0, 0, 0, 0)
    for r in results:
        total = total + r.counts
    return total


def aggregate_pooled_over_seeds(per_seed_results: List[List[PerImageResult]]) -> Dict[str, float]:
    """Section 4.2: pool within each seed, compute the ratio metric once
    per seed, then average the five (or however many) seed-wise ratios."""
    per_seed_f1 = []
    for seed_results in per_seed_results:
        counts = pool_counts_across_images(seed_results)
        per_seed_f1.append(pixel_metrics_from_counts(counts)["f1"])
    per_seed_cldice = [float(np.mean([r.cl_dice for r in seed_results])) for seed_results in per_seed_results]
    return {
        "f1_mean": float(np.mean(per_seed_f1)),
        "f1_std": float(np.std(per_seed_f1)),
        "cldice_mean": float(np.mean(per_seed_cldice)),
        "cldice_std": float(np.std(per_seed_cldice)),
    }
