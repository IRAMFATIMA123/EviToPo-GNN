"""Hard-skeleton topology metrics used for evaluation (Section 4.2).

``cl_dice_score`` implements Eq. (17):

    clDice = 2 * T_prec * T_sens / (T_prec + T_sens)

where ``T_prec`` is the fraction of the predicted skeleton inside the
ground-truth mask and ``T_sens`` the fraction of the ground-truth skeleton
inside the prediction (both hard skeletons here, for evaluation; the
training-time soft/differentiable version is
``losses/dice_cldice_loss.py::cl_dice_loss``).

``betti0_error`` is the normalised zero-dimensional Betti error: per image,
the absolute difference between the number of 8-connected foreground
components of the prediction and of the ground truth inside the FOV, each
counted after discarding components smaller than 5 px, divided by the
ground-truth count (or by one where that count is zero).
"""

from __future__ import annotations

import numpy as np
from scipy.ndimage import label as cc_label

from evitopo_gnn.models.skeleton import hard_skeletonize_and_prune


def _hard_skeleton(mask: np.ndarray, threshold: float = 0.5, min_spur_len: int = 0) -> np.ndarray:
    return hard_skeletonize_and_prune(mask.astype(np.float32), threshold=threshold, min_spur_len=min_spur_len)


def cl_dice_score(pred_mask: np.ndarray, gt_mask: np.ndarray, fov_mask: np.ndarray | None = None, eps: float = 1e-8) -> float:
    """Eq. (17), evaluated on hard (binarised, thinned) skeletons."""
    if fov_mask is not None:
        pred_mask = pred_mask * fov_mask
        gt_mask = gt_mask * fov_mask
    pred_skel = _hard_skeleton(pred_mask)
    gt_skel = _hard_skeleton(gt_mask)

    t_prec = (pred_skel & (gt_mask > 0.5)).sum() / max(pred_skel.sum(), eps)
    t_sens = (gt_skel & (pred_mask > 0.5)).sum() / max(gt_skel.sum(), eps)
    if t_prec + t_sens < eps:
        return 0.0
    return float(2 * t_prec * t_sens / (t_prec + t_sens))


def _count_components(mask: np.ndarray, fov_mask: np.ndarray | None, min_size_px: int = 5) -> int:
    binary = mask > 0.5
    if fov_mask is not None:
        binary = binary & (fov_mask > 0.5)
    labelled, n = cc_label(binary, structure=np.ones((3, 3)))
    if n == 0:
        return 0
    sizes = np.bincount(labelled.ravel())[1:]  # skip background label 0
    return int((sizes >= min_size_px).sum())


def betti0_error(pred_mask: np.ndarray, gt_mask: np.ndarray, fov_mask: np.ndarray | None = None, min_size_px: int = 5) -> float:
    """Normalised zero-dimensional Betti error (Section 4.2)."""
    n_pred = _count_components(pred_mask, fov_mask, min_size_px)
    n_gt = _count_components(gt_mask, fov_mask, min_size_px)
    denom = n_gt if n_gt > 0 else 1
    return abs(n_pred - n_gt) / denom
