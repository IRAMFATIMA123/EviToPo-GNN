"""
EviTopo-GNN
===========

Evidential Vessel-Topology Graph Learning with Uncertainty-Guided Contrastive
Representation for Retinal Vessel Segmentation in Diabetic Retinopathy.

Reference implementation matching the equations of the paper:

    Fatima, I., Khan, I. R., Kaur, H.
    "EviTopo-GNN: Evidential Vessel-Topology Graph Learning with
    Uncertainty-Guided Contrastive Representation for Retinal Vessel
    Segmentation in Diabetic Retinopathy."

Package layout
--------------
evitopo_gnn/
    models/    network modules (encoder, evidential heads, graph, GNN, decoder)
    losses/    training objectives (Eq. 5, 14, 15)
    data/      dataset loaders, splits, synthetic-gap augmentation
    graph/     topology metrics (clDice, Betti-0)
    metrics/   segmentation / calibration / uncertainty metrics
    inference/ full-image tiled inference with a single global graph
    engine/    training and evaluation loops
    stats/     paired bootstrap, Wilcoxon, Holm-corrected significance tests
    utils/     seeding, logging, checkpointing

See README.md for installation and reproduction instructions, and
``results/`` for the Table 1-5 data, rendered tables and figures
accompanying the Results section of the paper.
"""

from evitopo_gnn.models.evitopo_gnn import EviTopoGNN, EviTopoGNNOutput

__all__ = ["EviTopoGNN", "EviTopoGNNOutput"]
__version__ = "1.0.0"
