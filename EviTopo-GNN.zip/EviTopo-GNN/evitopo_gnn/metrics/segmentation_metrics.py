"""Pixel-agreement metrics (Section 4.2).

Pixel metrics are **micro-averaged in a fixed order**: within each seed the
confusion counts are pooled over all FOV pixels of the test images and the
metric is computed from those counts, and the five seed values are then
averaged. A reported pixel metric is therefore a mean of seed-wise ratios,
never a ratio of seed-averaged counts (the two differ because F1 and
precision are non-linear in the counts).

    F1 = 2*TP / (2*TP + FP + FN)                                  (Eq. 16)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class ConfusionCounts:
    tp: int
    fp: int
    fn: int
    tn: int

    def __add__(self, other: "ConfusionCounts") -> "ConfusionCounts":
        return ConfusionCounts(self.tp + other.tp, self.fp + other.fp, self.fn + other.fn, self.tn + other.tn)


def pooled_confusion_counts(pred_binary: np.ndarray, gt_binary: np.ndarray, fov_mask: np.ndarray | None = None) -> ConfusionCounts:
    """Accumulate confusion counts over the FOV of one image (call once per
    test image, then sum the returned :class:`ConfusionCounts` across the
    test set before computing any ratio metric -- that pooling is what
    "micro-averaged" means here)."""
    pred = pred_binary.astype(bool)
    gt = gt_binary.astype(bool)
    if fov_mask is not None:
        valid = fov_mask.astype(bool)
        pred, gt = pred[valid], gt[valid]
    tp = int(np.logical_and(pred, gt).sum())
    fp = int(np.logical_and(pred, ~gt).sum())
    fn = int(np.logical_and(~pred, gt).sum())
    tn = int(np.logical_and(~pred, ~gt).sum())
    return ConfusionCounts(tp, fp, fn, tn)


def f1_from_counts(c: ConfusionCounts, eps: float = 1e-8) -> float:
    return (2 * c.tp) / max(2 * c.tp + c.fp + c.fn, eps)


def pixel_metrics_from_counts(c: ConfusionCounts, eps: float = 1e-8) -> dict:
    accuracy = (c.tp + c.tn) / max(c.tp + c.tn + c.fp + c.fn, eps)
    precision = c.tp / max(c.tp + c.fp, eps)
    sensitivity = c.tp / max(c.tp + c.fn, eps)   # Se / recall
    specificity = c.tn / max(c.tn + c.fp, eps)   # Sp
    f1 = f1_from_counts(c, eps)
    return {
        "accuracy": accuracy,
        "precision": precision,
        "sensitivity": sensitivity,
        "specificity": specificity,
        "f1": f1,
    }


def pooled_auc_roc(pooled_probs: np.ndarray, pooled_labels: np.ndarray) -> float:
    """AUC-ROC from pooled probability maps (Section 4.2). A small
    dependency-free implementation (rank-based Mann-Whitney U statistic) so
    this module does not require scikit-learn."""
    order = np.argsort(pooled_probs)
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, len(pooled_probs) + 1)

    pos = pooled_labels.astype(bool)
    n_pos = int(pos.sum())
    n_neg = len(pooled_labels) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    sum_ranks_pos = ranks[pos].sum()
    auc = (sum_ranks_pos - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)
    return float(auc)
