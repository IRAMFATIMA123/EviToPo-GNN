"""Uncertainty-ranking metrics (Section 4.2): the error-detection ROC
(``AUROC-err``) and the risk-coverage curve / its area (``AURC``).

Both treat the predicted uncertainty as a *score for ranking* pixels by how
likely they are to be mispredicted, as opposed to calibration metrics
(``calibration.py``), which judge whether the probability itself is
accurate. The two are "never conflated" (Section 4.2).
"""

from __future__ import annotations

import numpy as np

from evitopo_gnn.metrics.segmentation_metrics import pooled_auc_roc


def auroc_error_detection(pred_binary: np.ndarray, gt_binary: np.ndarray, uncertainty: np.ndarray, region_mask: np.ndarray | None = None) -> float:
    """AUROC-err: can the uncertainty separate correctly- from incorrectly-
    classified pixels? ``label = 1`` where the thresholded prediction
    disagrees with the ground truth."""
    pred = pred_binary.ravel().astype(bool)
    gt = gt_binary.ravel().astype(bool)
    unc = uncertainty.ravel()
    if region_mask is not None:
        region_mask = region_mask.ravel().astype(bool)
        pred, gt, unc = pred[region_mask], gt[region_mask], unc[region_mask]
    error_label = (pred != gt).astype(np.float64)
    return pooled_auc_roc(unc, error_label)


def risk_coverage_curve(pred_binary: np.ndarray, gt_binary: np.ndarray, uncertainty: np.ndarray, region_mask: np.ndarray | None = None):
    """Sorts pixels from most- to least-confident (ascending uncertainty)
    and returns ``(coverage, risk)`` arrays: at coverage ``c`` (the fraction
    of pixels kept / not referred for review), risk is the error rate among
    those kept pixels."""
    pred = pred_binary.ravel().astype(bool)
    gt = gt_binary.ravel().astype(bool)
    unc = uncertainty.ravel()
    if region_mask is not None:
        region_mask = region_mask.ravel().astype(bool)
        pred, gt, unc = pred[region_mask], gt[region_mask], unc[region_mask]

    n = len(unc)
    order = np.argsort(unc)  # most confident (lowest uncertainty) first
    errors = (pred != gt).astype(np.float64)[order]
    cum_errors = np.cumsum(errors)
    coverage = np.arange(1, n + 1) / n
    risk = cum_errors / np.arange(1, n + 1)
    return coverage, risk


_trapezoid = getattr(np, "trapezoid", None) or np.trapz  # numpy >=2.0 renamed trapz -> trapezoid


def aurc(pred_binary: np.ndarray, gt_binary: np.ndarray, uncertainty: np.ndarray, region_mask: np.ndarray | None = None) -> float:
    """Area under the risk-coverage curve (trapezoidal rule)."""
    coverage, risk = risk_coverage_curve(pred_binary, gt_binary, uncertainty, region_mask)
    return float(_trapezoid(risk, coverage))
