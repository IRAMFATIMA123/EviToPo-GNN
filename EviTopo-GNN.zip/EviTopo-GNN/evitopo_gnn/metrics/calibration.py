"""Calibration metrics (Section 4.2): ECE over 15 bins, reliability-diagram
data, Brier score and negative log-likelihood.

    ECE = sum_{b=1}^{15} (|B_b| / N) * |acc(B_b) - conf(B_b)|          (Eq. 18)

``expected_calibration_error`` supports restricting the pixel population
(e.g. to ground-truth vessel pixels, or to a band around the vessel edge,
Section 5.3 / Table 3) via a boolean ``region_mask``.
"""

from __future__ import annotations

import numpy as np


def expected_calibration_error(
    probs: np.ndarray, labels: np.ndarray, num_bins: int = 15, region_mask: np.ndarray | None = None
) -> float:
    probs = probs.ravel()
    labels = labels.ravel().astype(np.float64)
    if region_mask is not None:
        region_mask = region_mask.ravel().astype(bool)
        probs, labels = probs[region_mask], labels[region_mask]
    n = len(probs)
    if n == 0:
        return float("nan")

    bin_edges = np.linspace(0.0, 1.0, num_bins + 1)
    ece = 0.0
    for b in range(num_bins):
        lo, hi = bin_edges[b], bin_edges[b + 1]
        if b == num_bins - 1:
            in_bin = (probs >= lo) & (probs <= hi)
        else:
            in_bin = (probs >= lo) & (probs < hi)
        count = in_bin.sum()
        if count == 0:
            continue
        acc = labels[in_bin].mean()
        conf = probs[in_bin].mean()
        ece += (count / n) * abs(acc - conf)
    return float(ece)


def reliability_diagram_data(probs: np.ndarray, labels: np.ndarray, num_bins: int = 15):
    """Returns ``(bin_centers, accuracy_per_bin, confidence_per_bin, counts)``
    for plotting a reliability diagram."""
    probs = probs.ravel()
    labels = labels.ravel().astype(np.float64)
    bin_edges = np.linspace(0.0, 1.0, num_bins + 1)
    centers, acc, conf, counts = [], [], [], []
    for b in range(num_bins):
        lo, hi = bin_edges[b], bin_edges[b + 1]
        in_bin = (probs >= lo) & (probs < hi if b < num_bins - 1 else probs <= hi)
        c = in_bin.sum()
        centers.append((lo + hi) / 2)
        counts.append(int(c))
        if c == 0:
            acc.append(np.nan)
            conf.append(np.nan)
        else:
            acc.append(float(labels[in_bin].mean()))
            conf.append(float(probs[in_bin].mean()))
    return np.array(centers), np.array(acc), np.array(conf), np.array(counts)


def brier_score(probs: np.ndarray, labels: np.ndarray) -> float:
    probs = probs.ravel()
    labels = labels.ravel().astype(np.float64)
    return float(np.mean((probs - labels) ** 2))


def negative_log_likelihood(probs: np.ndarray, labels: np.ndarray, eps: float = 1e-7) -> float:
    probs = np.clip(probs.ravel(), eps, 1 - eps)
    labels = labels.ravel().astype(np.float64)
    nll = -(labels * np.log(probs) + (1 - labels) * np.log(1 - probs))
    return float(nll.mean())
