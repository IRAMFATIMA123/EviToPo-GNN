"""Paired statistics against the strongest baseline (Section 4.4).

Two estimands, never mixed:

* **Per-unit estimand** (Table 2): ``Delta`` is the mean, over test units,
  of the paired per-unit difference (EviTopo-GNN minus comparator); its 95%
  CI is the percentile interval of a paired bootstrap over test units, and
  ``p`` comes from a paired Wilcoxon signed-rank test on the same
  differences -- estimate, interval and test all refer to the same
  quantity.
* **Pooled estimand** (Table 1 / supplementary Table S5): the difference of
  the micro-pooled dataset-level metric, given separately by a cluster
  bootstrap that resamples units, re-pools their confusion counts and
  recomputes the metric.

Holm correction is applied within each dataset and endpoint separately over
the eleven baselines, controlling the family-wise error rate within each
dataset-endpoint family rather than jointly across endpoints.
"""

from __future__ import annotations

from typing import Callable, List, Sequence

import numpy as np
from scipy.stats import wilcoxon


def paired_bootstrap_ci(
    values_a: Sequence[float], values_b: Sequence[float], n_resamples: int = 10_000, seed: int = 0, alpha: float = 0.05
):
    """Per-unit estimand: paired bootstrap over test units (Section 4.4).
    ``values_a`` (ours) and ``values_b`` (comparator) must be aligned by
    unit (e.g. per-image metric values, or per-child on CHASE_DB1)."""
    a = np.asarray(values_a, dtype=np.float64)
    b = np.asarray(values_b, dtype=np.float64)
    assert a.shape == b.shape
    diffs = a - b
    n = len(diffs)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(n_resamples, n))
    resampled_means = diffs[idx].mean(axis=1)
    lo = np.percentile(resampled_means, 100 * alpha / 2)
    hi = np.percentile(resampled_means, 100 * (1 - alpha / 2))
    return float(diffs.mean()), (float(lo), float(hi))


def paired_wilcoxon_p(values_a: Sequence[float], values_b: Sequence[float]) -> float:
    """Paired Wilcoxon signed-rank test on per-unit differences."""
    a = np.asarray(values_a, dtype=np.float64)
    b = np.asarray(values_b, dtype=np.float64)
    diffs = a - b
    if np.allclose(diffs, 0):
        return 1.0
    try:
        _, p = wilcoxon(diffs)
    except ValueError:
        # all-zero or too few non-tied samples
        p = 1.0
    return float(p)


def holm_correction(p_values: Sequence[float]) -> List[float]:
    """Holm step-down adjustment. Returns adjusted p-values in the same
    order as the input, each clipped to the running maximum so adjusted
    p-values are monotone non-decreasing in rank (standard Holm
    convention)."""
    p = np.asarray(p_values, dtype=np.float64)
    m = len(p)
    order = np.argsort(p)
    adjusted = np.empty(m, dtype=np.float64)
    running_max = 0.0
    for rank, idx in enumerate(order):
        factor = m - rank
        val = min(1.0, p[idx] * factor)
        running_max = max(running_max, val)
        adjusted[idx] = running_max
    return adjusted.tolist()


def cluster_bootstrap_pooled_difference(
    per_unit_counts_a: List[dict], per_unit_counts_b: List[dict], metric_fn: Callable[[dict], float],
    n_resamples: int = 10_000, seed: int = 0, alpha: float = 0.05,
):
    """Pooled estimand (Table 1 / Table S5): resample *units* with
    replacement, re-pool each resample's confusion counts, and recompute
    the metric for each arm -- so the statistic is a difference of
    micro-averaged metrics, not a mean of per-unit differences.

    ``per_unit_counts_{a,b}``: list of dicts with keys ``tp, fp, fn, tn``
    (aligned by unit index). ``metric_fn``: maps a pooled count dict to a
    scalar, e.g. ``lambda c: f1_from_counts(ConfusionCounts(**c))``.
    """
    n = len(per_unit_counts_a)
    assert n == len(per_unit_counts_b)
    rng = np.random.default_rng(seed)

    def pool(selected: List[dict]) -> dict:
        out = {"tp": 0, "fp": 0, "fn": 0, "tn": 0}
        for c in selected:
            for k in out:
                out[k] += c[k]
        return out

    point_a = metric_fn(pool(per_unit_counts_a))
    point_b = metric_fn(pool(per_unit_counts_b))
    point_diff = point_a - point_b

    diffs = np.empty(n_resamples)
    idx_pool = rng.integers(0, n, size=(n_resamples, n))
    for r in range(n_resamples):
        idx = idx_pool[r]
        a_sel = [per_unit_counts_a[i] for i in idx]
        b_sel = [per_unit_counts_b[i] for i in idx]
        diffs[r] = metric_fn(pool(a_sel)) - metric_fn(pool(b_sel))

    lo = np.percentile(diffs, 100 * alpha / 2)
    hi = np.percentile(diffs, 100 * (1 - alpha / 2))
    return float(point_diff), (float(lo), float(hi))
