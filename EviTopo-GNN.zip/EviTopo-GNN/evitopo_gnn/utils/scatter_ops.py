"""Minimal scatter-reduce helpers so the GNN (Eq. 7-9) needs no optional
``torch_scatter`` / ``torch_geometric`` dependency. Pure-PyTorch, works on
CPU and CUDA alike (``scatter_reduce_`` has been part of core PyTorch since
1.12)."""

from __future__ import annotations

import torch


def scatter_softmax(src: torch.Tensor, index: torch.Tensor, num_nodes: int, eps: float = 1e-16) -> torch.Tensor:
    """Softmax of ``src`` values grouped by ``index`` (e.g. destination node
    of each edge), matching ``beta_ij`` in Eq. (7)."""
    if src.numel() == 0:
        return src
    group_max = torch.full((num_nodes,), float("-inf"), device=src.device, dtype=src.dtype)
    group_max = group_max.scatter_reduce(0, index, src, reduce="amax", include_self=True)
    group_max = torch.nan_to_num(group_max, neginf=0.0)
    shifted = src - group_max[index]
    exp = shifted.exp()
    denom = torch.zeros(num_nodes, device=src.device, dtype=src.dtype)
    denom = denom.scatter_add(0, index, exp)
    return exp / (denom[index] + eps)


def scatter_add(src: torch.Tensor, index: torch.Tensor, num_nodes: int) -> torch.Tensor:
    """Sum ``src`` rows grouped by ``index`` into a ``[num_nodes, *]`` tensor."""
    shape = (num_nodes,) + src.shape[1:]
    out = torch.zeros(shape, device=src.device, dtype=src.dtype)
    idx = index.view(-1, *([1] * (src.dim() - 1))).expand_as(src)
    out = out.scatter_add(0, idx, src)
    return out
