"""Tiny YAML config loader supporting one level of ``inherits:`` (a
per-dataset config inherits ``configs/base.yaml`` and overrides only the
``dataset:`` block -- see ``configs/*.yaml``)."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import yaml


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(base)
    for k, v in override.items():
        if k == "inherits":
            continue
        if isinstance(v, dict) and isinstance(merged.get(k), dict):
            merged[k] = _deep_merge(merged[k], v)
        else:
            merged[k] = v
    return merged


def load_config(path: str) -> Dict[str, Any]:
    path = Path(path)
    with open(path) as f:
        cfg = yaml.safe_load(f) or {}
    if "inherits" in cfg:
        parent_path = path.parent / cfg["inherits"]
        parent = load_config(str(parent_path))
        cfg = _deep_merge(parent, cfg)
    return cfg
