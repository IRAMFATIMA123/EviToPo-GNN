"""Full-image tiled inference with a single global graph (Section 3.9).

The claim that cross-tile gaps are repaired depends on this path:

(i)   The image is reflection-padded so each side is a whole number of
      strides (window 512 px, stride 256 px) and every FOV pixel lies
      under at least one window.
(ii)  Only Stage A -- the encoder, the ViT-CNN fusion and the coarse
      evidential head -- runs per tile.
(iii) The fused full-resolution features and the coarse Dirichlet evidence
      are stitched, overlaps being combined by *accumulating evidence
      rather than probability*: the window-weighted sum of tile evidence
      divided by the summed weight under a separable raised-cosine window,
      so the merged uncertainty read from Eq. (4) is that of one Dirichlet
      posterior rather than an average of per-tile uncertainties.
(iv)  The graph is built once on the stitched map -- the soft skeleton,
      binarisation, thinning and spur pruning are all global, so no
      skeleton is pruned at a tile boundary and no endpoint is created by
      one.
(v)   Nodes carry coordinates in the padded global frame and sample
      bilinearly from the stitched maps.
(vi)  One global GNN + link-head pass follows and the accepted gaps are
      rasterised into a single global link-prior map.
(vii) Stage B -- the decoder and final head -- then runs once on the
      global graph and the stitched full-resolution skip features
      (decoding is not repeated per tile).
(viii) Padding is removed and the FOV mask applied before any metric is
      computed.

Implementation note: step (vii)'s optional *memory-driven* windowing of
Stage B ("where memory requires it is itself windowed with the same
merge, but the graph stays global") is not implemented here -- this
reference implementation always runs Stage B once on the full stitched
tensor, which is the behaviour the paper measures its *full-image*
timings against. A production deployment on very large images (e.g. the
3504x2336 px HRF example in Section 6.3) would add that chunked decode.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch
import torch.nn.functional as F

from evitopo_gnn.models.evitopo_gnn import EviTopoGNN
from evitopo_gnn.models.evidential_head import EvidentialOutput
from evitopo_gnn.models.link_predictor import decide_bridges
from evitopo_gnn.models.graph_builder import NODE_ENDPOINT


@dataclass
class TiledInferenceResult:
    prob: torch.Tensor         # [1, H, W] (padding removed)
    uncertainty: torch.Tensor  # [1, H, W]
    num_tiles: int
    tile_positions: list


def _raised_cosine_window(window: int, device) -> torch.Tensor:
    n = torch.arange(window, dtype=torch.float32, device=device)
    w1d = 0.5 - 0.5 * torch.cos(2 * math.pi * (n + 0.5) / window)
    w1d = w1d.clamp(min=1e-3)  # avoid exact zero weight at tile borders
    return torch.outer(w1d, w1d)  # [window, window]


def _tile_starts(size: int, window: int, stride: int):
    if size <= window:
        return [0], window
    n_steps = math.ceil((size - window) / stride)
    total = window + n_steps * stride
    starts = list(range(0, total - window + 1, stride))
    return starts, total


class TiledInferenceEngine:
    def __init__(self, model: EviTopoGNN, window: int = 512, stride: int = 256, tau_link: float = 0.5):
        self.model = model
        self.window = window
        self.stride = stride
        self.tau_link = tau_link

    @torch.no_grad()
    def run(self, image: torch.Tensor, fov_mask: torch.Tensor | None = None) -> TiledInferenceResult:
        """``image``: ``[1, 3, H, W]``. Returns probability/uncertainty
        cropped back to the original ``(H, W)``."""
        device = image.device
        _, _, h, w = image.shape
        y_starts, padded_h = _tile_starts(h, self.window, self.stride)
        x_starts, padded_w = _tile_starts(w, self.window, self.stride)
        pad_h, pad_w = padded_h - h, padded_w - w
        padded = F.pad(image, (0, pad_w, 0, pad_h), mode="reflect")

        win = _raised_cosine_window(self.window, device)

        full_res_ch = self.model.encoder.full_res_channels
        decoded_ch = self.model.decoded_feat_ch

        evidence_sum = torch.zeros(2, padded_h, padded_w, device=device)
        full_res_sum = torch.zeros(full_res_ch, padded_h, padded_w, device=device)
        decoded_sum = torch.zeros(decoded_ch, padded_h, padded_w, device=device)
        weight_sum = torch.zeros(1, padded_h, padded_w, device=device)

        tile_positions = []
        for y0 in y_starts:
            for x0 in x_starts:
                tile = padded[:, :, y0 : y0 + self.window, x0 : x0 + self.window]
                full_res, fused = self.model.encoder(tile)
                decoded = self.model.coarse_decoder(fused, full_res)
                coarse_out = self.model.coarse_head(decoded)

                evidence_sum[:, y0 : y0 + self.window, x0 : x0 + self.window] += (
                    coarse_out.evidence[0] * win.unsqueeze(0)
                )
                full_res_sum[:, y0 : y0 + self.window, x0 : x0 + self.window] += full_res[0] * win.unsqueeze(0)
                decoded_sum[:, y0 : y0 + self.window, x0 : x0 + self.window] += decoded[0] * win.unsqueeze(0)
                weight_sum[:, y0 : y0 + self.window, x0 : x0 + self.window] += win.unsqueeze(0)
                tile_positions.append((y0, x0))

        weight_sum = weight_sum.clamp(min=1e-6)
        merged_evidence = evidence_sum / weight_sum          # (iii)
        merged_full_res = full_res_sum / weight_sum
        merged_decoded = decoded_sum / weight_sum

        alpha = merged_evidence + 1.0
        strength = alpha.sum(dim=0, keepdim=True)
        merged_prob = (alpha[1:2] / strength)
        merged_uncertainty = 2.0 / strength
        coarse_global = EvidentialOutput(
            prob=merged_prob.unsqueeze(0), uncertainty=merged_uncertainty.unsqueeze(0),
            alpha=alpha.unsqueeze(0), evidence=merged_evidence.unsqueeze(0),
        )

        # (iv)-(vi): single global graph, GNN pass and link decision.
        graph = self.model.graph_builder.build(merged_prob, merged_uncertainty, merged_decoded)
        h_prime = self.model.gnn(graph)
        edge_emb_gap = (
            self.model.gnn.edge_encoder.gap_enc(graph.gap_edge_attr)
            if graph.gap_edge_attr.shape[0]
            else torch.zeros(0, self.model.gnn.edge_encoder.edge_dim, device=device)
        )
        link_out = self.model.link_predictor(h_prime, graph.gap_edge_index, edge_emb_gap)
        accepted_mask = decide_bridges(
            graph.gap_edge_index, link_out.pi, link_out.u, graph.node_type,
            node_is_endpoint_value=NODE_ENDPOINT, tau_link=self.tau_link,
        )

        # (vii): Stage B once, globally.
        final_out, _, _, _ = self.model.decoder(
            graph.node_pos, h_prime, graph.node_width, graph.gap_edge_index, link_out.pi,
            merged_full_res.unsqueeze(0), accepted_mask=accepted_mask,
        )

        # (viii): drop padding, apply FOV.
        prob = final_out.prob[0, :, :h, :w]
        uncertainty = final_out.uncertainty[0, :, :h, :w]
        if fov_mask is not None:
            prob = prob * fov_mask
            uncertainty = uncertainty * fov_mask

        return TiledInferenceResult(
            prob=prob, uncertainty=uncertainty, num_tiles=len(tile_positions), tile_positions=tile_positions
        )
