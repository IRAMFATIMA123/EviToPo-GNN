"""Synthetic gap augmentation (Section 3.6).

"To supervise bridging directly, synthetic gaps are added in training:
with probability 0.5 per image, three to eight ground-truth branches of
width at most 3 px are degraded over 8-24 px by local blur and contrast
reduction, the label unchanged." The realised gaps have a median length of
15.8 px and a median width of 2.1 px (reference statistics from the paper;
this implementation's own realised distribution will vary with the data).

This is a fixed random augmentation with a logged seed per Section 4.3, so
``apply_synthetic_gaps`` takes an explicit ``np.random.Generator`` rather
than relying on global RNG state, and returns the exact pixel ranges that
were degraded (``GapRecord``) so they can be (a) used as positive-candidate
supervision for the link head (``losses/link_loss.py``) and (b) excluded
from, or compared against, the *evaluation*-time controlled gap test of
Section 6.2 (which uses seeds disjoint from these).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
from scipy.ndimage import distance_transform_edt, gaussian_filter

from evitopo_gnn.models.graph_builder import _walk_branches
from evitopo_gnn.models.skeleton import hard_skeletonize_and_prune, skeleton_degree_map


@dataclass
class GapRecord:
    branch_pixels: List[Tuple[int, int]]  # degraded pixel coordinates, (y, x)
    length_px: float
    width_px: float


def _thin_branches(vessel_mask: np.ndarray, max_width_px: float = 3.0):
    skeleton = hard_skeletonize_and_prune(vessel_mask.astype(np.float32), threshold=0.5, min_spur_len=5)
    degree = skeleton_degree_map(skeleton)
    branches = _walk_branches(skeleton, degree)
    dist = distance_transform_edt(vessel_mask)
    thin = []
    for branch in branches:
        if len(branch) < 10:
            continue
        widths = [2 * dist[y, x] for (y, x) in branch]
        if np.mean(widths) <= max_width_px:
            thin.append((branch, float(np.mean(widths))))
    return thin


def apply_synthetic_gaps(
    image: np.ndarray,          # [H, W, 3] float in [0, 1]
    vessel_mask: np.ndarray,    # [H, W] binary (NOT modified; label stays correct)
    rng: np.random.Generator,
    p: float = 0.5,
    min_gaps: int = 3,
    max_gaps: int = 8,
    min_len_px: int = 8,
    max_len_px: int = 24,
    max_width_px: float = 3.0,
    blur_sigma: float = 2.5,
    contrast_reduction: float = 0.55,
) -> Tuple[np.ndarray, List[GapRecord]]:
    """Returns ``(degraded_image, gap_records)``. ``vessel_mask`` is
    returned implicitly unchanged by the caller (this function never
    touches it) -- the whole point of the augmentation is a label that
    still says "vessel" where the image no longer visibly shows one."""
    if rng.random() > p:
        return image, []

    thin_branches = _thin_branches(vessel_mask, max_width_px=max_width_px)
    if not thin_branches:
        return image, []

    n_gaps = int(rng.integers(min_gaps, max_gaps + 1))
    n_gaps = min(n_gaps, len(thin_branches))
    chosen_idx = rng.choice(len(thin_branches), size=n_gaps, replace=False)

    out = image.copy()
    records = []
    for idx in chosen_idx:
        branch, mean_width = thin_branches[idx]
        gap_len = int(rng.integers(min_len_px, max_len_px + 1))
        gap_len = min(gap_len, len(branch))
        start = int(rng.integers(0, len(branch) - gap_len + 1))
        segment = branch[start : start + gap_len]

        ys = np.array([p[0] for p in segment])
        xs = np.array([p[1] for p in segment])
        y0, y1 = max(0, ys.min() - 4), min(image.shape[0], ys.max() + 5)
        x0, x1 = max(0, xs.min() - 4), min(image.shape[1], xs.max() + 5)

        patch = out[y0:y1, x0:x1].copy()
        blurred = gaussian_filter(patch, sigma=(blur_sigma, blur_sigma, 0))
        local_mean = patch.reshape(-1, patch.shape[-1]).mean(axis=0)
        low_contrast = local_mean + contrast_reduction * (blurred - local_mean)
        out[y0:y1, x0:x1] = low_contrast

        records.append(GapRecord(branch_pixels=segment, length_px=float(gap_len), width_px=mean_width))

    return out, records
