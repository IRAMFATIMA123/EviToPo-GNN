"""Split builders matching Section 4.1's leakage-controlled protocol.

Every dataset has a validation partition used for *all* checkpoint and
hyperparameter choices, never for model comparison:

* **STARE**: leave-one-out over 20 images; each fold's validation set holds
  out two of the remaining 19 training images (so the fold's test image is
  never used for validation either).
* **HRF**: k-fold with four held-out *training* images per fold used for
  validation.
* **CHASE_DB1**: two children (both eyes each) form the fixed validation
  set; the test unit is the child, not the image (Section 4.4), so both
  eyes of a child always stay in the same partition.
* **DRIVE / FIVES**: a fixed, logged train/val/test split.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple


@dataclass
class Split:
    train: List[str]
    val: List[str]
    test: List[str]


def fixed_train_val_test_split(
    stems: Sequence[str], val_frac: float = 0.1, test_frac: float = 0.2, seed: int = 0
) -> Split:
    """A fixed, seed-logged split for datasets with a conventional single
    train/test partition (DRIVE, FIVES). Shuffling is seeded for
    reproducibility; the resulting indices should be persisted (e.g. to
    ``results/data/splits/<dataset>_seed<seed>.json``) rather than
    regenerated per run, so that "identical splits" (Section 4.3) actually
    holds across methods and re-executions."""
    stems = list(stems)
    rng = random.Random(seed)
    rng.shuffle(stems)
    n = len(stems)
    n_test = int(round(n * test_frac))
    n_val = int(round(n * val_frac))
    test = stems[:n_test]
    val = stems[n_test : n_test + n_val]
    train = stems[n_test + n_val :]
    return Split(train=train, val=val, test=test)


def leave_one_out_folds(stems: Sequence[str], n_val: int = 2, seed: int = 0) -> List[Split]:
    """STARE-style leave-one-out: for each held-out test image, the
    remaining ``N-1`` images are further split into ``n_val`` validation
    images and ``N-1-n_val`` training images."""
    stems = list(stems)
    folds = []
    for i, test_stem in enumerate(stems):
        remaining = [s for s in stems if s != test_stem]
        rng = random.Random(seed + i)
        rng.shuffle(remaining)
        val = remaining[:n_val]
        train = remaining[n_val:]
        folds.append(Split(train=train, val=val, test=[test_stem]))
    return folds


def k_fold_subject_disjoint(
    subject_ids: Sequence[str], k: int, n_val_subjects: int = 1, seed: int = 0
) -> List[Split]:
    """HRF-style k-fold cross-validation at the *subject* level (so, unlike
    a plain image-level k-fold, no subject's images can leak across the
    train/val/test boundary of a fold). ``n_val_subjects`` held-out
    *training* subjects supply the validation set for each fold."""
    unique_subjects = sorted(set(subject_ids))
    rng = random.Random(seed)
    rng.shuffle(unique_subjects)
    fold_size = max(1, len(unique_subjects) // k)
    folds = []
    for fold_idx in range(k):
        test_subjects = set(unique_subjects[fold_idx * fold_size : (fold_idx + 1) * fold_size])
        remaining = [s for s in unique_subjects if s not in test_subjects]
        rng2 = random.Random(seed + fold_idx)
        rng2.shuffle(remaining)
        val_subjects = set(remaining[:n_val_subjects])
        train_subjects = set(remaining[n_val_subjects:])

        def stems_for(subjects, ids=subject_ids):
            return [s for s in ids if s in subjects]

        folds.append(
            Split(train=stems_for(train_subjects), val=stems_for(val_subjects), test=stems_for(test_subjects))
        )
    return folds


def chase_db1_child_split(stem_to_child: Dict[str, str], val_children: Sequence[str], test_children: Sequence[str]) -> Split:
    """CHASE_DB1: both eyes of a child stay in the same partition, and the
    test *unit* for statistics is the child (Section 4.4), not the image."""
    val_set, test_set = set(val_children), set(test_children)
    train, val, test = [], [], []
    for stem, child in stem_to_child.items():
        if child in test_set:
            test.append(stem)
        elif child in val_set:
            val.append(stem)
        else:
            train.append(stem)
    return Split(train=train, val=val, test=test)
