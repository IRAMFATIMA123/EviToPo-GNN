"""Lightweight augmentation pipeline operating on the ``dict`` sample that
:class:`~evitopo_gnn.data.datasets.RetinalVesselDataset` produces before
tensor conversion: ``{"image", "vessel_mask", "fov_mask", ...}`` with
``image`` ``[H, W, 3]`` float and the masks ``[H, W]`` float.

Random crop to the training patch size (512x512, Section 3.9), horizontal/
vertical flips, 90-degree rotations and mild colour jitter -- "standard
augmentation" (Section 4.3); nothing dataset-specific is assumed.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

import numpy as np


@dataclass
class TrainAugmentation:
    patch_size: int = 512
    hflip_p: float = 0.5
    vflip_p: float = 0.5
    rot90_p: float = 0.5
    brightness_jitter: float = 0.1
    contrast_jitter: float = 0.1
    seed: int | None = None

    def __post_init__(self):
        self._rng = random.Random(self.seed)

    def _random_crop(self, sample: dict) -> dict:
        h, w = sample["image"].shape[:2]
        ph = pw = self.patch_size
        if h < ph or w < pw:
            pad_h, pad_w = max(0, ph - h), max(0, pw - w)
            sample["image"] = np.pad(sample["image"], ((0, pad_h), (0, pad_w), (0, 0)))
            sample["vessel_mask"] = np.pad(sample["vessel_mask"], ((0, pad_h), (0, pad_w)))
            sample["fov_mask"] = np.pad(sample["fov_mask"], ((0, pad_h), (0, pad_w)))
            h, w = sample["image"].shape[:2]
        y0 = self._rng.randint(0, h - ph)
        x0 = self._rng.randint(0, w - pw)
        sample["image"] = sample["image"][y0 : y0 + ph, x0 : x0 + pw]
        sample["vessel_mask"] = sample["vessel_mask"][y0 : y0 + ph, x0 : x0 + pw]
        sample["fov_mask"] = sample["fov_mask"][y0 : y0 + ph, x0 : x0 + pw]
        return sample

    def __call__(self, sample: dict) -> dict:
        sample = self._random_crop(sample)

        if self._rng.random() < self.hflip_p:
            sample["image"] = np.ascontiguousarray(sample["image"][:, ::-1])
            sample["vessel_mask"] = np.ascontiguousarray(sample["vessel_mask"][:, ::-1])
            sample["fov_mask"] = np.ascontiguousarray(sample["fov_mask"][:, ::-1])
        if self._rng.random() < self.vflip_p:
            sample["image"] = np.ascontiguousarray(sample["image"][::-1, :])
            sample["vessel_mask"] = np.ascontiguousarray(sample["vessel_mask"][::-1, :])
            sample["fov_mask"] = np.ascontiguousarray(sample["fov_mask"][::-1, :])
        if self._rng.random() < self.rot90_p:
            k = self._rng.randint(1, 3)
            sample["image"] = np.ascontiguousarray(np.rot90(sample["image"], k))
            sample["vessel_mask"] = np.ascontiguousarray(np.rot90(sample["vessel_mask"], k))
            sample["fov_mask"] = np.ascontiguousarray(np.rot90(sample["fov_mask"], k))

        brightness = 1.0 + self._rng.uniform(-self.brightness_jitter, self.brightness_jitter)
        contrast = 1.0 + self._rng.uniform(-self.contrast_jitter, self.contrast_jitter)
        img = sample["image"] * brightness
        img = (img - img.mean()) * contrast + img.mean()
        sample["image"] = np.clip(img, 0.0, 1.0).astype(np.float32)
        return sample


@dataclass
class EvalTransform:
    """No augmentation; used for validation/test loaders."""

    def __call__(self, sample: dict) -> dict:
        return sample
