"""Dataset loaders for the five public benchmarks used in the paper
(Section 4.1): DRIVE [2], STARE [3], CHASE_DB1 [4], HRF [5] and FIVES [6].

Expected on-disk layout (after running the dataset's own download/prep
steps -- raw pixel data is not redistributed here):

    <root>/<dataset_name>/
        images/<stem>.<ext>          # colour fundus photographs
        manual/<stem>.<ext>          # binary vessel ground truth
        mask/<stem>.<ext>            # field-of-view (FOV) mask (optional;
                                      # derived from the image if absent)
        subject_id.csv               # optional, maps <stem> -> subject id
                                      # (used by CHASE_DB1's child-level split)

Every dataset is wrapped by one class, :class:`RetinalVesselDataset`,
configured through a small per-dataset spec in ``DATASET_REGISTRY`` so that
adding a sixth dataset only means adding one entry.
"""

from __future__ import annotations

import csv
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

try:
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None


@dataclass
class DatasetSpec:
    name: str
    image_dir: str = "images"
    manual_dir: str = "manual"
    mask_dir: str = "mask"
    image_glob: str = "*.*"
    has_fov_mask: bool = True
    subject_csv: Optional[str] = "subject_id.csv"


DATASET_REGISTRY = {
    "DRIVE": DatasetSpec(name="DRIVE"),
    "STARE": DatasetSpec(name="STARE", has_fov_mask=False),
    "CHASE_DB1": DatasetSpec(name="CHASE_DB1", subject_csv="subject_id.csv"),
    "HRF": DatasetSpec(name="HRF"),
    "FIVES": DatasetSpec(name="FIVES"),
}


def _list_stems(image_dir: Path, pattern: str) -> List[str]:
    return sorted(p.stem for p in image_dir.glob(pattern))


def _find_file(directory: Path, stem: str) -> Optional[Path]:
    matches = list(directory.glob(f"{stem}.*"))
    return matches[0] if matches else None


def _derive_fov_mask(image: np.ndarray, threshold: int = 20) -> np.ndarray:
    """Fallback FOV mask when the dataset provides none (e.g. STARE):
    foreground is simply "not near-black", which is adequate for the
    circular fundus camera vignette."""
    gray = image.mean(axis=-1) if image.ndim == 3 else image
    return (gray > threshold).astype(np.float32)


class RetinalVesselDataset(Dataset):
    """A single dataset / split, returning ``(image, vessel_mask, fov_mask, stem)``
    tensors. ``image``: ``[3, H, W]`` float in ``[0, 1]``. ``vessel_mask``,
    ``fov_mask``: ``[1, H, W]`` in ``{0, 1}``.
    """

    def __init__(
        self,
        root: str,
        dataset_name: str,
        stems: Optional[List[str]] = None,
        transform: Optional[Callable] = None,
    ):
        if Image is None:
            raise ImportError("Pillow is required to load image files (pip install Pillow)")
        if dataset_name not in DATASET_REGISTRY:
            raise ValueError(f"Unknown dataset '{dataset_name}'. Known: {list(DATASET_REGISTRY)}")
        self.spec = DATASET_REGISTRY[dataset_name]
        self.root = Path(root) / dataset_name
        self.image_dir = self.root / self.spec.image_dir
        self.manual_dir = self.root / self.spec.manual_dir
        self.mask_dir = self.root / self.spec.mask_dir
        self.transform = transform

        self.stems = stems if stems is not None else _list_stems(self.image_dir, self.spec.image_glob)
        self.subject_of = self._load_subject_map()

    def _load_subject_map(self) -> dict:
        subject_csv = self.spec.subject_csv
        if not subject_csv:
            return {s: s for s in self.stems}
        path = self.root / subject_csv
        mapping = {}
        if path.exists():
            with open(path, newline="") as f:
                for row in csv.DictReader(f):
                    mapping[row["stem"]] = row["subject_id"]
        for s in self.stems:
            mapping.setdefault(s, s)
        return mapping

    def __len__(self) -> int:
        return len(self.stems)

    def __getitem__(self, idx: int):
        stem = self.stems[idx]
        img_path = _find_file(self.image_dir, stem)
        manual_path = _find_file(self.manual_dir, stem)
        if img_path is None or manual_path is None:
            raise FileNotFoundError(f"Missing image or manual annotation for '{stem}' in {self.root}")

        image = np.array(Image.open(img_path).convert("RGB"), dtype=np.float32) / 255.0
        manual = np.array(Image.open(manual_path).convert("L"), dtype=np.float32)
        manual = (manual > 127).astype(np.float32)

        if self.spec.has_fov_mask:
            mask_path = _find_file(self.mask_dir, stem)
            if mask_path is not None:
                fov = np.array(Image.open(mask_path).convert("L"), dtype=np.float32)
                fov = (fov > 127).astype(np.float32)
            else:
                fov = _derive_fov_mask(image)
        else:
            fov = _derive_fov_mask(image)

        sample = {
            "image": image,            # [H, W, 3]
            "vessel_mask": manual,      # [H, W]
            "fov_mask": fov,            # [H, W]
            "stem": stem,
            "subject_id": self.subject_of.get(stem, stem),
        }
        if self.transform is not None:
            sample = self.transform(sample)

        image_t = torch.from_numpy(np.ascontiguousarray(sample["image"])).permute(2, 0, 1).float()
        vessel_t = torch.from_numpy(np.ascontiguousarray(sample["vessel_mask"])).unsqueeze(0).float()
        fov_t = torch.from_numpy(np.ascontiguousarray(sample["fov_mask"])).unsqueeze(0).float()
        return image_t, vessel_t, fov_t, sample["stem"]
