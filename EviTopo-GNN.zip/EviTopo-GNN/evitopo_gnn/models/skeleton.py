"""Soft and hard skeletonisation (Section 3.4, and the clDice loss [18]).

``soft_skeletonize`` is the differentiable iterative min-/max-pooling
skeleton approximation of Shit et al. (2021) used both inside the clDice
loss and to obtain the coarse probability map's soft skeleton that seeds
graph construction.

``hard_skeletonize_and_prune`` binarises that soft skeleton at 0.5, thins
it to a one-pixel-wide curve with ``skimage.morphology.skeletonize``, and
prunes spurs shorter than ``min_spur_len`` pixels (default 10 px, Section
3.4), returning a boolean mask plus a lightweight graph-friendly pixel
list. It is intentionally *not* used inside the training loop in a way
that requires gradients -- Section 3.9 states explicitly that the
binarised skeleton, node positions and endpoint/junction selection carry
no gradient.
"""

from __future__ import annotations

from typing import Tuple

import numpy as np
import torch
import torch.nn.functional as F

try:
    from skimage.morphology import skeletonize as _sk_skeletonize
except Exception:  # pragma: no cover - optional dependency at import time
    _sk_skeletonize = None


def _soft_erode(x: torch.Tensor) -> torch.Tensor:
    p1 = -F.max_pool2d(-x, (3, 1), stride=1, padding=(1, 0))
    p2 = -F.max_pool2d(-x, (1, 3), stride=1, padding=(0, 1))
    return torch.min(p1, p2)


def _soft_dilate(x: torch.Tensor) -> torch.Tensor:
    return F.max_pool2d(x, (3, 3), stride=1, padding=1)


def _soft_open(x: torch.Tensor) -> torch.Tensor:
    return _soft_dilate(_soft_erode(x))


def soft_skeletonize(prob: torch.Tensor, num_iter: int = 10) -> torch.Tensor:
    """Differentiable soft-skeleton of a probability / mask map.

    Parameters
    ----------
    prob: torch.Tensor
        ``[B, 1, H, W]`` values in ``[0, 1]``.
    num_iter: int
        Number of erosion steps (clDice default: 10).

    Returns
    -------
    torch.Tensor
        ``[B, 1, H, W]`` soft skeleton, same value range.
    """
    img1 = _soft_open(prob)
    skel = F.relu(prob - img1)
    img = prob
    for _ in range(num_iter):
        img = _soft_erode(img)
        img1 = _soft_open(img)
        delta = F.relu(img - img1)
        skel = skel + F.relu(delta - skel * delta)
    return skel


def _prune_spurs(skeleton: np.ndarray, min_spur_len: int = 10) -> np.ndarray:
    """Iteratively remove branches (spurs) shorter than ``min_spur_len``
    pixels, following endpoints inward until a junction is reached."""
    skel = skeleton.copy()

    def neighbors(y, x):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                ny, nx = y + dy, x + dx
                if 0 <= ny < skel.shape[0] and 0 <= nx < skel.shape[1] and skel[ny, nx]:
                    yield ny, nx

    changed = True
    while changed:
        changed = False
        ys, xs = np.nonzero(skel)
        degree = {}
        for y, x in zip(ys, xs):
            degree[(y, x)] = sum(1 for _ in neighbors(y, x))
        endpoints = [p for p, d in degree.items() if d == 1]
        for ep in endpoints:
            path = [ep]
            prev = None
            cur = ep
            while True:
                nbrs = [n for n in neighbors(*cur) if n != prev]
                d = degree.get(cur, 0)
                if d != 1 and cur != ep:
                    break
                if len(nbrs) != 1:
                    break
                prev, cur = cur, nbrs[0]
                path.append(cur)
                if degree.get(cur, 0) != 2:
                    break
                if len(path) > min_spur_len:
                    break
            if len(path) < min_spur_len and (degree.get(path[-1], 0) >= 3 or len(path) == 1):
                for (y, x) in path[:-1]:
                    skel[y, x] = False
                changed = True
    return skel


def hard_skeletonize_and_prune(
    prob_map: torch.Tensor | np.ndarray, threshold: float = 0.5, min_spur_len: int = 10
) -> np.ndarray:
    """Binarise at ``threshold``, thin to one pixel, prune spurs shorter
    than ``min_spur_len`` pixels. Operates per-image on numpy arrays
    (no gradient; see module docstring)."""
    if isinstance(prob_map, torch.Tensor):
        arr = prob_map.detach().cpu().numpy()
    else:
        arr = prob_map
    arr = np.squeeze(arr)
    binary = arr >= threshold
    if _sk_skeletonize is not None:
        thin = _sk_skeletonize(binary)
    else:  # pragma: no cover - fallback without scikit-image
        thin = binary
    pruned = _prune_spurs(thin, min_spur_len=min_spur_len)
    return pruned


def skeleton_degree_map(skeleton: np.ndarray) -> np.ndarray:
    """8-connected degree of every skeleton pixel (0 where background)."""
    deg = np.zeros_like(skeleton, dtype=np.int32)
    ys, xs = np.nonzero(skeleton)
    h, w = skeleton.shape
    for y, x in zip(ys, xs):
        count = 0
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and skeleton[ny, nx]:
                    count += 1
        deg[y, x] = count
    return deg
