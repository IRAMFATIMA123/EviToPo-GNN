"""Evidential gap-link prediction (Section 3.6, Eq. 10-11).

For every candidate gap edge, a link head ``psi`` outputs two-class
evidence from the refined endpoint features and the edge feature, giving a
bridging probability ``pi_ij`` and a link uncertainty ``u_ij`` (Eq. 10):

    alpha_lnk = softplus( psi([h_i' || h_j' || f_ij]) ) + 1
    pi_ij = alpha_1^lnk / S^lnk,   u_ij = 2 / S^lnk

and a gap is bridged when the probability is high and the link
uncertainty is low (Eq. 11):

    bridge(i, j)  <=>  pi_ij > 0.5  AND  u_ij < tau_link

At most one gap is accepted per endpoint: the candidate with the largest
``pi_ij`` that satisfies Eq. (11).

Training vs. inference (Section 3.6): Eq. (11) and the one-gap-per-endpoint
rule describe the *inference* path only. During training every candidate is
scored and the link loss is averaged over all of them (see
``losses/link_loss.py``); no candidate is thresholded or discarded, and the
link-prior map (Section 3.7) is rasterised as a soft superposition over all
candidates weighted by their bridging probability.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class LinkPredictionOutput:
    alpha: torch.Tensor   # [E_gap, 2] Dirichlet strengths
    pi: torch.Tensor      # [E_gap] bridging probability
    u: torch.Tensor       # [E_gap] link uncertainty


class EvidentialLinkPredictor(nn.Module):
    def __init__(self, node_dim: int, edge_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(2 * node_dim + edge_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, 2),
        )

    def forward(self, h_prime: torch.Tensor, gap_edge_index: torch.Tensor, gap_edge_emb: torch.Tensor) -> LinkPredictionOutput:
        if gap_edge_index.shape[1] == 0:
            z = torch.zeros(0, 2, device=h_prime.device)
            return LinkPredictionOutput(alpha=z, pi=z[:, 0], u=z[:, 0])
        src, dst = gap_edge_index[0], gap_edge_index[1]
        feat = torch.cat([h_prime[src], h_prime[dst], gap_edge_emb], dim=-1)
        nu = self.mlp(feat)
        evidence = F.softplus(nu)
        alpha = evidence + 1.0
        strength = alpha.sum(dim=-1)
        pi = alpha[:, 1] / strength
        u = 2.0 / strength
        return LinkPredictionOutput(alpha=alpha, pi=pi, u=u)


def decide_bridges(
    gap_edge_index: torch.Tensor,
    pi: torch.Tensor,
    u: torch.Tensor,
    node_type: torch.Tensor,
    node_is_endpoint_value: int,
    tau_link: float = 0.5,
) -> torch.Tensor:
    """Inference-time bridge decision (Eq. 11) with the one-gap-per-endpoint
    rule. Returns a boolean mask over candidate gap edges."""
    if gap_edge_index.shape[1] == 0:
        return torch.zeros(0, dtype=torch.bool, device=pi.device)

    accept = (pi > 0.5) & (u < tau_link)
    if not torch.any(accept):
        return accept

    src, dst = gap_edge_index[0], gap_edge_index[1]
    is_endpoint = node_type == node_is_endpoint_value

    final = accept.clone()
    # Enforce "at most one accepted gap per endpoint" for every node that is
    # an endpoint and touches at least one accepted candidate, keeping only
    # the highest-pi candidate incident to it.
    touched_nodes = torch.unique(torch.cat([src[accept], dst[accept]]))
    for node_id in touched_nodes.tolist():
        if not bool(is_endpoint[node_id]):
            continue
        incident = ((src == node_id) | (dst == node_id)) & accept
        if incident.sum() <= 1:
            continue
        idxs = torch.nonzero(incident, as_tuple=False).squeeze(-1)
        best = idxs[torch.argmax(pi[idxs])]
        drop = idxs[idxs != best]
        final[drop] = False
    return final
