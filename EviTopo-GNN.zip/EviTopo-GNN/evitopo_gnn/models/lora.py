"""Low-rank adaptation (LoRA) for the frozen ViT branch.

Implements Eq. (2) of the paper:

    W_q' = W_q + B_q A_q ,   W_v' = W_v + B_v A_v ,
    B_* in R^{C x r},  A_* in R^{r x C}

Only the adapter matrices ``A`` and ``B`` are trained; the base projection
``W`` (and bias, if any) is frozen. This module is a drop-in replacement
for ``nn.Linear`` so it can be substituted into the query/value projections
of any pretrained attention block (e.g. the RETFound ViT-L/16 checkpoint)
without touching the rest of the architecture.
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn


class LoRALinear(nn.Module):
    """``nn.Linear`` augmented with a frozen base weight and a trainable
    low-rank residual ``B @ A``.

    Parameters
    ----------
    base: nn.Linear
        The pretrained projection to adapt. Its parameters are frozen.
    rank: int
        LoRA rank ``r`` (paper default ``r = 8``).
    alpha: float
        LoRA scaling factor; the residual is scaled by ``alpha / rank``.
        Defaults to ``rank`` so the initial effective scale is 1.
    """

    def __init__(self, base: nn.Linear, rank: int = 8, alpha: float | None = None):
        super().__init__()
        if rank <= 0:
            raise ValueError("LoRA rank must be positive")
        out_features, in_features = base.weight.shape
        self.base = base
        for p in self.base.parameters():
            p.requires_grad_(False)

        self.rank = rank
        self.alpha = float(alpha) if alpha is not None else float(rank)
        self.scaling = self.alpha / self.rank

        # A: R^{r x C_in}, B: R^{C_out x r}  ->  B @ A in R^{C_out x C_in}
        self.lora_A = nn.Parameter(torch.zeros(rank, in_features))
        self.lora_B = nn.Parameter(torch.zeros(out_features, rank))
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)  # residual starts at exactly zero

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base_out = self.base(x)
        delta = (x @ self.lora_A.t()) @ self.lora_B.t()
        return base_out + self.scaling * delta

    def extra_repr(self) -> str:  # pragma: no cover - cosmetic
        return f"rank={self.rank}, alpha={self.alpha}"


def inject_lora(attn_module: nn.Module, rank: int = 8, targets=("q_proj", "v_proj")) -> nn.Module:
    """Replace named ``nn.Linear`` sub-modules of ``attn_module`` with
    :class:`LoRALinear` wrappers in place, following Eq. (2)'s choice of
    adapting the query and value projections only.
    """
    for name in targets:
        if hasattr(attn_module, name) and isinstance(getattr(attn_module, name), nn.Linear):
            setattr(attn_module, name, LoRALinear(getattr(attn_module, name), rank=rank))
    return attn_module
