"""Uncertainty-gated graph neural network (Section 3.5, Eq. 7-9).

Edge-aware graph attention refines node features ``h_i`` using edge
features ``f_ij``, learnable projections ``Theta`` / ``Theta_e`` and
attention vector ``zeta`` (Eq. 7):

    eps_ij  = LeakyReLU( zeta^T [Theta h_i || Theta h_j || Theta_e f_ij] )
    beta_ij = softmax_j( eps_ij )

A reliability gate lets confident nodes speak louder while edge evidence
suppresses implausible gap edges (Eq. 8):

    g_ij = (1 - sg(U_j)^gamma) * sigma(v^T f_ij)

where ``sg`` is stop-gradient, so the uncertainty term uses the *detached*
coarse uncertainty of the source node ``j``, ``v`` is learnable and
``gamma`` is the gate exponent. The node update combines the gated,
attention-weighted messages with a two-layer MLP (Eq. 9):

    h_i' = phi( h_i + sum_{j in N_i} beta_ij * g_ij * Theta h_j )

The gate reweights messages but never skips them (no hard masking), so a
confident trunk's evidence can still reach a faint branch many pixels away.

Edge-direction convention used throughout this module: ``edge_index[0]`` is
the *source* (sender, ``j``) and ``edge_index[1]`` is the *target*
(receiver, ``i``), i.e. message flow is ``source -> target``.

Implementation note: Eq. (8)'s ``v^T f_ij`` is applied to the *embedded*
edge feature (after ``Theta_e``), rather than to the raw edge attributes,
because observed and candidate-gap edges have different raw feature
dimensionalities (Section 3.4) and must share a common space before they
can be gated and attended over jointly. This is a stated implementation
choice, not part of the paper's equations.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from evitopo_gnn.utils.scatter_ops import scatter_add, scatter_softmax


class EdgeFeatureEncoder(nn.Module):
    """Projects the two heterogeneous raw edge-feature spaces (observed
    edges: length/type/prob/uncertainty/gradient; candidate gap edges:
    compatibility ``c_ij``) into one shared embedding space."""

    def __init__(self, obs_dim: int, gap_dim: int, edge_dim: int):
        super().__init__()
        self.obs_enc = nn.Sequential(nn.Linear(obs_dim, edge_dim), nn.ReLU(inplace=True))
        self.gap_enc = nn.Sequential(nn.Linear(gap_dim, edge_dim), nn.ReLU(inplace=True))
        self.edge_dim = edge_dim

    def forward(self, obs_attr: torch.Tensor, gap_attr: torch.Tensor) -> torch.Tensor:
        parts = []
        if obs_attr.shape[0] > 0:
            parts.append(self.obs_enc(obs_attr))
        if gap_attr.shape[0] > 0:
            parts.append(self.gap_enc(gap_attr))
        if not parts:
            return torch.zeros(0, self.edge_dim, device=obs_attr.device)
        return torch.cat(parts, dim=0)


#: Gate ablation variants (Section 6.1, Table 5 rows A5/A5a/A5b/A9g), selected
#: via the ``gate_mode`` constructor argument so they are runnable from a
#: config rather than requiring a code fork:
#:   "full"             A5/A9  -- g_ij = (1 - sg(U_j)^gamma) * sigma(v^T f_ij)
#:   "uncertainty_only"  A5a   -- g_ij = (1 - sg(U_j)^gamma)
#:   "edge_only"         A5b / A9g -- g_ij = sigma(v^T f_ij)  (uncertainty term
#:                                     replaced by the constant 1)
GATE_MODES = ("full", "uncertainty_only", "edge_only")


class UncertaintyGatedGNNLayer(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, edge_dim: int, gate_exponent: float = 1.0, gate_mode: str = "full"):
        super().__init__()
        if gate_mode not in GATE_MODES:
            raise ValueError(f"gate_mode must be one of {GATE_MODES}, got {gate_mode!r}")
        self.gate_mode = gate_mode
        self.theta = nn.Linear(in_dim, out_dim, bias=False)
        self.theta_e = nn.Linear(edge_dim, out_dim, bias=False)
        self.attn_vec = nn.Parameter(torch.empty(3 * out_dim))
        self.gate_vec = nn.Parameter(torch.empty(out_dim))
        self.gamma = gate_exponent
        self.leaky_relu = nn.LeakyReLU(0.2)
        self.mlp = nn.Sequential(
            nn.Linear(out_dim, out_dim), nn.ReLU(inplace=True), nn.Linear(out_dim, out_dim)
        )
        self.out_dim = out_dim
        self.in_dim = in_dim
        self.skip = None if in_dim == out_dim else nn.Linear(in_dim, out_dim, bias=False)
        nn.init.xavier_uniform_(self.attn_vec.view(1, -1))
        nn.init.xavier_uniform_(self.gate_vec.view(1, -1))

    def forward(
        self,
        h: torch.Tensor,                 # [N, in_dim]
        edge_index: torch.Tensor,        # [2, E] (source=j, target=i)
        edge_emb: torch.Tensor,          # [E, edge_dim]
        node_uncertainty: torch.Tensor,  # [N, 1] detached-safe (we detach again defensively)
    ) -> torch.Tensor:
        n = h.shape[0]
        if edge_index.shape[1] == 0:
            identity = h if self.skip is None else self.skip(h)
            return self.mlp(identity)

        src, dst = edge_index[0], edge_index[1]
        theta_h = self.theta(h)                  # [N, out_dim]
        theta_e_f = self.theta_e(edge_emb)        # [E, out_dim]

        hi = theta_h[dst]
        hj = theta_h[src]
        cat = torch.cat([hi, hj, theta_e_f], dim=-1)  # [E, 3*out_dim]
        eps = self.leaky_relu((cat * self.attn_vec).sum(dim=-1))  # [E]
        beta = scatter_softmax(eps, dst, num_nodes=n)             # [E]

        u_source = node_uncertainty[src].squeeze(-1).detach()  # stop-gradient (sg)
        uncertainty_term = 1.0 - u_source.clamp(0, 1).pow(self.gamma)
        edge_term = torch.sigmoid((theta_e_f * self.gate_vec).sum(dim=-1))
        if self.gate_mode == "full":
            gate = uncertainty_term * edge_term  # g_ij, Eq. (8)
        elif self.gate_mode == "uncertainty_only":  # A5a
            gate = uncertainty_term
        else:  # "edge_only": A5b / A9g
            gate = edge_term

        messages = beta.unsqueeze(-1) * gate.unsqueeze(-1) * theta_h[src]  # [E, out_dim]
        aggregated = scatter_add(messages, dst, num_nodes=n)               # [N, out_dim]

        identity = h if self.skip is None else self.skip(h)
        return self.mlp(identity + aggregated)


class UncertaintyGatedGNN(nn.Module):
    """Stacks ``num_layers`` :class:`UncertaintyGatedGNNLayer` blocks."""

    def __init__(
        self,
        node_dim: int,
        edge_dim: int = 64,
        hidden_dim: int = 256,
        num_layers: int = 2,
        gate_exponent: float = 1.0,
        gate_mode: str = "full",
        obs_edge_raw_dim: int = 5,
        gap_edge_raw_dim: int = 1,
    ):
        super().__init__()
        self.edge_encoder = EdgeFeatureEncoder(obs_edge_raw_dim, gap_edge_raw_dim, edge_dim)
        dims = [node_dim] + [hidden_dim] * num_layers
        self.layers = nn.ModuleList(
            [
                UncertaintyGatedGNNLayer(dims[i], dims[i + 1], edge_dim, gate_exponent, gate_mode)
                for i in range(num_layers)
            ]
        )

    def forward(self, graph) -> torch.Tensor:
        """``graph``: a :class:`~evitopo_gnn.models.graph_builder.VesselGraph`.
        Returns refined node features ``h'`` of shape ``[N, hidden_dim]``,
        computed over ``E_obs U E_gap`` jointly (all *candidate* gap edges
        participate in message passing; which ones are actually *bridged*
        is decided downstream by the link head, Section 3.6)."""
        h = graph.node_feat
        edge_index = torch.cat([graph.obs_edge_index, graph.gap_edge_index], dim=1)
        edge_emb = self.edge_encoder(graph.obs_edge_attr, graph.gap_edge_attr)
        for layer in self.layers:
            h = layer(h, edge_index, edge_emb, graph.node_uncertainty)
        return h
