"""Projection head for the topology-aware contrastive loss (Section 3.8).

A small projection head on the decoder features produces L2-normalised
pixel embeddings ``z``; the sampling strategy, positive/negative mining and
the InfoNCE-style loss itself (Eq. 13-14) live in
``losses/contrastive_loss.py`` since they require ground-truth branch
labels that are only available during training.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class ContrastiveProjectionHead(nn.Module):
    def __init__(self, in_channels: int, proj_dim: int = 128, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, hidden_dim, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dim, proj_dim, 1),
        )

    def forward(self, decoder_feat: torch.Tensor) -> torch.Tensor:
        """``decoder_feat``: ``[B, C, H, W]``. Returns L2-normalised
        embeddings ``[B, proj_dim, H, W]``."""
        z = self.net(decoder_feat)
        return F.normalize(z, dim=1)
