"""Graph-to-pixel decoder (Section 3.7, Eq. 12).

Refined node features are splatted back to the image grid with Gaussian
kernels whose width ``omega_i`` is proportional to the local vessel width:

    R(x) = sum_{i in V} h_i' * exp( -||x - x_i||^2 / (2 * omega_i^2) )

and gap edges are rasterised as soft line segments weighted by ``pi_ij`` to
form the link-prior map ``Gamma``. The decoder concatenates ``R``,
``Gamma`` and the full-resolution skip features, applies two residual
blocks and a second evidential head, returning the final ``P`` and ``U``.

Training-time vs. inference-time ``Gamma`` (Section 3.6/3.7): at training
the superposition runs over *every* candidate -- the map is the pixel-wise
*maximum*, over candidate edges, of that edge's bridging probability times
its soft line kernel, so the gradient w.r.t. ``pi_ij`` is defined for
accepted and rejected candidates alike. At inference it is restricted to
the gaps actually accepted by Eq. (11). Callers select which behaviour to
use via the ``accepted_mask`` argument to :func:`rasterize_gap_edges`
(``None`` => use every candidate, i.e. the training-time path).
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from evitopo_gnn.models.evidential_head import EvidentialHead, EvidentialOutput


def gaussian_splat(
    node_pos: torch.Tensor,   # [N, 2] (y, x)
    node_feat: torch.Tensor,  # [N, C]
    sigma: torch.Tensor,      # [N] or [N, 1], proportional to local vessel width
    height: int,
    width: int,
    min_sigma: float = 1.0,
    max_radius: int = 24,
) -> torch.Tensor:
    """Eq. (12). Returns ``R``: ``[C, H, W]``."""
    device = node_feat.device
    c = node_feat.shape[1]
    r_out = torch.zeros(c, height, width, device=device)
    if node_pos.shape[0] == 0:
        return r_out
    sigma = sigma.view(-1).clamp(min=min_sigma)

    for i in range(node_pos.shape[0]):
        cy, cx = node_pos[i, 0].item(), node_pos[i, 1].item()
        s = sigma[i]
        radius = min(int(3 * s.item()) + 1, max_radius)
        y0, y1 = max(0, int(cy) - radius), min(height, int(cy) + radius + 1)
        x0, x1 = max(0, int(cx) - radius), min(width, int(cx) + radius + 1)
        if y1 <= y0 or x1 <= x0:
            continue
        yy, xx = torch.meshgrid(
            torch.arange(y0, y1, device=device, dtype=torch.float32),
            torch.arange(x0, x1, device=device, dtype=torch.float32),
            indexing="ij",
        )
        d2 = (yy - cy) ** 2 + (xx - cx) ** 2
        g = torch.exp(-d2 / (2 * s ** 2))
        r_out[:, y0:y1, x0:x1] += node_feat[i].view(c, 1, 1) * g.unsqueeze(0)
    return r_out


def _soft_line_kernel_patch(p0, p1, height, width, sigma: float = 1.5, margin: int = 6):
    """Returns ``(kernel_patch, y0, y1, x0, x1)``: a soft raster of the
    segment ``p0 -> p1`` restricted to its bounding box (plus margin)."""
    y0 = int(max(0, min(p0[0].item(), p1[0].item()) - margin))
    y1 = int(min(height, max(p0[0].item(), p1[0].item()) + margin + 1))
    x0 = int(max(0, min(p0[1].item(), p1[1].item()) - margin))
    x1 = int(min(width, max(p0[1].item(), p1[1].item()) + margin + 1))
    if y1 <= y0 or x1 <= x0:
        return None, 0, 0, 0, 0
    device = p0.device
    yy, xx = torch.meshgrid(
        torch.arange(y0, y1, device=device, dtype=torch.float32),
        torch.arange(x0, x1, device=device, dtype=torch.float32),
        indexing="ij",
    )
    seg = (p1 - p0).float()
    seg_len2 = (seg ** 2).sum().clamp(min=1e-6)
    pts = torch.stack([yy - p0[0], xx - p0[1]], dim=-1)
    t = (pts * seg.view(1, 1, 2)).sum(-1) / seg_len2
    t = t.clamp(0.0, 1.0)
    proj = p0.view(1, 1, 2) + t.unsqueeze(-1) * seg.view(1, 1, 2)
    dist2 = ((torch.stack([yy, xx], dim=-1) - proj) ** 2).sum(-1)
    kernel = torch.exp(-dist2 / (2 * sigma ** 2))
    return kernel, y0, y1, x0, x1


def rasterize_gap_edges(
    node_pos: torch.Tensor,        # [N, 2]
    gap_edge_index: torch.Tensor,  # [2, E_gap]
    pi: torch.Tensor,              # [E_gap] bridging probability
    height: int,
    width: int,
    accepted_mask: torch.Tensor | None = None,
    line_sigma: float = 1.5,
) -> torch.Tensor:
    """Builds the link-prior map ``Gamma`` (``[1, H, W]``) as the pixel-wise
    maximum, over (accepted or all) candidate edges, of ``pi_ij`` times a
    soft line kernel along the segment."""
    device = node_pos.device
    e = gap_edge_index.shape[1]
    if e == 0:
        return torch.zeros(1, height, width, device=device)
    indices = range(e) if accepted_mask is None else torch.nonzero(accepted_mask, as_tuple=False).squeeze(-1).tolist()
    if isinstance(indices, int):
        indices = [indices]

    # Built out-of-place (each edge's contribution padded into a full-size
    # canvas, then combined with a single non-mutating `amax`) rather than
    # via repeated in-place slice writes: autograd cannot safely backprop
    # through "read old value, overwrite it with max(old, new)" when old and
    # new share storage, since the pre-overwrite value is exactly what the
    # max's backward needs. The number of (candidate or accepted) gap edges
    # per image is small (Section 3.4: k_gap per source node), so materialising
    # one full-size canvas per edge is cheap relative to the splat in
    # `gaussian_splat`, which instead stays windowed for memory reasons.
    canvases = []
    for idx in indices:
        i, j = gap_edge_index[0, idx].item(), gap_edge_index[1, idx].item()
        kernel, y0, y1, x0, x1 = _soft_line_kernel_patch(
            node_pos[i], node_pos[j], height, width, sigma=line_sigma
        )
        if kernel is None:
            continue
        weighted = pi[idx] * kernel
        canvas = F.pad(weighted, (x0, width - x1, y0, height - y1))
        canvases.append(canvas)

    if not canvases:
        return torch.zeros(1, height, width, device=device)
    gamma = torch.stack(canvases, dim=0).amax(dim=0, keepdim=False)
    return gamma.unsqueeze(0)


class ResidualConvBlock(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(channels)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(channels)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.act(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return self.act(out + x)


class GraphToPixelDecoder(nn.Module):
    """``R`` (graph features splatted back), ``Gamma`` (link-prior map) and
    the full-resolution skip features are concatenated, passed through two
    residual blocks, and mapped to the final evidential output ``(P, U)``.
    """

    def __init__(self, node_feat_dim: int, skip_channels: int, decoder_channels: int = 128):
        super().__init__()
        self.in_proj = nn.Conv2d(node_feat_dim + 1 + skip_channels, decoder_channels, 1)
        self.block1 = ResidualConvBlock(decoder_channels)
        self.block2 = ResidualConvBlock(decoder_channels)
        self.final_head = EvidentialHead(decoder_channels)
        self.node_feat_dim = node_feat_dim

    def forward(
        self,
        node_pos: torch.Tensor,
        node_feat: torch.Tensor,
        node_width: torch.Tensor,
        gap_edge_index: torch.Tensor,
        gap_pi: torch.Tensor,
        skip_features: torch.Tensor,  # [1, skip_ch, H, W] (batch size 1 per-image graph)
        accepted_mask: torch.Tensor | None = None,
    ) -> tuple[EvidentialOutput, torch.Tensor, torch.Tensor, torch.Tensor]:
        _, _, h, w = skip_features.shape
        r_map = gaussian_splat(node_pos, node_feat, node_width, h, w)
        gamma_map = rasterize_gap_edges(node_pos, gap_edge_index, gap_pi, h, w, accepted_mask=accepted_mask)
        fused = torch.cat([r_map.unsqueeze(0), gamma_map.unsqueeze(0), skip_features], dim=1)
        x = self.in_proj(fused)
        x = self.block1(x)
        x = self.block2(x)
        out = self.final_head(x)
        return out, r_map, gamma_map, x
