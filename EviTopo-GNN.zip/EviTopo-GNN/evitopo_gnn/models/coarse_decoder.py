"""Top-down decoder that turns the hybrid encoder's multi-scale fused
features into one full-resolution feature map (Section 3.2-3.3).

This module is not separately named in the paper -- it is the "decoded
features" that Section 3.3 says are mapped to coarse evidential logits by
a 1x1 convolution, and that Section 3.4 says graph nodes sample their
fused feature from. It is implemented here as a standard FPN-style
top-down path: start from the coarsest fused scale, progressively upsample
and merge with the next finer fused scale, and finally merge with the
full-resolution CNN skip feature that bypassed cross-attention fusion.
"""

from __future__ import annotations

from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F


class CoarseDecoder(nn.Module):
    def __init__(self, fused_channels: int, full_res_channels: int, out_channels: int, num_scales: int = 4):
        super().__init__()
        self.merge_convs = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(fused_channels * 2, fused_channels, 3, padding=1),
                    nn.BatchNorm2d(fused_channels),
                    nn.ReLU(inplace=True),
                )
                for _ in range(num_scales - 1)
            ]
        )
        self.final_merge = nn.Sequential(
            nn.Conv2d(fused_channels + full_res_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
        self.out_channels = out_channels

    def forward(self, fused_scales: List[torch.Tensor], full_res: torch.Tensor) -> torch.Tensor:
        """``fused_scales``: finest-to-coarsest ordered list (as produced by
        :class:`HybridViTCNNEncoder`). ``full_res``: the CNN stem skip
        feature at the input resolution."""
        x = fused_scales[-1]
        for i in range(len(fused_scales) - 2, -1, -1):
            x = F.interpolate(x, size=fused_scales[i].shape[-2:], mode="bilinear", align_corners=False)
            x = torch.cat([x, fused_scales[i]], dim=1)
            x = self.merge_convs[len(fused_scales) - 2 - i](x)
        x = F.interpolate(x, size=full_res.shape[-2:], mode="bilinear", align_corners=False)
        x = torch.cat([x, full_res], dim=1)
        return self.final_merge(x)
