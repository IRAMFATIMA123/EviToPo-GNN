"""Hybrid ViT-CNN encoder (Section 3.2).

Global branch
-------------
A ViT-L/16 initialised from the RETFound retinal foundation checkpoint [22].
Its backbone weights are frozen; LoRA modules (Eq. 2, see ``lora.py``) are
inserted into the query/value projections of every attention block, so only
the adapters are trained. Tokens from blocks ``{6, 12, 18, 24}`` are
reshaped to spatial maps and resampled to the convolutional scales.

Local branch
------------
A residual CNN whose first stage stays at full input resolution, preserving
one- to two-pixel capillaries that a patch embedding would discard.

Fusion
------
At each shared scale the convolutional features query the transformer
features through windowed cross-attention (Eq. 3):

    F_fus = softmax(Q_c K_v^T / sqrt(C)) V_v ,
    Q_c = F_cnn W_Q ,  K_v, V_v = F_vit W_K, W_V

and the full-resolution features bypass fusion, reaching the decoder
through a skip connection.

Notes on scale
--------------
The default configuration (``ViTConfig`` defaults) mirrors ViT-L/16
(embed_dim=1024, depth=24, heads=16, mlp_ratio=4) which is what gives the
~342.6M total / 37.9M trainable parameter budget quoted in Section 6.1.
For unit tests and quick smoke checks, pass a much smaller config -- the
module is agnostic to the exact sizes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

from evitopo_gnn.models.lora import LoRALinear


# --------------------------------------------------------------------------- #
# ViT branch
# --------------------------------------------------------------------------- #

@dataclass
class ViTConfig:
    image_size: int = 512
    patch_size: int = 16
    embed_dim: int = 1024
    depth: int = 24
    num_heads: int = 16
    mlp_ratio: float = 4.0
    lora_rank: int = 8
    tap_blocks: Sequence[int] = field(default_factory=lambda: (6, 12, 18, 24))
    in_chans: int = 3


class MultiHeadSelfAttention(nn.Module):
    """Self-attention with separate q/k/v projections so LoRA (Eq. 2) can be
    injected into exactly the query and value paths, as specified."""

    def __init__(self, dim: int, num_heads: int):
        super().__init__()
        assert dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5

        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        self.out_proj = nn.Linear(dim, dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, n, c = x.shape
        q = self.q_proj(x).reshape(b, n, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).reshape(b, n, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).reshape(b, n, self.num_heads, self.head_dim).transpose(1, 2)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        out = attn @ v
        out = out.transpose(1, 2).reshape(b, n, c)
        return self.out_proj(out)

    def apply_lora(self, rank: int) -> None:
        """Freeze the base projections and wrap q/v with LoRA (Eq. 2)."""
        self.k_proj.weight.requires_grad_(False)
        if self.k_proj.bias is not None:
            self.k_proj.bias.requires_grad_(False)
        self.q_proj = LoRALinear(self.q_proj, rank=rank)
        self.v_proj = LoRALinear(self.v_proj, rank=rank)


class MLP(nn.Module):
    def __init__(self, dim: int, mlp_ratio: float):
        super().__init__()
        hidden = int(dim * mlp_ratio)
        self.fc1 = nn.Linear(dim, hidden)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden, dim)
        # Frozen: only the backbone's transformer MLPs are frozen along with
        # everything else that is not a LoRA adapter.
        for p in self.parameters():
            p.requires_grad_(False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.act(self.fc1(x)))


class ViTBlock(nn.Module):
    def __init__(self, dim: int, num_heads: int, mlp_ratio: float, lora_rank: int):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = MultiHeadSelfAttention(dim, num_heads)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = MLP(dim, mlp_ratio)

        # Freeze everything in this block, then re-enable only the LoRA
        # adapters that `apply_lora` introduces.
        for p in self.parameters():
            p.requires_grad_(False)
        self.attn.apply_lora(lora_rank)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class RETFoundViT(nn.Module):
    """ViT-L/16 backbone with LoRA adapters.

    ``load_retfound_checkpoint`` loads the public ``RETFound_cfp_weights``
    masked-autoencoder checkpoint [22] into the (frozen) backbone; the
    patch-embedding and transformer-block weights are expected to match
    timm's standard ViT naming. Without a checkpoint the backbone is simply
    randomly initialised and frozen, which is sufficient for architecture
    testing but not for reproducing the paper's numbers.
    """

    def __init__(self, cfg: ViTConfig):
        super().__init__()
        self.cfg = cfg
        self.patch_embed = nn.Conv2d(
            cfg.in_chans, cfg.embed_dim, kernel_size=cfg.patch_size, stride=cfg.patch_size
        )
        num_patches = (cfg.image_size // cfg.patch_size) ** 2
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches, cfg.embed_dim))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        self.blocks = nn.ModuleList(
            [ViTBlock(cfg.embed_dim, cfg.num_heads, cfg.mlp_ratio, cfg.lora_rank) for _ in range(cfg.depth)]
        )
        self.norm = nn.LayerNorm(cfg.embed_dim)

        # Freeze patch embedding / position embedding / final norm -- only
        # LoRA adapters inside `blocks` are trainable.
        for p in self.patch_embed.parameters():
            p.requires_grad_(False)
        self.pos_embed.requires_grad_(False)
        for p in self.norm.parameters():
            p.requires_grad_(False)

    def load_retfound_checkpoint(self, state_dict: dict) -> None:
        """Best-effort loader for a timm-style ViT-L/16 MAE checkpoint.
        Keys that don't match the backbone (e.g. decoder/mask-token weights
        from the MAE pretext task) are silently ignored."""
        own = self.state_dict()
        filtered = {k: v for k, v in state_dict.items() if k in own and own[k].shape == v.shape}
        own.update(filtered)
        self.load_state_dict(own)

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        """Returns the token sequence after each tapped block, as spatial
        maps ``[B, C, H', W']`` where ``H' = W' = image_size / patch_size``."""
        b = x.shape[0]
        tokens = self.patch_embed(x)  # [B, C, H', W']
        gh, gw = tokens.shape[-2:]
        tokens = tokens.flatten(2).transpose(1, 2)  # [B, N, C]

        pos = self.pos_embed
        if pos.shape[1] != tokens.shape[1]:
            pos = F.interpolate(
                pos.transpose(1, 2).reshape(1, -1, int(pos.shape[1] ** 0.5), int(pos.shape[1] ** 0.5)),
                size=(gh, gw),
                mode="bilinear",
                align_corners=False,
            ).flatten(2).transpose(1, 2)
        tokens = tokens + pos

        taps = []
        for i, block in enumerate(self.blocks, start=1):
            tokens = block(tokens)
            if i in self.cfg.tap_blocks:
                feat = self.norm(tokens) if i == self.cfg.depth else tokens
                spatial = feat.transpose(1, 2).reshape(b, -1, gh, gw)
                taps.append(spatial)
        if not taps:
            taps.append(tokens.transpose(1, 2).reshape(b, -1, gh, gw))
        return taps


# --------------------------------------------------------------------------- #
# CNN branch
# --------------------------------------------------------------------------- #

class ResBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, stride: int = 1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_ch, out_ch, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_ch)
        self.conv2 = nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_ch)
        self.act = nn.ReLU(inplace=True)
        self.skip = None
        if stride != 1 or in_ch != out_ch:
            self.skip = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, stride=stride, bias=False), nn.BatchNorm2d(out_ch)
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x if self.skip is None else self.skip(x)
        out = self.act(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return self.act(out + identity)


class FullResCNNBranch(nn.Module):
    """Residual CNN whose first stage stays at the input resolution, then
    progressively downsamples to the scales tapped from the ViT branch."""

    def __init__(self, in_chans: int = 3, base_ch: int = 64, num_scales: int = 4):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(in_chans, base_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(base_ch),
            nn.ReLU(inplace=True),
            ResBlock(base_ch, base_ch),  # full resolution: preserves 1-2 px capillaries
        )
        stages = []
        ch = base_ch
        for s in range(num_scales):
            out_ch = min(ch * 2, 1024)
            stages.append(ResBlock(ch, out_ch, stride=2))
            ch = out_ch
        self.stages = nn.ModuleList(stages)

    def forward(self, x: torch.Tensor):
        full_res = self.stem(x)
        feats = [full_res]
        h = full_res
        for stage in self.stages:
            h = stage(h)
            feats.append(h)
        return full_res, feats  # full_res bypasses fusion via a skip connection


# --------------------------------------------------------------------------- #
# Windowed cross-attention fusion (Eq. 3)
# --------------------------------------------------------------------------- #

class WindowedCrossAttention(nn.Module):
    """F_fus = softmax(Q_c K_v^T / sqrt(C)) V_v, computed independently
    inside non-overlapping ``window`` x ``window`` spatial windows so cost
    stays linear in resolution."""

    def __init__(self, cnn_ch: int, vit_ch: int, fused_ch: int, window: int = 8, num_heads: int = 8):
        super().__init__()
        self.window = window
        self.num_heads = num_heads
        self.head_dim = fused_ch // num_heads
        assert fused_ch % num_heads == 0

        self.q_proj = nn.Conv2d(cnn_ch, fused_ch, 1)
        self.k_proj = nn.Conv2d(vit_ch, fused_ch, 1)
        self.v_proj = nn.Conv2d(vit_ch, fused_ch, 1)
        self.out_proj = nn.Conv2d(fused_ch, fused_ch, 1)
        self.scale = self.head_dim ** -0.5

    @staticmethod
    def _pad_to_multiple(x: torch.Tensor, multiple: int):
        _, _, h, w = x.shape
        pad_h = (multiple - h % multiple) % multiple
        pad_w = (multiple - w % multiple) % multiple
        if pad_h or pad_w:
            x = F.pad(x, (0, pad_w, 0, pad_h))
        return x, pad_h, pad_w

    def _windows(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        win = self.window
        x = x.view(b, c, h // win, win, w // win, win)
        x = x.permute(0, 2, 4, 1, 3, 5).contiguous()  # [B, nH, nW, C, win, win]
        return x.view(b * (h // win) * (w // win), c, win * win).transpose(1, 2)  # [B*nWin, win*win, C]

    def forward(self, f_cnn: torch.Tensor, f_vit: torch.Tensor) -> torch.Tensor:
        if f_vit.shape[-2:] != f_cnn.shape[-2:]:
            f_vit = F.interpolate(f_vit, size=f_cnn.shape[-2:], mode="bilinear", align_corners=False)

        q_full = self.q_proj(f_cnn)
        k_full = self.k_proj(f_vit)
        v_full = self.v_proj(f_vit)

        q_full, pad_h, pad_w = self._pad_to_multiple(q_full, self.window)
        k_full, _, _ = self._pad_to_multiple(k_full, self.window)
        v_full, _, _ = self._pad_to_multiple(v_full, self.window)
        b, c, h, w = q_full.shape

        q = self._windows(q_full)  # [B*nWin, win*win, C]
        k = self._windows(k_full)
        v = self._windows(v_full)

        nb, n, c_ = q.shape
        nh = self.num_heads
        hd = self.head_dim
        q = q.view(nb, n, nh, hd).transpose(1, 2)
        k = k.view(nb, n, nh, hd).transpose(1, 2)
        v = v.view(nb, n, nh, hd).transpose(1, 2)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        out = (attn @ v).transpose(1, 2).reshape(nb, n, c_)

        win = self.window
        n_win_h = h // win
        n_win_w = w // win
        out = out.transpose(1, 2).reshape(b, n_win_h, n_win_w, c_, win, win)
        out = out.permute(0, 3, 1, 4, 2, 5).contiguous().view(b, c_, h, w)
        if pad_h or pad_w:
            out = out[:, :, : h - pad_h, : w - pad_w]
        return self.out_proj(out)


# --------------------------------------------------------------------------- #
# Full hybrid encoder
# --------------------------------------------------------------------------- #

class HybridViTCNNEncoder(nn.Module):
    """Couples :class:`RETFoundViT` and :class:`FullResCNNBranch` through
    :class:`WindowedCrossAttention` at every shared scale (Section 3.2)."""

    def __init__(
        self,
        vit_cfg: ViTConfig | None = None,
        cnn_base_ch: int = 64,
        fused_ch: int = 256,
        window: int = 8,
    ):
        super().__init__()
        self.vit_cfg = vit_cfg or ViTConfig()
        self.vit = RETFoundViT(self.vit_cfg)
        self.cnn = FullResCNNBranch(in_chans=self.vit_cfg.in_chans, base_ch=cnn_base_ch,
                                     num_scales=len(self.vit_cfg.tap_blocks))
        self.fusions = nn.ModuleList(
            [
                WindowedCrossAttention(
                    cnn_ch=min(cnn_base_ch * 2 ** (i + 1), 1024),
                    vit_ch=self.vit_cfg.embed_dim,
                    fused_ch=fused_ch,
                    window=window,
                )
                for i in range(len(self.vit_cfg.tap_blocks))
            ]
        )
        self.full_res_channels = cnn_base_ch
        self.fused_channels = fused_ch

    def forward(self, x: torch.Tensor):
        """Returns ``(full_res_skip, fused_multiscale)`` where
        ``full_res_skip`` is ``[B, cnn_base_ch, H, W]`` (bypasses fusion,
        Section 3.2) and ``fused_multiscale`` is a list of fused feature
        maps, one per tapped ViT block / CNN stage, coarsest first."""
        vit_taps = self.vit(x)
        full_res, cnn_feats = self.cnn(x)
        # cnn_feats[0] is the full-res stem; fuse stages 1.. with ViT taps
        fused = []
        for i, (vit_feat, cnn_feat) in enumerate(zip(vit_taps, cnn_feats[1:])):
            fused.append(self.fusions[i](cnn_feat, vit_feat))
        return full_res, fused
