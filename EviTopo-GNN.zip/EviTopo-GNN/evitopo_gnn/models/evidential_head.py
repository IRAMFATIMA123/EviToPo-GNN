"""Evidential head: Dirichlet-parameterised probability + uncertainty.

Implements Eq. (4):

    e = softplus(nu),  alpha = e + 1,  S = alpha_0 + alpha_1,
    p_k = alpha_k / S,  U = 2 / S

A one-by-one convolution maps decoded features to two-class logits ``nu``;
the evidence ``e`` parameterises a Dirichlet distribution per pixel, from
which the vessel probability and the (total-evidence) uncertainty are read
directly. Used for both the coarse head (Section 3.3, on the encoder-decoder
features before graph refinement) and the final head (Section 3.7, after
the graph-to-pixel decoder).
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class EvidentialOutput:
    prob: torch.Tensor          # p_1, vessel probability,  [B, 1, H, W]
    uncertainty: torch.Tensor   # U = 2 / S,                [B, 1, H, W]
    alpha: torch.Tensor         # Dirichlet strengths,      [B, 2, H, W]
    evidence: torch.Tensor      # e = softplus(nu),         [B, 2, H, W]


class EvidentialHead(nn.Module):
    """Two-class evidential (Dirichlet) prediction head.

    Parameters
    ----------
    in_channels: int
        Number of channels of the incoming decoded feature map.
    hidden_channels: int, optional
        If given, inserts one 3x3 conv + ReLU before the 1x1 evidence
        projection; the paper specifies a plain 1x1 conv, so this defaults
        to ``None`` (direct 1x1 projection).
    """

    def __init__(self, in_channels: int, hidden_channels: int | None = None):
        super().__init__()
        if hidden_channels is not None:
            self.pre = nn.Sequential(
                nn.Conv2d(in_channels, hidden_channels, 3, padding=1), nn.ReLU(inplace=True)
            )
            proj_in = hidden_channels
        else:
            self.pre = nn.Identity()
            proj_in = in_channels
        self.logits = nn.Conv2d(proj_in, 2, kernel_size=1)

    def forward(self, feat: torch.Tensor) -> EvidentialOutput:
        nu = self.logits(self.pre(feat))
        evidence = F.softplus(nu)
        alpha = evidence + 1.0
        strength = alpha.sum(dim=1, keepdim=True)  # S
        prob = alpha[:, 1:2] / strength             # p_1 (vessel class)
        uncertainty = 2.0 / strength                # U = K / S with K=2 classes
        return EvidentialOutput(prob=prob, uncertainty=uncertainty, alpha=alpha, evidence=evidence)
