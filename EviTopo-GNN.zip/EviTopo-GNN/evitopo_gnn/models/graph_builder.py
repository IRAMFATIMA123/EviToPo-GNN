"""Vessel-topology graph construction (Section 3.4).

Builds ``G = (V, E_obs U E_gap)`` on the hard skeleton of the coarse
probability map:

* **Nodes** ``V``: junctions, endpoints and points sampled at fixed spacing
  ``delta`` along each branch. Every node carries the bilinearly sampled
  fused feature, the local vessel width, a sign-free orientation encoding
  ``(cos 2*theta, sin 2*theta)``, and the coarse probability/uncertainty.
* **Observed edges** ``E_obs``: link consecutive nodes along a branch and
  carry length, type, and the mean probability / uncertainty / gradient
  magnitude along the segment.
* **Candidate gap edges** ``E_gap``: for every endpoint, and every
  non-junction node whose uncertainty exceeds ``tau_u``, candidates link it
  to nodes on other branches within radius ``r_g``. A node's tangent is the
  principal eigenvector of the covariance of skeleton-pixel coordinates in
  a 7x7 window (sign-free); an endpoint additionally receives a signed
  outward direction ``d_i``, the unit vector from the mean of its five
  preceding skeleton pixels to the endpoint.

  Source compatibility (Eq. 6):

      c_ij = <d_i, o_ij>                 if i is an endpoint
      c_ij = |<t_i, o_ij>|               otherwise

  where ``o_ij = (x_j - x_i) / ||x_j - x_i||``. A candidate is retained when
  ``c_ij >= tau_c`` and, if the target is also an endpoint,
  ``<d_j, -o_ij> >= tau_c``; the ``k_gap`` most compatible candidates are
  kept per source. Junctions are never gap sources.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F

from evitopo_gnn.models.skeleton import hard_skeletonize_and_prune, skeleton_degree_map

NODE_JUNCTION = 0
NODE_ENDPOINT = 1
NODE_REGULAR = 2


@dataclass
class VesselGraph:
    """Container for one image's vessel-topology graph. All tensors live on
    the same device as the feature map passed to the builder."""

    node_pos: torch.Tensor          # [N, 2] (y, x) in pixel coordinates
    node_feat: torch.Tensor         # [N, C] bilinearly sampled fused features
    node_width: torch.Tensor        # [N, 1] local vessel width
    node_orient: torch.Tensor       # [N, 2] (cos 2theta, sin 2theta)
    node_prob: torch.Tensor         # [N, 1] coarse probability at node
    node_uncertainty: torch.Tensor  # [N, 1] coarse uncertainty at node
    node_type: torch.Tensor         # [N] long, one of NODE_* constants
    node_tangent: torch.Tensor      # [N, 2] unit tangent (sign-free)
    node_outward: torch.Tensor      # [N, 2] signed outward dir (endpoints only, else 0)
    branch_id: torch.Tensor         # [N] long, connected-branch grouping (for contrastive loss)

    obs_edge_index: torch.Tensor    # [2, E_obs]
    obs_edge_attr: torch.Tensor     # [E_obs, F]

    gap_edge_index: torch.Tensor    # [2, E_gap] candidate gaps (both directions already resolved)
    gap_edge_attr: torch.Tensor     # [E_gap, F2] last column is compatibility c_ij
    gap_is_endpoint_pair: torch.Tensor  # [E_gap] bool

    skeleton: np.ndarray            # [H, W] bool, for visualisation / debugging

    @property
    def num_nodes(self) -> int:
        return self.node_pos.shape[0]


def _node_feature_dim(feat_map: torch.Tensor) -> int:
    return feat_map.shape[0]


def _bilinear_sample(feat_map: torch.Tensor, ys: np.ndarray, xs: np.ndarray) -> torch.Tensor:
    """``feat_map``: [C, H, W]. Returns [N, C]."""
    c, h, w = feat_map.shape
    if len(ys) == 0:
        return torch.zeros(0, c, device=feat_map.device, dtype=feat_map.dtype)
    grid_y = torch.as_tensor(ys, dtype=torch.float32, device=feat_map.device)
    grid_x = torch.as_tensor(xs, dtype=torch.float32, device=feat_map.device)
    norm_x = (grid_x / max(w - 1, 1)) * 2 - 1
    norm_y = (grid_y / max(h - 1, 1)) * 2 - 1
    grid = torch.stack([norm_x, norm_y], dim=-1).view(1, -1, 1, 2)
    sampled = F.grid_sample(
        feat_map.unsqueeze(0), grid, mode="bilinear", padding_mode="border", align_corners=True
    )  # [1, C, N, 1]
    return sampled.squeeze(0).squeeze(-1).transpose(0, 1)  # [N, C]


def _tangent_from_window(skeleton: np.ndarray, y: int, x: int, win: int = 7):
    r = win // 2
    h, w = skeleton.shape
    y0, y1 = max(0, y - r), min(h, y + r + 1)
    x0, x1 = max(0, x - r), min(w, x + r + 1)
    patch = skeleton[y0:y1, x0:x1]
    ys, xs = np.nonzero(patch)
    if len(ys) < 2:
        return np.array([1.0, 0.0])
    pts = np.stack([ys, xs], axis=1).astype(np.float64)
    pts -= pts.mean(axis=0, keepdims=True)
    cov = pts.T @ pts
    eigvals, eigvecs = np.linalg.eigh(cov)
    principal = eigvecs[:, np.argmax(eigvals)]  # (dy, dx)
    norm = np.linalg.norm(principal) + 1e-8
    return principal / norm


def _walk_branches(skeleton: np.ndarray, degree: np.ndarray):
    """Decompose the skeleton into branches between junctions/endpoints.
    Returns a list of branches, each a list of (y, x) pixel coordinates in
    walk order (including the junction/endpoint pixels at both ends)."""
    h, w = skeleton.shape

    def neighbors(y, x):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and skeleton[ny, nx]:
                    yield ny, nx

    special = set(zip(*np.nonzero((degree == 1) | (degree >= 3))))
    visited_edges = set()
    branches = []

    def edge_key(a, b):
        return (a, b) if a <= b else (b, a)

    for start in special:
        for nb in neighbors(*start):
            key = edge_key(start, nb)
            if key in visited_edges:
                continue
            path = [start, nb]
            visited_edges.add(key)
            prev, cur = start, nb
            while cur not in special:
                nxt = [n for n in neighbors(*cur) if n != prev]
                if not nxt:
                    break
                nxt = nxt[0]
                k2 = edge_key(cur, nxt)
                if k2 in visited_edges:
                    break
                visited_edges.add(k2)
                path.append(nxt)
                prev, cur = cur, nxt
            branches.append(path)

    # handle isolated cycles with no junction/endpoint (rare): walk them whole
    all_visited = set()
    for br in branches:
        for i in range(len(br) - 1):
            all_visited.add(edge_key(br[i], br[i + 1]))
    ys, xs = np.nonzero(skeleton)
    seen_pixels = set()
    for br in branches:
        seen_pixels.update(br)
    for y, x in zip(ys, xs):
        if (y, x) in seen_pixels:
            continue
        # walk an unvisited loop starting here
        path = [(y, x)]
        seen_pixels.add((y, x))
        prev, cur = None, (y, x)
        while True:
            nxt = [n for n in neighbors(*cur) if n != prev and n not in seen_pixels]
            if not nxt:
                break
            nxt = nxt[0]
            path.append(nxt)
            seen_pixels.add(nxt)
            prev, cur = cur, nxt
        if len(path) > 1:
            branches.append(path)
    return branches


class VesselTopologyGraphBuilder:
    def __init__(
        self,
        node_spacing: int = 8,       # delta
        min_spur_len: int = 10,
        gap_radius: float = 32.0,    # r_g
        k_gap: int = 3,
        tau_u: float = 0.5,
        tau_c: float = 0.5,
        skeleton_threshold: float = 0.5,
        tangent_window: int = 7,
    ):
        self.node_spacing = node_spacing
        self.min_spur_len = min_spur_len
        self.gap_radius = gap_radius
        self.k_gap = k_gap
        self.tau_u = tau_u
        self.tau_c = tau_c
        self.skeleton_threshold = skeleton_threshold
        self.tangent_window = tangent_window

    def build(
        self,
        prob_map: torch.Tensor,        # [1, H, W] coarse probability
        uncertainty_map: torch.Tensor, # [1, H, W]
        feature_map: torch.Tensor,     # [C, H, W] fused features to sample node features from
    ) -> VesselGraph:
        """Builds the graph for one image.

        Gradient flow (Section 3.9): the binarised skeleton, node
        *positions*, endpoint/junction selection and the candidate edge set
        are structural decisions computed from detached numpy arrays and
        carry no gradient. The *values* sampled at those fixed positions
        (``node_feat``, ``node_prob``, ``node_uncertainty``) are read with
        ``F.grid_sample`` directly from the (still-attached) input tensors,
        so gradients reach the encoder through them as intended -- this
        method is therefore deliberately *not* wrapped in
        ``torch.no_grad()``.
        """
        device = feature_map.device
        skeleton = hard_skeletonize_and_prune(
            prob_map, threshold=self.skeleton_threshold, min_spur_len=self.min_spur_len
        )
        degree = skeleton_degree_map(skeleton)
        branches = _walk_branches(skeleton, degree)

        # --- enumerate nodes: junction/endpoint pixels + resampled regular points ---
        node_records: List[Dict] = []
        pixel_to_node: Dict[Tuple[int, int], int] = {}

        def register(y, x, ntype, branch_id):
            key = (y, x)
            if key in pixel_to_node:
                return pixel_to_node[key]
            idx = len(node_records)
            node_records.append({"y": y, "x": x, "type": ntype, "branch": branch_id})
            pixel_to_node[key] = idx
            return idx

        for bid, branch in enumerate(branches):
            y0, x0 = branch[0]
            y1, x1 = branch[-1]
            t0 = NODE_JUNCTION if degree[y0, x0] >= 3 else NODE_ENDPOINT
            t1 = NODE_JUNCTION if degree[y1, x1] >= 3 else NODE_ENDPOINT
            register(y0, x0, t0, bid)
            register(y1, x1, t1, bid)
            for i in range(self.node_spacing, len(branch) - 1, self.node_spacing):
                y, x = branch[i]
                register(y, x, NODE_REGULAR, bid)

        n = len(node_records)
        if n == 0:
            return self._empty_graph(feature_map, skeleton)

        ys = np.array([r["y"] for r in node_records])
        xs = np.array([r["x"] for r in node_records])
        types = np.array([r["type"] for r in node_records])
        branch_ids = np.array([r["branch"] for r in node_records])

        # --- per-node geometry: tangent, width, outward direction ---
        tangents = np.zeros((n, 2))
        outward = np.zeros((n, 2))
        width = np.zeros((n, 1))
        dist_map = _distance_transform(skeleton.shape, skeleton, prob_map, self.skeleton_threshold)
        branch_pixel_index: Dict[int, List[Tuple[int, int]]] = {}
        for bid, branch in enumerate(branches):
            branch_pixel_index[bid] = branch

        for i, rec in enumerate(node_records):
            y, x, bid = rec["y"], rec["x"], rec["branch"]
            tangents[i] = _tangent_from_window(skeleton, y, x, win=self.tangent_window)
            width[i, 0] = dist_map[y, x]
            if rec["type"] == NODE_ENDPOINT:
                branch = branch_pixel_index[bid]
                if branch[0] == (y, x):
                    preceding = branch[1:6]
                else:
                    preceding = branch[-6:-1]
                if preceding:
                    mean_pt = np.mean(np.array(preceding), axis=0)
                    direction = np.array([y, x], dtype=np.float64) - mean_pt
                    norm = np.linalg.norm(direction) + 1e-8
                    outward[i] = direction / norm

        # sign-free orientation encoding (cos 2theta, sin 2theta)
        theta = np.arctan2(tangents[:, 0], tangents[:, 1])
        orient = np.stack([np.cos(2 * theta), np.sin(2 * theta)], axis=1)

        node_pos = torch.as_tensor(np.stack([ys, xs], axis=1), dtype=torch.float32, device=device)
        node_feat = _bilinear_sample(feature_map, ys, xs)
        node_width = torch.as_tensor(width, dtype=torch.float32, device=device)
        node_orient = torch.as_tensor(orient, dtype=torch.float32, device=device)
        node_tangent = torch.as_tensor(tangents, dtype=torch.float32, device=device)
        node_outward = torch.as_tensor(outward, dtype=torch.float32, device=device)
        node_prob = _bilinear_sample(prob_map, ys, xs)
        node_uncertainty = _bilinear_sample(uncertainty_map, ys, xs)
        node_type = torch.as_tensor(types, dtype=torch.long, device=device)
        branch_id_t = torch.as_tensor(branch_ids, dtype=torch.long, device=device)

        # --- observed edges: consecutive registered nodes within each branch walk ---
        obs_src, obs_dst, obs_attr = [], [], []
        for bid, branch in enumerate(branches):
            node_idx_in_branch = [pixel_to_node[p] for p in branch if p in pixel_to_node]
            # unique, ordered
            seen = set()
            ordered = []
            for idx in node_idx_in_branch:
                if idx not in seen:
                    seen.add(idx)
                    ordered.append(idx)
            for a, b in zip(ordered[:-1], ordered[1:]):
                pa = node_pos[a].detach().cpu().numpy()
                pb = node_pos[b].detach().cpu().numpy()
                length = float(np.linalg.norm(pa - pb))
                # Observed-edge summary statistics are structural (not
                # differentiated through); node_feat/node_prob/node_uncertainty
                # themselves remain differentiable for the GNN and decoder.
                mean_prob = float((node_prob[a].detach() + node_prob[b].detach()).mean() / 2)
                mean_unc = float((node_uncertainty[a].detach() + node_uncertainty[b].detach()).mean() / 2)
                grad_mag = float(
                    abs(node_prob[a].detach().item() - node_prob[b].detach().item()) / max(length, 1e-6)
                )
                obs_src += [a, b]
                obs_dst += [b, a]
                attr = [length, 0.0, mean_prob, mean_unc, grad_mag]  # second col: is_gap flag (0)
                obs_attr += [attr, attr]

        if obs_src:
            obs_edge_index = torch.as_tensor([obs_src, obs_dst], dtype=torch.long, device=device)
            obs_edge_attr = torch.as_tensor(obs_attr, dtype=torch.float32, device=device)
        else:
            obs_edge_index = torch.zeros(2, 0, dtype=torch.long, device=device)
            obs_edge_attr = torch.zeros(0, 5, dtype=torch.float32, device=device)

        # --- candidate gap edges (Eq. 6) ---
        gap_src, gap_dst, gap_attr, gap_is_ep_pair = self._build_gap_edges(
            node_pos.detach().cpu().numpy(), types, branch_ids, tangents, outward,
            node_uncertainty.squeeze(-1).detach().cpu().numpy(),
        )
        if gap_src:
            gap_edge_index = torch.as_tensor([gap_src, gap_dst], dtype=torch.long, device=device)
            gap_edge_attr = torch.as_tensor(gap_attr, dtype=torch.float32, device=device)
            gap_is_endpoint_pair = torch.as_tensor(gap_is_ep_pair, dtype=torch.bool, device=device)
        else:
            gap_edge_index = torch.zeros(2, 0, dtype=torch.long, device=device)
            gap_edge_attr = torch.zeros(0, 1, dtype=torch.float32, device=device)
            gap_is_endpoint_pair = torch.zeros(0, dtype=torch.bool, device=device)

        return VesselGraph(
            node_pos=node_pos,
            node_feat=node_feat,
            node_width=node_width,
            node_orient=node_orient,
            node_prob=node_prob,
            node_uncertainty=node_uncertainty,
            node_type=node_type,
            node_tangent=node_tangent,
            node_outward=node_outward,
            branch_id=branch_id_t,
            obs_edge_index=obs_edge_index,
            obs_edge_attr=obs_edge_attr,
            gap_edge_index=gap_edge_index,
            gap_edge_attr=gap_edge_attr,
            gap_is_endpoint_pair=gap_is_endpoint_pair,
            skeleton=skeleton,
        )

    def _build_gap_edges(self, pos, types, branch_ids, tangents, outward, uncertainty):
        n = pos.shape[0]
        eligible_target = np.arange(n)
        candidates_by_source = []

        is_source_eligible = (types == NODE_ENDPOINT) | ((types == NODE_REGULAR) & (uncertainty > self.tau_u))
        source_idx = np.nonzero(is_source_eligible)[0]

        gap_src, gap_dst, gap_attr, gap_is_ep_pair = [], [], [], []

        for i in source_idx:
            diffs = pos[eligible_target] - pos[i]
            dists = np.linalg.norm(diffs, axis=1)
            same_branch = branch_ids[eligible_target] == branch_ids[i]
            valid = (dists > 1e-3) & (dists <= self.gap_radius) & (~same_branch)
            valid &= eligible_target != i
            if not np.any(valid):
                continue
            j_candidates = eligible_target[valid]
            o_ij = diffs[valid] / dists[valid, None]

            if types[i] == NODE_ENDPOINT:
                src_vec = outward[i]
            else:
                src_vec = tangents[i]

            if types[i] == NODE_ENDPOINT:
                c_ij = (o_ij * src_vec[None, :]).sum(axis=1)
            else:
                c_ij = np.abs((o_ij * src_vec[None, :]).sum(axis=1))

            keep = c_ij >= self.tau_c
            if types[i] == NODE_ENDPOINT:
                target_is_ep = types[j_candidates] == NODE_ENDPOINT
                reciprocal = np.ones_like(keep, dtype=bool)
                if np.any(target_is_ep):
                    d_j = outward[j_candidates[target_is_ep]]
                    rec_val = (-o_ij[target_is_ep] * d_j).sum(axis=1)
                    reciprocal[target_is_ep] = rec_val >= self.tau_c
                keep &= reciprocal

            if not np.any(keep):
                continue

            kept_j = j_candidates[keep]
            kept_c = c_ij[keep]
            order = np.argsort(-kept_c)[: self.k_gap]
            for rank in order:
                j = int(kept_j[rank])
                gap_src.append(int(i))
                gap_dst.append(j)
                gap_attr.append([float(kept_c[rank])])
                gap_is_ep_pair.append(bool(types[i] == NODE_ENDPOINT and types[j] == NODE_ENDPOINT))

        return gap_src, gap_dst, gap_attr, gap_is_ep_pair

    def _empty_graph(self, feature_map, skeleton):
        device = feature_map.device
        z = lambda *shape: torch.zeros(*shape, device=device)
        return VesselGraph(
            node_pos=z(0, 2), node_feat=z(0, feature_map.shape[0]), node_width=z(0, 1),
            node_orient=z(0, 2), node_prob=z(0, 1), node_uncertainty=z(0, 1),
            node_type=torch.zeros(0, dtype=torch.long, device=device),
            node_tangent=z(0, 2), node_outward=z(0, 2),
            branch_id=torch.zeros(0, dtype=torch.long, device=device),
            obs_edge_index=torch.zeros(2, 0, dtype=torch.long, device=device),
            obs_edge_attr=z(0, 5),
            gap_edge_index=torch.zeros(2, 0, dtype=torch.long, device=device),
            gap_edge_attr=z(0, 1),
            gap_is_endpoint_pair=torch.zeros(0, dtype=torch.bool, device=device),
            skeleton=skeleton,
        )


def _distance_transform(shape, skeleton, prob_map, threshold):
    """Local vessel half-width at each skeleton pixel: distance from the
    skeleton pixel to the nearest background pixel in the binarised mask."""
    from scipy.ndimage import distance_transform_edt

    if isinstance(prob_map, torch.Tensor):
        mask = (prob_map.detach().cpu().numpy().squeeze() >= threshold)
    else:
        mask = prob_map.squeeze() >= threshold
    return distance_transform_edt(mask)
