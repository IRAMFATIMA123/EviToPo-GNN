"""The full EviTopo-GNN model (Eq. 1, Fig. 1).

    P, U, G = F_theta(X, M),   P, U in [0, 1]^Omega

Five stages, matching Fig. 1 / Section 3:

1. :class:`~evitopo_gnn.models.hybrid_encoder.HybridViTCNNEncoder` -- hybrid
   ViT-CNN encoder (Section 3.2).
2. :class:`~evitopo_gnn.models.evidential_head.EvidentialHead` on the
   decoded coarse features -- evidential coarse head, returns ``P_c, U_c``
   (Section 3.3).
3. :class:`~evitopo_gnn.models.graph_builder.VesselTopologyGraphBuilder` --
   vessel-topology graph with orientation-gated gap candidates
   (Section 3.4).
4. :class:`~evitopo_gnn.models.gnn_layers.UncertaintyGatedGNN` +
   :class:`~evitopo_gnn.models.link_predictor.EvidentialLinkPredictor` --
   uncertainty-gated message passing and the evidential link head that
   decides which gaps to bridge (Section 3.5-3.6).
5. :class:`~evitopo_gnn.models.decoder.GraphToPixelDecoder` -- splats the
   refined graph back onto the pixel grid and returns the final ``P, U``
   (Section 3.7).

The graph stages (3-4) are inherently per-image (variable node/edge
counts), so :meth:`EviTopoGNN.forward` loops over the batch dimension for
those stages while the encoder/decoder convolutions run batched.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import torch
import torch.nn as nn

from evitopo_gnn.models.hybrid_encoder import HybridViTCNNEncoder, ViTConfig
from evitopo_gnn.models.coarse_decoder import CoarseDecoder
from evitopo_gnn.models.evidential_head import EvidentialHead, EvidentialOutput
from evitopo_gnn.models.graph_builder import VesselTopologyGraphBuilder, VesselGraph, NODE_ENDPOINT
from evitopo_gnn.models.gnn_layers import UncertaintyGatedGNN
from evitopo_gnn.models.link_predictor import EvidentialLinkPredictor, LinkPredictionOutput, decide_bridges
from evitopo_gnn.models.decoder import GraphToPixelDecoder
from evitopo_gnn.models.contrastive_head import ContrastiveProjectionHead


@dataclass
class EviTopoGNNOutput:
    coarse: List[EvidentialOutput]
    final: List[EvidentialOutput]
    graphs: List[VesselGraph]
    refined_node_feats: List[torch.Tensor]
    link_outputs: List[LinkPredictionOutput]
    contrastive_embeddings: torch.Tensor  # [B, proj_dim, H, W]
    accepted_bridge_masks: Optional[List[torch.Tensor]] = None

    @property
    def prob(self) -> torch.Tensor:
        return torch.stack([o.prob.squeeze(0) for o in self.final], dim=0)

    @property
    def uncertainty(self) -> torch.Tensor:
        return torch.stack([o.uncertainty.squeeze(0) for o in self.final], dim=0)


class EviTopoGNN(nn.Module):
    def __init__(
        self,
        vit_cfg: ViTConfig | None = None,
        cnn_base_ch: int = 64,
        fused_ch: int = 256,
        window: int = 8,
        decoded_feat_ch: int = 128,
        graph_node_spacing: int = 8,
        graph_min_spur_len: int = 10,
        graph_gap_radius: float = 32.0,
        graph_k_gap: int = 3,
        graph_tau_u: float = 0.5,
        graph_tau_c: float = 0.5,
        gnn_edge_dim: int = 64,
        gnn_hidden_dim: int = 256,
        gnn_num_layers: int = 2,
        gnn_gate_exponent: float = 1.0,
        gnn_gate_mode: str = "full",
        link_hidden_dim: int = 128,
        decoder_channels: int = 128,
        contrastive_proj_dim: int = 128,
        tau_link: float = 0.5,
    ):
        super().__init__()
        self.encoder = HybridViTCNNEncoder(vit_cfg=vit_cfg, cnn_base_ch=cnn_base_ch, fused_ch=fused_ch, window=window)
        self.coarse_decoder = CoarseDecoder(
            fused_channels=fused_ch, full_res_channels=cnn_base_ch, out_channels=decoded_feat_ch
        )
        self.coarse_head = EvidentialHead(decoded_feat_ch)

        self.graph_builder = VesselTopologyGraphBuilder(
            node_spacing=graph_node_spacing,
            min_spur_len=graph_min_spur_len,
            gap_radius=graph_gap_radius,
            k_gap=graph_k_gap,
            tau_u=graph_tau_u,
            tau_c=graph_tau_c,
        )
        self.gnn = UncertaintyGatedGNN(
            node_dim=decoded_feat_ch,
            edge_dim=gnn_edge_dim,
            hidden_dim=gnn_hidden_dim,
            num_layers=gnn_num_layers,
            gate_exponent=gnn_gate_exponent,
            gate_mode=gnn_gate_mode,
        )
        self.link_predictor = EvidentialLinkPredictor(
            node_dim=gnn_hidden_dim, edge_dim=gnn_edge_dim, hidden_dim=link_hidden_dim
        )
        self.decoder = GraphToPixelDecoder(
            node_feat_dim=gnn_hidden_dim, skip_channels=cnn_base_ch, decoder_channels=decoder_channels
        )
        self.contrastive_head = ContrastiveProjectionHead(decoder_channels, proj_dim=contrastive_proj_dim)

        self.tau_link = tau_link
        self.decoded_feat_ch = decoded_feat_ch

    def forward(self, x: torch.Tensor, inference: bool = False) -> EviTopoGNNOutput:
        """``x``: ``[B, 3, H, W]``. ``inference=True`` restricts the
        link-prior map to gaps actually accepted by Eq. (11) (otherwise the
        training-time soft superposition over every candidate is used,
        Section 3.6-3.7)."""
        full_res, fused = self.encoder(x)
        decoded_coarse = self.coarse_decoder(fused, full_res)  # [B, decoded_feat_ch, H, W]
        coarse_out = self.coarse_head(decoded_coarse)

        batch_size = x.shape[0]
        coarse_list, final_list, graphs, refined_feats, link_outs, accept_masks = [], [], [], [], [], []
        contrastive_maps = []

        for b in range(batch_size):
            prob_b = coarse_out.prob[b]
            unc_b = coarse_out.uncertainty[b]
            feat_b = decoded_coarse[b]
            coarse_list.append(
                EvidentialOutput(
                    prob=prob_b.unsqueeze(0), uncertainty=unc_b.unsqueeze(0),
                    alpha=coarse_out.alpha[b].unsqueeze(0), evidence=coarse_out.evidence[b].unsqueeze(0),
                )
            )

            graph = self.graph_builder.build(prob_b, unc_b, feat_b)
            h_prime = self.gnn(graph)

            edge_emb_gap = self.gnn.edge_encoder.gap_enc(graph.gap_edge_attr) if graph.gap_edge_attr.shape[0] else \
                torch.zeros(0, self.gnn.edge_encoder.edge_dim, device=x.device)
            link_out = self.link_predictor(h_prime, graph.gap_edge_index, edge_emb_gap)

            accepted_mask = None
            if inference:
                accepted_mask = decide_bridges(
                    graph.gap_edge_index, link_out.pi, link_out.u, graph.node_type,
                    node_is_endpoint_value=NODE_ENDPOINT, tau_link=self.tau_link,
                )

            final_out, r_map, gamma_map, dec_feat = self.decoder(
                graph.node_pos, h_prime, graph.node_width, graph.gap_edge_index, link_out.pi,
                full_res[b : b + 1], accepted_mask=accepted_mask,
            )
            z = self.contrastive_head(dec_feat)
            contrastive_maps.append(z)

            final_list.append(final_out)
            graphs.append(graph)
            refined_feats.append(h_prime)
            link_outs.append(link_out)
            accept_masks.append(accepted_mask)

        contrastive_embeddings = torch.cat(contrastive_maps, dim=0)

        return EviTopoGNNOutput(
            coarse=coarse_list,
            final=final_list,
            graphs=graphs,
            refined_node_feats=refined_feats,
            link_outputs=link_outs,
            contrastive_embeddings=contrastive_embeddings,
            accepted_bridge_masks=accept_masks if inference else None,
        )
