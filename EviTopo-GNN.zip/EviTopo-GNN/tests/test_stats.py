import numpy as np

from evitopo_gnn.stats.significance import paired_bootstrap_ci, paired_wilcoxon_p, holm_correction, cluster_bootstrap_pooled_difference
from evitopo_gnn.metrics.segmentation_metrics import f1_from_counts, ConfusionCounts


def test_paired_bootstrap_ci_contains_point_estimate():
    rng = np.random.default_rng(0)
    a = rng.random(30) + 0.8
    b = rng.random(30) + 0.75
    delta, (lo, hi) = paired_bootstrap_ci(a, b, n_resamples=2000, seed=1)
    assert lo <= delta <= hi


def test_wilcoxon_identical_arrays_gives_p_one():
    a = np.array([0.1, 0.2, 0.3])
    assert paired_wilcoxon_p(a, a) == 1.0


def test_holm_correction_monotone_and_bounded():
    pvals = [0.001, 0.2, 0.03, 0.049, 0.6]
    adj = holm_correction(pvals)
    assert all(0 <= p <= 1 for p in adj)
    # Holm-adjusted p-values must each be >= the raw p-value
    assert all(a >= p - 1e-12 for a, p in zip(adj, pvals))


def test_cluster_bootstrap_pooled_difference():
    counts_a = [{"tp": 10, "fp": 2, "fn": 3, "tn": 100} for _ in range(10)]
    counts_b = [{"tp": 8, "fp": 4, "fn": 5, "tn": 100} for _ in range(10)]
    metric_fn = lambda c: f1_from_counts(ConfusionCounts(**c))
    diff, (lo, hi) = cluster_bootstrap_pooled_difference(counts_a, counts_b, metric_fn, n_resamples=200, seed=2)
    assert diff > 0  # a is strictly better on every unit
