import numpy as np
import torch

from evitopo_gnn.losses.evidential_loss import evidential_bayes_risk_loss, to_one_hot_binary, lambda_kl_schedule
from evitopo_gnn.losses.dice_cldice_loss import dice_loss, cl_dice_loss
from evitopo_gnn.losses.link_loss import make_synthetic_gap_candidate_labels, link_supervision_loss
from evitopo_gnn.losses.contrastive_loss import TopologyAwareContrastiveLoss, contrastive_ramp
from evitopo_gnn.losses.combined_objective import CombinedObjective, StageSchedule


def test_lambda_kl_schedule():
    assert lambda_kl_schedule(0) == 0.0
    assert lambda_kl_schedule(10) == 1.0
    assert lambda_kl_schedule(20) == 1.0
    assert 0 < lambda_kl_schedule(5) < 1


def test_evidential_loss_backward():
    nu = torch.randn(2, 2, 8, 8, requires_grad=True)
    alpha = torch.nn.functional.softplus(nu) + 1.0
    y = (torch.rand(2, 1, 8, 8) > 0.5).float()
    y_onehot = to_one_hot_binary(y, class_dim=1)
    loss = evidential_bayes_risk_loss(alpha, y_onehot, lambda_kl=0.5)
    assert loss.ndim == 0
    loss.backward()
    assert nu.grad is not None


def test_dice_and_cldice_bounds():
    pred = torch.rand(1, 1, 16, 16, requires_grad=True)
    target = (torch.rand(1, 1, 16, 16) > 0.7).float()
    d = dice_loss(pred, target)
    c = cl_dice_loss(pred, target, num_iter=3)
    assert 0 <= float(d.detach()) <= 1.5
    assert 0 <= float(c.detach()) <= 1.5
    (d + c).backward()
    assert pred.grad is not None


def test_link_labels_perfect_match_is_positive():
    gt = np.zeros((32, 32), dtype=bool)
    gt[10, 2:30] = True  # one connected branch, no gap
    node_pos = torch.tensor([[10.0, 5.0], [10.0, 25.0]])
    gap_edge_index = torch.tensor([[0], [1]])
    labels = make_synthetic_gap_candidate_labels(node_pos, gap_edge_index, gt, max_proj_dist=1.0, geodesic_ratio=2.0)
    assert labels.item() == 1.0


def test_link_loss_runs():
    raw = torch.randn(5, 2, requires_grad=True)
    alpha_lnk = torch.nn.functional.softplus(raw) + 1
    labels = torch.tensor([1.0, 0.0, 0.0, 1.0, 0.0])
    loss = link_supervision_loss(alpha_lnk, labels, lambda_kl=0.1)
    loss.backward()
    assert raw.grad is not None


def test_contrastive_ramp():
    assert contrastive_ramp(100, 101, 150) == 0.0
    assert contrastive_ramp(150, 101, 150) == 1.0
    assert 0 < contrastive_ramp(125, 101, 150) < 1


def test_contrastive_loss_runs():
    proj_dim = 4
    H = W = 48
    raw = torch.randn(1, proj_dim, H, W, requires_grad=True)
    z_map = torch.nn.functional.normalize(raw, dim=1)
    prob_map = torch.rand(1, 1, H, W)
    unc_map = torch.rand(1, 1, H, W)
    gt_mask = np.zeros((H, W), dtype=bool)
    gt_mask[20, 5:40] = True
    loss_fn = TopologyAwareContrastiveLoss(proj_dim=proj_dim)
    loss = loss_fn(z_map, prob_map, unc_map, gt_mask, epoch=120)
    loss.backward()
    assert raw.grad is not None


def test_combined_objective_stage_gating():
    sched = StageSchedule()
    combiner = CombinedObjective(schedule=sched)
    losses = {
        "evid_final": torch.tensor(0.5), "dice": torch.tensor(0.3), "cldice": torch.tensor(0.2),
        "evid_coarse": torch.tensor(0.4), "link": torch.tensor(0.1), "contrastive": torch.tensor(0.05),
    }
    total_warmup, breakdown_warmup = combiner.combine(losses, epoch=10)
    total_full, breakdown_full = combiner.combine(losses, epoch=150)
    assert breakdown_warmup["link_term"] == 0.0
    assert breakdown_warmup["contrastive_term"] == 0.0
    assert breakdown_full["link_term"] > 0.0
    assert breakdown_full["contrastive_term"] > 0.0
    assert total_full > total_warmup
