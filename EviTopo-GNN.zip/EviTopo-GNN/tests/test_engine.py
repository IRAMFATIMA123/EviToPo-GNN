import numpy as np
import torch

from evitopo_gnn.models.hybrid_encoder import ViTConfig
from evitopo_gnn.models.evitopo_gnn import EviTopoGNN
from evitopo_gnn.inference.tiled_inference import TiledInferenceEngine
from evitopo_gnn.engine.trainer import Trainer, TrainerConfig
from evitopo_gnn.losses.combined_objective import StageSchedule


def _tiny_model():
    vit_cfg = ViTConfig(image_size=32, patch_size=16, embed_dim=16, depth=2, num_heads=2,
                         mlp_ratio=2.0, lora_rank=2, tap_blocks=(1, 2))
    return EviTopoGNN(
        vit_cfg=vit_cfg, cnn_base_ch=4, fused_ch=8, window=4, decoded_feat_ch=8,
        graph_node_spacing=4, graph_min_spur_len=3, graph_gap_radius=12.0, graph_k_gap=2,
        gnn_edge_dim=4, gnn_hidden_dim=8, gnn_num_layers=1, link_hidden_dim=8,
        decoder_channels=8, contrastive_proj_dim=4,
    )


def test_tiled_inference_matches_input_shape():
    torch.manual_seed(0)
    model = _tiny_model()
    model.eval()
    engine = TiledInferenceEngine(model, window=32, stride=16)
    img = torch.rand(1, 3, 48, 40)
    fov = torch.ones(1, 1, 48, 40)
    result = engine.run(img, fov)
    assert result.prob.shape[-2:] == (48, 40)
    assert result.num_tiles >= 1


class _TinyDataset(torch.utils.data.Dataset):
    def __len__(self):
        return 4

    def __getitem__(self, i):
        img = torch.rand(3, 32, 32)
        mask = (torch.rand(1, 32, 32) > 0.9).float()
        fov = torch.ones(1, 32, 32)
        return img, mask, fov, f"im{i}"


def test_trainer_runs_all_three_stages():
    torch.manual_seed(0)
    np.random.seed(0)
    model = _tiny_model()
    loader = torch.utils.data.DataLoader(_TinyDataset(), batch_size=2)
    schedule = StageSchedule(warmup_end=1, graph_end=2, full_end=3, contrastive_ramp_start=1, contrastive_ramp_end=2)
    cfg = TrainerConfig(total_epochs=3, schedule=schedule)
    trainer = Trainer(model, cfg, device="cpu")

    stats = {}
    for epoch in [1, 2, 3]:
        stats[epoch] = trainer.train_one_epoch(loader, epoch)

    assert stats[1]["stage"] == "warmup"
    assert stats[2]["stage"] == "graph"
    assert stats[3]["stage"] == "full"
    assert all(np.isfinite(s["mean_total_loss"]) for s in stats.values())
