import torch

from evitopo_gnn.models.hybrid_encoder import ViTConfig
from evitopo_gnn.models.evitopo_gnn import EviTopoGNN


def _tiny_model():
    vit_cfg = ViTConfig(image_size=64, patch_size=16, embed_dim=32, depth=4, num_heads=4,
                         mlp_ratio=2.0, lora_rank=4, tap_blocks=(1, 2, 3, 4))
    return EviTopoGNN(
        vit_cfg=vit_cfg, cnn_base_ch=8, fused_ch=16, window=4, decoded_feat_ch=16,
        graph_node_spacing=4, graph_min_spur_len=3, graph_gap_radius=16.0, graph_k_gap=2,
        gnn_edge_dim=8, gnn_hidden_dim=16, gnn_num_layers=2, link_hidden_dim=16,
        decoder_channels=16, contrastive_proj_dim=8,
    )


def test_forward_shapes():
    torch.manual_seed(0)
    model = _tiny_model()
    x = torch.rand(2, 3, 64, 64)
    out = model(x)
    assert len(out.final) == 2
    for o in out.final:
        assert o.prob.shape == (1, 1, 64, 64)
        assert o.uncertainty.shape == (1, 1, 64, 64)
        assert torch.all(o.prob >= 0) and torch.all(o.prob <= 1)
        assert torch.all(o.uncertainty >= 0) and torch.all(o.uncertainty <= 1)
    assert out.contrastive_embeddings.shape == (2, 8, 64, 64)


def test_backward_reaches_frozen_backbone_through_lora():
    torch.manual_seed(0)
    model = _tiny_model()
    x = torch.rand(1, 3, 64, 64)
    out = model(x)
    loss = out.final[0].prob.mean() + out.contrastive_embeddings.mean()
    loss.backward()

    lora_grad = model.encoder.vit.blocks[0].attn.q_proj.lora_B.grad
    assert lora_grad is not None and torch.any(lora_grad != 0)

    # the frozen base ViT projection must receive no gradient
    assert model.encoder.vit.blocks[0].attn.q_proj.base.weight.grad is None

    enc_grad = model.encoder.cnn.stem[0].weight.grad
    assert enc_grad is not None and torch.any(enc_grad != 0)


def test_inference_mode_applies_bridge_decision():
    torch.manual_seed(1)
    model = _tiny_model()
    model.eval()
    x = torch.rand(1, 3, 64, 64)
    with torch.no_grad():
        out = model(x, inference=True)
    assert out.accepted_bridge_masks is not None
    mask = out.accepted_bridge_masks[0]
    if mask is not None:
        assert mask.dtype == torch.bool
