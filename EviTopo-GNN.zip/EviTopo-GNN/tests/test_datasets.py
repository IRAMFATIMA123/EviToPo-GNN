import numpy as np
import pytest

PIL = pytest.importorskip("PIL")
from PIL import Image  # noqa: E402

from evitopo_gnn.data.datasets import RetinalVesselDataset


def test_retinal_vessel_dataset_roundtrip(tmp_path):
    ds_root = tmp_path / "DRIVE"
    for d in ["images", "manual", "mask"]:
        (ds_root / d).mkdir(parents=True)

    rng = np.random.default_rng(0)
    for i in range(3):
        img = (rng.random((48, 48, 3)) * 255).astype(np.uint8)
        Image.fromarray(img).save(ds_root / "images" / f"im{i}.png")
        manual = (rng.random((48, 48)) > 0.8).astype(np.uint8) * 255
        Image.fromarray(manual).save(ds_root / "manual" / f"im{i}.png")
        fov = np.ones((48, 48), dtype=np.uint8) * 255
        Image.fromarray(fov).save(ds_root / "mask" / f"im{i}.png")

    dataset = RetinalVesselDataset(str(tmp_path), "DRIVE")
    assert len(dataset) == 3
    image, vessel, fov, stem = dataset[0]
    assert image.shape == (3, 48, 48)
    assert vessel.shape == (1, 48, 48)
    assert fov.shape == (1, 48, 48)
    assert float(image.min()) >= 0.0 and float(image.max()) <= 1.0
    assert set(vessel.unique().tolist()) <= {0.0, 1.0}
