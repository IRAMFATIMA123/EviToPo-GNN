import numpy as np
import torch

from evitopo_gnn.models.graph_builder import VesselTopologyGraphBuilder, NODE_ENDPOINT, NODE_JUNCTION


def test_graph_builder_on_simple_cross():
    H = W = 64
    prob = torch.zeros(1, H, W)
    prob[0, 32, 4:60] = 1.0   # horizontal branch
    prob[0, 4:60, 32] = 1.0   # vertical branch (crosses -> one junction)
    unc = torch.full((1, H, W), 0.3)
    feat = torch.randn(6, H, W)

    builder = VesselTopologyGraphBuilder(node_spacing=6, min_spur_len=3, gap_radius=20.0, k_gap=2)
    graph = builder.build(prob, unc, feat)

    assert graph.num_nodes > 0
    assert graph.node_feat.shape == (graph.num_nodes, 6)
    assert graph.obs_edge_index.shape[0] == 2
    # a cross should produce at least one junction (degree >= 3)
    assert (graph.node_type == NODE_JUNCTION).any()
    assert (graph.node_type == NODE_ENDPOINT).any()


def test_graph_builder_gap_edges_only_from_eligible_sources():
    H = W = 64
    prob = torch.zeros(1, H, W)
    prob[0, 10, 5:25] = 1.0
    prob[0, 10, 35:55] = 1.0  # two disjoint branches within gap radius
    unc = torch.full((1, H, W), 0.9)  # high uncertainty everywhere
    feat = torch.randn(4, H, W)

    builder = VesselTopologyGraphBuilder(node_spacing=4, min_spur_len=2, gap_radius=25.0, k_gap=3, tau_c=0.3)
    graph = builder.build(prob, unc, feat)
    assert graph.gap_edge_index.shape[1] >= 0  # should not crash; may or may not find compatible pairs

    # junctions must never be gap sources
    if graph.gap_edge_index.shape[1] > 0:
        src = graph.gap_edge_index[0]
        assert not (graph.node_type[src] == NODE_JUNCTION).any()


def test_empty_image_returns_empty_graph():
    H = W = 32
    prob = torch.zeros(1, H, W)
    unc = torch.zeros(1, H, W)
    feat = torch.zeros(3, H, W)
    builder = VesselTopologyGraphBuilder()
    graph = builder.build(prob, unc, feat)
    assert graph.num_nodes == 0
    assert graph.obs_edge_index.shape == (2, 0)
    assert graph.gap_edge_index.shape == (2, 0)
