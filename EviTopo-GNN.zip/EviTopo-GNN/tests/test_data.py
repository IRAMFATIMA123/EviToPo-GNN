import numpy as np
import pytest

from evitopo_gnn.data.splits import fixed_train_val_test_split, leave_one_out_folds, k_fold_subject_disjoint, chase_db1_child_split
from evitopo_gnn.data.synthetic_gaps import apply_synthetic_gaps
from evitopo_gnn.data.transforms import TrainAugmentation, EvalTransform


def test_fixed_split_sizes_and_disjointness():
    stems = [f"img{i:02d}" for i in range(20)]
    split = fixed_train_val_test_split(stems, val_frac=0.1, test_frac=0.2, seed=0)
    assert len(split.train) + len(split.val) + len(split.test) == 20
    assert set(split.train) & set(split.val) == set()
    assert set(split.train) & set(split.test) == set()
    assert set(split.val) & set(split.test) == set()


def test_leave_one_out_each_fold_holds_out_one_test_image():
    stems = [f"s{i}" for i in range(10)]
    folds = leave_one_out_folds(stems, n_val=2, seed=0)
    assert len(folds) == 10
    for fold in folds:
        assert len(fold.test) == 1
        assert len(fold.val) == 2
        assert len(fold.train) == 7
        assert fold.test[0] not in fold.train
        assert fold.test[0] not in fold.val


def test_k_fold_subject_disjoint_keeps_subjects_together():
    subj = [f"s{i // 2}" for i in range(20)]  # pairs share a subject
    folds = k_fold_subject_disjoint(subj, k=5, n_val_subjects=1, seed=0)
    for fold in folds:
        train_subjects, val_subjects, test_subjects = set(fold.train), set(fold.val), set(fold.test)
        # no subject may appear on more than one side of a fold
        assert train_subjects.isdisjoint(val_subjects)
        assert train_subjects.isdisjoint(test_subjects)
        assert val_subjects.isdisjoint(test_subjects)
        # both items sharing a subject id land together wherever that subject goes
        assert fold.train.count(fold.train[0]) == 2 if fold.train else True
        for s in test_subjects:
            assert fold.test.count(s) == 2


def test_chase_child_split_keeps_both_eyes_together():
    stem_to_child = {f"child{i}_L": f"child{i}" for i in range(5)}
    stem_to_child.update({f"child{i}_R": f"child{i}" for i in range(5)})
    split = chase_db1_child_split(stem_to_child, val_children=["child0"], test_children=["child1"])
    assert "child0_L" in split.val and "child0_R" in split.val
    assert "child1_L" in split.test and "child1_R" in split.test


def test_synthetic_gaps_leaves_label_untouched_by_contract():
    H, W = 96, 96
    img = np.random.rand(H, W, 3).astype(np.float32)
    mask = np.zeros((H, W), dtype=np.float32)
    mask[40, 5:90] = 1.0
    mask[41, 5:90] = 1.0
    rng = np.random.default_rng(0)
    out_img, gaps = apply_synthetic_gaps(img, mask, rng, p=1.0)
    assert out_img.shape == img.shape
    assert len(gaps) >= 1
    for g in gaps:
        assert g.width_px <= 3.5  # "width at most 3 px" (with small estimation slack)
        assert 8 <= g.length_px <= 24


def test_synthetic_gaps_respects_probability_zero():
    H, W = 48, 48
    img = np.random.rand(H, W, 3).astype(np.float32)
    mask = np.zeros((H, W), dtype=np.float32)
    mask[20, 5:40] = 1.0
    rng = np.random.default_rng(0)
    out_img, gaps = apply_synthetic_gaps(img, mask, rng, p=0.0)
    assert len(gaps) == 0
    assert np.array_equal(out_img, img)


def test_train_augmentation_crops_to_patch_size():
    H, W = 40, 40
    sample = {
        "image": np.random.rand(H, W, 3).astype(np.float32),
        "vessel_mask": np.zeros((H, W), dtype=np.float32),
        "fov_mask": np.ones((H, W), dtype=np.float32),
    }
    aug = TrainAugmentation(patch_size=32, seed=0)
    out = aug(sample)
    assert out["image"].shape == (32, 32, 3)
    assert out["vessel_mask"].shape == (32, 32)


def test_eval_transform_is_identity():
    sample = {"image": np.zeros((4, 4, 3))}
    assert EvalTransform()(sample) is sample
