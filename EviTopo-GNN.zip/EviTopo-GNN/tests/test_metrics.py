import numpy as np

from evitopo_gnn.graph.topology_metrics import cl_dice_score, betti0_error
from evitopo_gnn.metrics.segmentation_metrics import pooled_confusion_counts, pixel_metrics_from_counts, pooled_auc_roc
from evitopo_gnn.metrics.calibration import expected_calibration_error, brier_score, negative_log_likelihood
from evitopo_gnn.metrics.uncertainty_metrics import auroc_error_detection, aurc


def _toy_masks():
    H = W = 64
    gt = np.zeros((H, W), dtype=np.float32)
    gt[30, 5:60] = 1
    gt[31, 5:60] = 1
    fov = np.ones((H, W), dtype=np.float32)
    return gt, fov


def test_cldice_perfect_prediction_is_one():
    gt, fov = _toy_masks()
    assert cl_dice_score(gt, gt, fov) == 1.0


def test_cldice_and_betti0_detect_a_gap():
    gt, fov = _toy_masks()
    pred = gt.copy()
    pred[30:32, 25:30] = 0
    assert cl_dice_score(pred, gt, fov) < 1.0
    assert betti0_error(pred, gt, fov) > 0.0


def test_pixel_metrics_from_counts():
    gt, fov = _toy_masks()
    counts = pooled_confusion_counts(gt, gt, fov)
    metrics = pixel_metrics_from_counts(counts)
    assert metrics["f1"] == 1.0
    assert metrics["precision"] == 1.0
    assert metrics["sensitivity"] == 1.0


def test_calibration_metrics_range():
    rng = np.random.default_rng(0)
    gt, _ = _toy_masks()
    probs = np.clip(gt * 0.8 + rng.random(gt.shape) * 0.2, 0, 1)
    ece = expected_calibration_error(probs, gt)
    brier = brier_score(probs, gt)
    nll = negative_log_likelihood(probs, gt)
    assert 0 <= ece <= 1
    assert 0 <= brier <= 1
    assert nll >= 0


def test_uncertainty_metrics_run():
    gt, _ = _toy_masks()
    pred = gt.copy()
    pred[30:32, 25:30] = 0
    unc = 1 - gt
    auc_err = auroc_error_detection(pred, gt, unc)
    aurc_val = aurc(pred, gt, unc)
    assert 0 <= auc_err <= 1
    assert aurc_val >= 0


def test_pooled_auc_roc_matches_known_case():
    probs = np.array([0.1, 0.4, 0.35, 0.8])
    labels = np.array([0, 0, 1, 1])
    auc = pooled_auc_roc(probs, labels)
    assert 0.5 <= auc <= 1.0
