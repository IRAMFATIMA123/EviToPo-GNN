"""Shared plotting style for ``make_figures.py``: a validated,
colorblind-safe categorical palette (fixed slot order -- never cycled
arbitrarily) plus consistent chart chrome (light surface, recessive
gridlines, no top/right spines). See the repository's data-viz notes in
``make_figures.py`` for the palette's provenance and validation.
"""

from __future__ import annotations

import matplotlib
import matplotlib.pyplot as plt

matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]

# Fixed categorical slot order (validated: worst adjacent CVD Delta-E 9.1,
# worst adjacent normal-vision Delta-E 19.6 -- both clear the >=8 / >=15 gates).
CAT = {
    "blue": "#2a78d6",
    "orange": "#eb6834",
    "aqua": "#1baf7a",
    "yellow": "#eda100",
    "magenta": "#e87ba4",
    "green": "#008300",
    "violet": "#6250d6",
    "red": "#e34948",
}
CAT_ORDER = ["blue", "orange", "aqua", "yellow", "magenta", "green", "violet", "red"]

SURFACE = "#fcfcfb"
PAGE = "#f9f9f7"
INK_PRIMARY = "#0b0b0b"
INK_SECONDARY = "#52514e"
INK_MUTED = "#898781"
GRIDLINE = "#e1e0d9"
BASELINE = "#c3c2b7"
GOOD = "#0ca30c"
CRITICAL = "#d03b3b"

OURS_COLOR = CAT["blue"]
BASELINE_COLOR = "#b9b8b2"  # neutral gray for "everything that isn't ours"


def style_axes(ax, hide_x_spine=False):
    ax.set_facecolor(SURFACE)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(BASELINE)
    ax.spines["bottom"].set_color(BASELINE)
    if hide_x_spine:
        ax.spines["bottom"].set_visible(False)
    ax.tick_params(colors=INK_MUTED, labelsize=8)
    ax.xaxis.label.set_color(INK_SECONDARY)
    ax.yaxis.label.set_color(INK_SECONDARY)
    ax.title.set_color(INK_PRIMARY)
    ax.grid(axis="x", color=GRIDLINE, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)


def new_figure(figsize=(8, 5), facecolor=PAGE):
    fig = plt.figure(figsize=figsize, facecolor=facecolor)
    return fig
