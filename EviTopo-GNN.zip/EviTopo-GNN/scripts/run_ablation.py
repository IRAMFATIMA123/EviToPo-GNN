#!/usr/bin/env python3
"""Drives one row of Table 5's component ablation (Section 6.1).

Honesty check first: not every row is a flag flip. Some ablation rows are
reached purely through constructor/config arguments already in this repo;
others name an architectural variant (e.g. "kNN feature graph" for A3a)
that would need its own module before it is runnable, and this script says
so instead of silently approximating it.

Directly runnable from this script (``--variant <id>``):

    A9    full model (defaults)
    A5a   gate_mode=uncertainty_only  (uncertainty term of the gate only)
    A5b   gate_mode=edge_only          (edge term of the gate only)
    A9g   gate_mode=edge_only, full schedule (uncertainty replaced by a
          constant; same gate as A5b, run once the rest of the model -
          link loss, synthetic gaps, contrastive loss - is also active)
    A6    A9 with schedule.use_synthetic_gaps forced off
    A10   A9 with a ViT-B/16-sized encoder (depth/width swapped in vit_cfg)
    A12   A9 with the ViT branch's contribution removed (fusion bypassed to
          zero -- an approximation of "CNN only", see the --variant help)
    A13   A9 with the full-resolution CNN skip replaced by zeros (an
          approximation of "ViT only")

Named but **not yet wired up** (would need a dedicated module before this
script can run them -- raises ``NotImplementedError`` with a pointer to
where that module would plug in):

    A1, A2, A2p   softmax vs. evidential head, capacity-matched conv swap
    A3, A3a, A3b  graph-free / kNN feature graph / local pixel propagation
    A4a, A4, A4c  gap-edge and link-loss toggles, geodesic (VGN-style) edges
    A7, A8        generic vs. topology-aware contrastive variants
    A11           Kolmogorov-Arnold node update in the GNN

Usage:

    python scripts/run_ablation.py --variant A5a --config configs/drive.yaml \\
        --seed 0 --output runs/ablation/A5a_seed0
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import torch  # noqa: E402

from evitopo_gnn.utils.config import load_config  # noqa: E402
from evitopo_gnn.utils.seed import set_seed  # noqa: E402
from evitopo_gnn.models.hybrid_encoder import ViTConfig  # noqa: E402
from evitopo_gnn.models.evitopo_gnn import EviTopoGNN  # noqa: E402
from evitopo_gnn.engine.trainer import Trainer, TrainerConfig  # noqa: E402
from evitopo_gnn.losses.combined_objective import StageSchedule  # noqa: E402

NOT_WIRED_UP = {
    "A1": "softmax coarse/final heads instead of evidential (swap EvidentialHead for a plain softmax head)",
    "A2": "this repo's A2 IS the evidential-head default; A1 above is the thing being compared against",
    "A2p": "capacity-matched conv blocks in place of the graph stage (models/graph_builder.py bypass)",
    "A3": "graph with observed edges only, no gap candidates (set graph_gap_radius=0 as an approximation)",
    "A3a": "kNN feature-space graph replacing the centreline graph (new graph_builder variant)",
    "A3b": "local 4-connected pixel propagation replacing the GNN (new module)",
    "A4a": "gap edges with gate=1 and no link loss (set gnn_gate_mode has no 'off' value yet; needs a constant-1 mode)",
    "A4": "A4a + link loss (needs the A4a constant-gate mode above first)",
    "A4c": "geodesic (VGN-style) gap edges instead of orientation-gated ones (new graph_builder variant)",
    "A7": "generic vessel-vs-background contrastive loss instead of topology-aware (new loss variant)",
    "A8": "topology contrast with uniform (non-uncertainty-weighted) anchors (set ContrastiveConfig.eta=0 as an approximation)",
    "A11": "Kolmogorov-Arnold Network node update instead of the 2-layer MLP (new gnn_layers.py variant)",
}

RUNNABLE = {"A9", "A5a", "A5b", "A9g", "A6", "A10", "A12", "A13"}


def build_model_for_variant(cfg: dict, variant: str) -> EviTopoGNN:
    m = cfg["model"]
    vit_cfg = ViTConfig(**m["vit"])
    gate_mode = "full"
    if variant == "A5a":
        gate_mode = "uncertainty_only"
    elif variant in ("A5b", "A9g"):
        gate_mode = "edge_only"

    if variant == "A10":
        vit_cfg = ViTConfig(**{**m["vit"], "embed_dim": 768, "depth": 12, "num_heads": 12, "mlp_ratio": 4.0})

    model = EviTopoGNN(
        vit_cfg=vit_cfg, cnn_base_ch=m["encoder"]["cnn_base_ch"], fused_ch=m["encoder"]["fused_ch"],
        window=m["encoder"]["window"], decoded_feat_ch=m["decoded_feat_ch"],
        graph_node_spacing=m["graph"]["node_spacing"], graph_min_spur_len=m["graph"]["min_spur_len"],
        graph_gap_radius=m["graph"]["gap_radius"], graph_k_gap=m["graph"]["k_gap"],
        graph_tau_u=m["graph"]["tau_u"], graph_tau_c=m["graph"]["tau_c"],
        gnn_edge_dim=m["gnn"]["edge_dim"], gnn_hidden_dim=m["gnn"]["hidden_dim"],
        gnn_num_layers=m["gnn"]["num_layers"], gnn_gate_exponent=m["gnn"]["gate_exponent"], gnn_gate_mode=gate_mode,
        link_hidden_dim=m["link"]["hidden_dim"], decoder_channels=m["decoder"]["channels"],
        contrastive_proj_dim=m["contrastive"]["proj_dim"], tau_link=m["link"]["tau_link"],
    )

    if variant == "A12":  # approximate "without ViT branch": zero the ViT fusion contribution
        for fusion in model.encoder.fusions:
            torch.nn.init.zeros_(fusion.k_proj.weight)
            torch.nn.init.zeros_(fusion.v_proj.weight)
            for p in list(fusion.k_proj.parameters()) + list(fusion.v_proj.parameters()):
                p.requires_grad_(False)
    if variant == "A13":  # approximate "without full-resolution CNN branch": zero the skip
        torch.nn.init.zeros_(model.encoder.cnn.stem[0].weight)
        for p in model.encoder.cnn.stem.parameters():
            p.requires_grad_(False)

    return model


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--variant", required=True, choices=sorted(RUNNABLE | set(NOT_WIRED_UP)))
    parser.add_argument("--config", required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output", default="runs/ablation/variant")
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    if args.variant in NOT_WIRED_UP:
        raise NotImplementedError(
            f"Ablation {args.variant} needs: {NOT_WIRED_UP[args.variant]}. "
            "This script only runs the variants reachable through existing config/constructor "
            "flags (see RUNNABLE in this file); add the module above to extend it."
        )

    cfg = load_config(args.config)
    set_seed(args.seed)
    model = build_model_for_variant(cfg, args.variant).to(args.device)

    schedule = StageSchedule(**cfg["schedule"])
    if args.variant == "A6":
        schedule.graph_end = schedule.warmup_end  # disables synthetic gaps (use_synthetic_gaps gates on stage)

    total_epochs = args.epochs or schedule.full_end
    trainer_cfg = TrainerConfig(
        total_epochs=total_epochs, base_lr=cfg["optim"]["base_lr"], weight_decay=cfg["optim"]["weight_decay"],
        tau_link=cfg["model"]["link"]["tau_link"], link_positive_weight=cfg["loss"]["link_positive_weight"],
        grad_clip_norm=cfg["optim"]["grad_clip_norm"], schedule=schedule,
    )
    trainer = Trainer(model, trainer_cfg, device=args.device)

    print(f"Built variant {args.variant} ({sum(p.numel() for p in model.parameters()):,} parameters, "
          f"{sum(p.numel() for p in model.parameters() if p.requires_grad):,} trainable).")
    print("Wire this up to a DataLoader exactly as in scripts/train.py to actually train it; "
          "this entry point's job is constructing the right variant, not duplicating the training loop.")
    return trainer


if __name__ == "__main__":
    main()
