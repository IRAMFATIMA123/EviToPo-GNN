#!/usr/bin/env python3
"""Regenerates Tables 1-5 of the Results section as CSV (``results/data/``)
and as rendered Markdown + LaTeX (``results/tables/``).

The underlying numbers are the paper's *published* results, transcribed in
``scripts/_paper_reported_results.py`` (see that module's docstring for why
-- reproducing them from scratch needs the five datasets, the RETFound
checkpoint and ~the compute budget described in Section 4.3/6.3, none of
which is available in this environment). This script is the single place
that turns those numbers into the table artefacts; run it again after
editing the source data to regenerate everything:

    python scripts/make_tables.py
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

import _paper_reported_results as R  # noqa: E402

DATA_DIR = ROOT / "results" / "data"
TABLE_DIR = ROOT / "results" / "tables"
DATA_DIR.mkdir(parents=True, exist_ok=True)
TABLE_DIR.mkdir(parents=True, exist_ok=True)


def fmt(x, nd=4):
    return "" if x is None else f"{x:.{nd}f}"


# --------------------------------------------------------------------------- #
# Table 1
# --------------------------------------------------------------------------- #
def write_table1():
    csv_path = DATA_DIR / "table1_in_domain.csv"
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["method", "dataset", "f1", "cldice", "f1_significant", "cldice_significant", "is_ours"])
        for method in R.TABLE1_METHODS:
            for ds in R.DATASETS:
                f1, cld = R.TABLE1[method][ds]
                sig = R.TABLE1_SIGNIFICANT[ds]
                is_ours = method.startswith("EviTopo-GNN")
                w.writerow([method, ds, f1, cld, sig["F1"] and is_ours, sig["clDice"] and is_ours, is_ours])

    lines = [
        "# Table 1. In-domain comparison across the five datasets",
        "",
        "F1 (micro-averaged over FOV test pixels at threshold 0.5) and clDice (image-level mean), "
        "each averaged over five seeds. **Bold**: EviTopo-GNN; \\* Holm-adjusted p < 0.05 against the "
        "strongest baseline (Table 2).",
        "",
        "| Method | " + " | ".join(f"{ds} F1 | {ds} clDice" for ds in R.DATASETS) + " |",
        "|---" * (1 + 2 * len(R.DATASETS)) + "|",
    ]
    for method in R.TABLE1_METHODS:
        is_ours = method.startswith("EviTopo-GNN")
        cells = []
        for ds in R.DATASETS:
            f1, cld = R.TABLE1[method][ds]
            sig = R.TABLE1_SIGNIFICANT[ds]
            f1_s = fmt(f1) + ("*" if is_ours and sig["F1"] else "")
            cld_s = fmt(cld) + ("*" if is_ours and sig["clDice"] else "")
            if is_ours:
                f1_s, cld_s = f"**{f1_s}**", f"**{cld_s}**"
            cells += [f1_s, cld_s]
        name = f"**{method}**" if is_ours else method
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    (TABLE_DIR / "table1_in_domain.md").write_text("\n".join(lines) + "\n")

    tex = [
        r"\begin{table}[t]", r"\centering",
        r"\caption{In-domain comparison across the five datasets (F1, clDice; mean over five seeds). "
        r"Bold: EviTopo-GNN; * Holm-adjusted $p<0.05$ against the strongest baseline.}",
        r"\begin{tabular}{l" + "cc" * len(R.DATASETS) + "}", r"\toprule",
        "Method & " + " & ".join(f"\\multicolumn{{2}}{{c}}{{{ds}}}" for ds in R.DATASETS) + r" \\",
        " & " + " & ".join("F1 & clDice" for _ in R.DATASETS) + r" \\", r"\midrule",
    ]
    for method in R.TABLE1_METHODS:
        is_ours = method.startswith("EviTopo-GNN")
        cells = []
        for ds in R.DATASETS:
            f1, cld = R.TABLE1[method][ds]
            sig = R.TABLE1_SIGNIFICANT[ds]
            f1_s = fmt(f1) + ("*" if is_ours and sig["F1"] else "")
            cld_s = fmt(cld) + ("*" if is_ours and sig["clDice"] else "")
            if is_ours:
                f1_s, cld_s = f"\\textbf{{{f1_s}}}", f"\\textbf{{{cld_s}}}"
            cells += [f1_s, cld_s]
        name = f"\\textbf{{{method}}}" if is_ours else method
        tex.append(f"{name} & " + " & ".join(cells) + r" \\")
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TABLE_DIR / "table1_in_domain.tex").write_text("\n".join(tex) + "\n")


# --------------------------------------------------------------------------- #
# Table 2
# --------------------------------------------------------------------------- #
def write_table2():
    csv_path = DATA_DIR / "table2_paired_stats.csv"
    fields = ["dataset", "n_units", "unit", "comparator", "d_f1", "f1_ci_lo", "f1_ci_hi", "p_f1",
              "d_cldice", "cldice_ci_lo", "cldice_ci_hi", "p_cldice", "d_ece", "ece_ci_lo", "ece_ci_hi",
              "p_ece", "ece_comp", "ece_ours", "betti_comp", "betti_ours"]
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(fields)
        for row in R.TABLE2:
            w.writerow([
                row["dataset"], row["n_units"], row["unit"], row["comparator"],
                row["d_f1"], row["f1_ci"][0], row["f1_ci"][1], row["p_f1"],
                row["d_cldice"], row["cldice_ci"][0], row["cldice_ci"][1], row["p_cldice"],
                row["d_ece"], row["ece_ci"][0], row["ece_ci"][1], row["p_ece"],
                row["ece_comp"], row["ece_ours"], row["betti_comp"], row["betti_ours"],
            ])

    def p_str(p):
        return "< 0.001" if p <= 0.001 else f"{p:.3f}"

    lines = [
        "# Table 2. Paired comparison with the strongest baseline",
        "",
        "Delta: mean paired per-unit difference (EviTopo-GNN minus comparator); 95% CI from a paired "
        "bootstrap over test units (10,000 resamples); p: Holm-adjusted paired Wilcoxon signed-rank. "
        "Units are images, or children on CHASE_DB1 (descriptive only).",
        "",
        "| Dataset (units), comparator | ΔF1 [95% CI] | p | ΔclDice [95% CI] | p | ΔECE [95% CI] | p | ECE comp.→ours | Betti-0 comp.→ours |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for row in R.TABLE2:
        lines.append(
            f"| {row['dataset']} ({row['n_units']} {row['unit']}) {row['comparator']} "
            f"| +{row['d_f1']:.4f} [{row['f1_ci'][0]:+.4f}, {row['f1_ci'][1]:+.4f}] | {p_str(row['p_f1'])} "
            f"| +{row['d_cldice']:.4f} [{row['cldice_ci'][0]:+.4f}, {row['cldice_ci'][1]:+.4f}] | {p_str(row['p_cldice'])} "
            f"| {row['d_ece']:.4f} [{row['ece_ci'][0]:+.4f}, {row['ece_ci'][1]:+.4f}] | {p_str(row['p_ece'])} "
            f"| {row['ece_comp']:.4f} → {row['ece_ours']:.4f} "
            f"| {row['betti_comp']:.3f} → {row['betti_ours']:.3f} |"
        )
    (TABLE_DIR / "table2_paired_stats.md").write_text("\n".join(lines) + "\n")


# --------------------------------------------------------------------------- #
# Table 3
# --------------------------------------------------------------------------- #
def write_table3():
    csv_path = DATA_DIR / "table3_uncertainty.csv"
    cols = ["method", "ece_pooled", "ece_vessel", "ece_edge", "brier", "nll", "auroc_err", "aurc"]
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for method, vals in R.TABLE3.items():
            w.writerow([method] + [vals[c] for c in cols[1:]])

    lines = [
        "# Table 3. Uncertainty quality on DRIVE (test images only)",
        "",
        "Calibration of the probability (ECE pooled, ECE on ground-truth vessel pixels, ECE on the 3 px "
        "edge band; Brier; NLL) and ranking quality of the uncertainty (AUROC-err; AURC), against MC "
        "dropout and a deep ensemble sharing the complete pipeline.",
        "",
        "| Method | ECE pooled | ECE vessel | ECE edge band | Brier | NLL | AUROC-err | AURC |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for method, vals in R.TABLE3.items():
        bold = method.startswith("EviTopo")
        row = f"| {method} | {vals['ece_pooled']:.4f} | {vals['ece_vessel']:.4f} | {vals['ece_edge']:.4f} | {vals['brier']:.4f} | {vals['nll']:.4f} | {vals['auroc_err']:.3f} | {vals['aurc']:.4f} |"
        lines.append(row)
    (TABLE_DIR / "table3_uncertainty.md").write_text("\n".join(lines) + "\n")


# --------------------------------------------------------------------------- #
# Table 4
# --------------------------------------------------------------------------- #
def write_table4():
    csv_path = DATA_DIR / "table4_reconnections.csv"
    cols = ["variant", "region", "gaps", "recall", "precision", "false_per_image", "cldice_bad_bridges"]
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for row in R.TABLE4:
            w.writerow([row[c] for c in cols])

    lines = [
        "# Table 4. Correct and false reconnections in the controlled gap test (DRIVE)",
        "",
        "Recall denominator: gaps introduced. Bridging precision: correct reconnections / reconnections "
        "made. A false reconnection joins endpoints in different ground-truth components or follows a "
        "path > 2 px from the degraded centreline.",
        "",
        "| Variant | Region | Gaps | Recall | Bridging precision | False reconnections / image | clDice from bad bridges |",
        "|---|---|---|---|---|---|---|",
    ]
    for row in R.TABLE4:
        prec = fmt(row["precision"], 3) or "n/a"
        false_pi = fmt(row["false_per_image"], 2) or "n/a"
        cld = fmt(row["cldice_bad_bridges"]) or "n/a"
        lines.append(f"| {row['variant']} | {row['region']} | {row['gaps']} | {row['recall']:.3f} | {prec} | {false_pi} | {cld} |")
    (TABLE_DIR / "table4_reconnections.md").write_text("\n".join(lines) + "\n")


# --------------------------------------------------------------------------- #
# Table 5
# --------------------------------------------------------------------------- #
def write_table5():
    csv_path = DATA_DIR / "table5_ablation.csv"
    cols = ["id", "variant", "drive_f1", "drive_cldice", "drive_betti0", "drive_ece", "fives_f1", "fives_cldice"]
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for row in R.TABLE5:
            w.writerow([row[c] for c in cols])

    lines = [
        "# Table 5. Component ablation on DRIVE and FIVES",
        "",
        "Mean over five seeds; each row changes one factor relative to the row it names (A9 is the full "
        "model). C1/C2: augmentation controls on DRIVE only ('-' not run).",
        "",
        "| ID | Variant (one factor changed) | DRIVE F1 | DRIVE clDice | DRIVE Betti-0 | DRIVE ECE | FIVES F1 | FIVES clDice |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for row in R.TABLE5:
        bold = row["id"] == R.TABLE5_BOLD_ID
        vals = [fmt(row["drive_f1"]), fmt(row["drive_cldice"]), fmt(row["drive_betti0"], 3), fmt(row["drive_ece"]),
                fmt(row["fives_f1"]), fmt(row["fives_cldice"])]
        vals = [v if v else "-" for v in vals]
        if bold:
            vals = [f"**{v}**" for v in vals]
            name = f"**{row['id']}**"
            variant = f"**{row['variant']}**"
        else:
            name, variant = row["id"], row["variant"]
        lines.append(f"| {name} | {variant} | " + " | ".join(vals) + " |")
    (TABLE_DIR / "table5_ablation.md").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    write_table1()
    write_table2()
    write_table3()
    write_table4()
    write_table5()
    print(f"Wrote CSVs to {DATA_DIR}")
    print(f"Wrote rendered tables to {TABLE_DIR}")
