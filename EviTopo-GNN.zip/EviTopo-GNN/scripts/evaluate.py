#!/usr/bin/env python3
"""CLI entry point for evaluating a trained checkpoint on a test split,
reproducing the Section 4.2/4.4 aggregation (pooled F1 per seed, per-image
clDice/Betti-0/ECE for the per-unit estimand).

    python scripts/evaluate.py --config configs/drive.yaml \\
        --checkpoint runs/drive_seed0/best.pt --split test \\
        --output results/data/drive_seed0_predictions.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import torch  # noqa: E402

from evitopo_gnn.utils.config import load_config  # noqa: E402
from evitopo_gnn.utils.checkpoint import load_checkpoint  # noqa: E402
from evitopo_gnn.data.datasets import RetinalVesselDataset  # noqa: E402
from evitopo_gnn.data.transforms import EvalTransform  # noqa: E402
from evitopo_gnn.engine.evaluator import Evaluator, pool_counts_across_images  # noqa: E402
from evitopo_gnn.metrics.segmentation_metrics import pixel_metrics_from_counts  # noqa: E402
from scripts.train import build_model, build_split  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--split", choices=["val", "test"], default="test")
    parser.add_argument("--output", default=None)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    cfg = load_config(args.config)
    model = build_model(cfg).to(args.device)
    load_checkpoint(args.checkpoint, model, map_location=args.device)

    split = build_split(cfg)
    stems = split.test if args.split == "test" else split.val
    dataset = RetinalVesselDataset(cfg["dataset"]["root"], cfg["dataset"]["name"], stems, transform=EvalTransform())

    evaluator = Evaluator(model, device=args.device, window=cfg["inference"]["window"],
                           stride=cfg["inference"]["stride"], threshold=cfg["inference"]["threshold"])
    results = evaluator.evaluate_dataset(dataset)

    counts = pool_counts_across_images(results)
    pixel_metrics = pixel_metrics_from_counts(counts)
    cldice_mean = sum(r.cl_dice for r in results) / max(len(results), 1)
    betti0_mean = sum(r.betti0 for r in results) / max(len(results), 1)
    ece_mean = sum(r.ece for r in results) / max(len(results), 1)

    summary = {
        "dataset": cfg["dataset"]["name"], "split": args.split, "n_images": len(results),
        "pixel_metrics": pixel_metrics, "cldice_mean": cldice_mean, "betti0_mean": betti0_mean,
        "ece_mean": ece_mean,
        "per_image": [
            {"stem": r.stem, "cldice": r.cl_dice, "betti0": r.betti0, "ece": r.ece, "f1": pixel_metrics_from_counts(r.counts)["f1"]}
            for r in results
        ],
    }
    print(json.dumps({k: v for k, v in summary.items() if k != "per_image"}, indent=2))

    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(json.dumps(summary, indent=2))
        print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
