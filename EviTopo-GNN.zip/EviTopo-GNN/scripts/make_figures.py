#!/usr/bin/env python3
"""Regenerates the figures accompanying the Results section (Section 5-6)
from the published numbers in ``scripts/_paper_reported_results.py`` (see
that module's docstring and ``scripts/make_tables.py`` for why these are
transcribed values rather than a live re-run).

Produces, in ``results/figures/``:

    fig1_pipeline.png            Fig. 1: the five-stage pipeline (schematic)
    fig2_f1_cldice_by_dataset.png  Table 1: F1 & clDice, every method, per dataset
    fig3_betti0_slopegraph.png     Table 2: Betti-0 error, comparator -> ours
    fig4_paired_delta_forest.png   Table 2: paired Delta F1/clDice/ECE with 95% CI
    fig5_uncertainty_quality.png   Table 3: ECE by region + ranking quality
    fig6_reconnections.png         Table 4: bridging recall/precision/false reconnections
    fig7a_ablation_overlap.png     Table 5: F1 / clDice across the ablation sequence
    fig7b_ablation_topology.png    Table 5: Betti-0 / ECE across the ablation sequence
    fig8_latency_breakdown.png     Section 6.3: per-stage tile latency (stacked bar)

Figure choices follow this repo's data-viz conventions (``_viz_style.py``):
one y-axis per chart (never dual-axis), a fixed validated categorical
palette used in a stable slot order, "ours" picked out with the first
categorical slot against neutral gray for everything else, and a plain
bar/line/slope form chosen for what the data's job actually is (magnitude,
change, or ranked comparison) rather than decoration.

Run: ``python scripts/make_figures.py``
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

import _paper_reported_results as R  # noqa: E402
from _viz_style import (  # noqa: E402
    CAT, CAT_ORDER, SURFACE, PAGE, INK_PRIMARY, INK_SECONDARY, INK_MUTED,
    GRIDLINE, BASELINE, GOOD, CRITICAL, OURS_COLOR, BASELINE_COLOR,
    style_axes, new_figure,
)

FIG_DIR = ROOT / "results" / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)
DPI = 160


# --------------------------------------------------------------------------- #
# Fig. 1: pipeline schematic
# --------------------------------------------------------------------------- #
def fig1_pipeline():
    fig, ax = plt.subplots(figsize=(13, 3.6), facecolor=PAGE)
    ax.set_facecolor(PAGE)
    stages = [
        ("1. Hybrid\nViT-CNN encoder", CAT["blue"], "Section 3.2"),
        ("2. Evidential\ncoarse head", CAT["orange"], "Section 3.3 — P_c, U_c"),
        ("3. Vessel-topology\ngraph + gap edges", CAT["aqua"], "Section 3.4"),
        ("4. Uncertainty-gated\nGNN + link head", CAT["violet"], "Section 3.5-3.6"),
        ("5. Graph-to-pixel\ndecoder", CAT["red"], "Section 3.7 — P, U, G"),
    ]
    n = len(stages)
    box_w, box_h, gap = 2.1, 1.3, 0.55
    total_w = n * box_w + (n - 1) * gap
    x0 = -total_w / 2
    y0 = -box_h / 2

    for i, (label, color, note) in enumerate(stages):
        x = x0 + i * (box_w + gap)
        rect = plt.Rectangle((x, y0), box_w, box_h, facecolor=SURFACE, edgecolor=color, linewidth=2.5, zorder=3)
        ax.add_patch(rect)
        ax.text(x + box_w / 2, y0 + box_h / 2 + 0.12, label, ha="center", va="center",
                fontsize=10.5, color=INK_PRIMARY, fontweight="bold", zorder=4)
        ax.text(x + box_w / 2, y0 - 0.32, note, ha="center", va="center", fontsize=8, color=INK_MUTED)
        if i < n - 1:
            ax.annotate("", xy=(x + box_w + gap - 0.05, 0), xytext=(x + box_w + 0.05, 0),
                        arrowprops=dict(arrowstyle="-|>", color=INK_SECONDARY, lw=2), zorder=2)

    ax.annotate("", xy=(x0 - 0.05, 0), xytext=(x0 - 0.85, 0),
                arrowprops=dict(arrowstyle="-|>", color=INK_SECONDARY, lw=2))
    ax.text(x0 - 0.95, 0.05, "X, M", ha="right", va="center", fontsize=10, color=INK_PRIMARY)
    last_x = x0 + (n - 1) * (box_w + gap) + box_w
    ax.annotate("", xy=(last_x + 0.85, 0), xytext=(last_x + 0.05, 0),
                arrowprops=dict(arrowstyle="-|>", color=INK_SECONDARY, lw=2))
    ax.text(last_x + 0.95, 0.05, "P, U, G", ha="left", va="center", fontsize=10, color=INK_PRIMARY, fontweight="bold")

    ax.set_xlim(x0 - 1.3, last_x + 1.6)
    ax.set_ylim(-1.3, 1.1)
    ax.axis("off")
    ax.set_title("Fig. 1 — The EviTopo-GNN pipeline (Eq. 1): five stages, Section 3",
                 fontsize=12, color=INK_PRIMARY, pad=14)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig1_pipeline.png", dpi=DPI, facecolor=PAGE)
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Fig. 2: Table 1 -- F1 & clDice per dataset, all methods (horizontal bars)
# --------------------------------------------------------------------------- #
def fig2_table1():
    fig, axes = plt.subplots(2, len(R.DATASETS), figsize=(20, 11), facecolor=PAGE, sharex="row")
    methods = R.TABLE1_METHODS

    for row, metric_idx, metric_name in [(0, 0, "F1"), (1, 1, "clDice")]:
        for col, ds in enumerate(R.DATASETS):
            ax = axes[row, col]
            values = [R.TABLE1[m][ds][metric_idx] for m in methods]
            order = np.argsort(values)
            sorted_methods = [methods[i] for i in order]
            sorted_values = [values[i] for i in order]
            colors = [OURS_COLOR if m.startswith("EviTopo") else BASELINE_COLOR for m in sorted_methods]
            y = np.arange(len(sorted_methods))
            ax.barh(y, sorted_values, color=colors, zorder=3, height=0.7)
            ax.set_yticks(y)
            ax.set_yticklabels(sorted_methods if col == 0 else ["" for _ in sorted_methods], fontsize=8)
            ax.set_xlim(0.70, 0.90)
            if row == 0:
                ax.set_title(ds, fontsize=12, color=INK_PRIMARY, fontweight="bold")
            if col == 0:
                ax.set_ylabel(metric_name, fontsize=11, color=INK_SECONDARY, fontweight="bold")
            style_axes(ax)

    fig.suptitle("Fig. 2 — Table 1: F1 and clDice by method and dataset (mean over 5 seeds)\n"
                 "blue = EviTopo-GNN, gray = retrained baselines", fontsize=13, color=INK_PRIMARY)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(FIG_DIR / "fig2_f1_cldice_by_dataset.png", dpi=DPI, facecolor=PAGE)
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Fig. 3: Table 2 -- Betti-0 slopegraph (comparator -> ours)
# --------------------------------------------------------------------------- #
def fig3_betti0_slope():
    fig, ax = plt.subplots(figsize=(7, 5.5), facecolor=PAGE)
    xs = [0, 1]
    for row in R.TABLE2:
        ys = [row["betti_comp"], row["betti_ours"]]
        ax.plot(xs, ys, color=INK_MUTED, lw=1.6, zorder=2)
        ax.scatter([0], [ys[0]], color=BASELINE_COLOR, s=70, zorder=3, edgecolor=INK_PRIMARY, linewidth=0.6)
        ax.scatter([1], [ys[1]], color=OURS_COLOR, s=70, zorder=3, edgecolor=INK_PRIMARY, linewidth=0.6)
        pct = 100 * (row["betti_comp"] - row["betti_ours"]) / row["betti_comp"]
        ax.annotate(f"{row['dataset']} (−{pct:.0f}%)", xy=(1.03, ys[1]), va="center", fontsize=9, color=INK_PRIMARY)
        ax.annotate(f"{row['betti_comp']:.3f}", xy=(-0.06, ys[0]), va="center", ha="right", fontsize=8, color=INK_MUTED)

    ax.set_xlim(-0.5, 1.9)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Strongest baseline", "EviTopo-GNN"], fontsize=10, color=INK_SECONDARY)
    ax.set_ylabel("Betti-0 error (lower is better)", fontsize=10, color=INK_SECONDARY)
    style_axes(ax)
    ax.grid(axis="y", color=GRIDLINE, linewidth=0.8)
    ax.grid(axis="x", visible=False)
    ax.set_title("Fig. 3 — Table 2: zero-dimensional Betti error, comparator → EviTopo-GNN\n"
                 "(23–35% reduction across datasets)", fontsize=11.5, color=INK_PRIMARY)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig3_betti0_slopegraph.png", dpi=DPI, facecolor=PAGE)
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Fig. 4: Table 2 -- paired Delta forest plot (F1, clDice, ECE)
# --------------------------------------------------------------------------- #
def fig4_forest():
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), facecolor=PAGE, sharey=True)
    specs = [("d_f1", "f1_ci", "p_f1", "ΔF1"), ("d_cldice", "cldice_ci", "p_cldice", "ΔclDice"),
             ("d_ece", "ece_ci", "p_ece", "ΔECE")]
    datasets = [row["dataset"] for row in R.TABLE2]
    y = np.arange(len(datasets))[::-1]

    for ax, (dkey, cikey, pkey, title) in zip(axes, specs):
        for i, row in enumerate(R.TABLE2):
            d = row[dkey]
            lo, hi = row[cikey]
            sig = row[pkey] <= 0.05
            color = OURS_COLOR if sig else INK_MUTED
            marker = "o" if sig else "o"
            fill = color if sig else "none"
            ax.plot([lo, hi], [y[i], y[i]], color=color, lw=1.8, zorder=2)
            ax.scatter([d], [y[i]], s=60, facecolor=fill, edgecolor=color, linewidth=1.6, zorder=3)
        ax.axvline(0, color=BASELINE, lw=1.2, linestyle="--", zorder=1)
        ax.set_title(title, fontsize=11.5, color=INK_PRIMARY)
        style_axes(ax)
        ax.grid(axis="y", visible=False)

    axes[0].set_yticks(y)
    axes[0].set_yticklabels(datasets, fontsize=10, color=INK_SECONDARY)
    handles = [
        plt.Line2D([0], [0], marker="o", color=OURS_COLOR, linestyle="", markersize=8, label="Holm-adjusted p ≤ 0.05"),
        plt.Line2D([0], [0], marker="o", color=INK_MUTED, linestyle="", markersize=8, markerfacecolor="none", label="not significant"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=2, frameon=False, fontsize=9, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle("Fig. 4 — Table 2: paired per-unit differences vs. the strongest baseline, 95% bootstrap CI",
                 fontsize=13, color=INK_PRIMARY)
    fig.tight_layout(rect=[0, 0.05, 1, 0.92])
    fig.savefig(FIG_DIR / "fig4_paired_delta_forest.png", dpi=DPI, facecolor=PAGE)
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Fig. 5: Table 3 -- uncertainty quality
# --------------------------------------------------------------------------- #
def fig5_uncertainty():
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), facecolor=PAGE)
    methods = list(R.TABLE3.keys())
    colors = [BASELINE_COLOR, "#8a8a86", OURS_COLOR]

    ax = axes[0]
    regions = ["ece_pooled", "ece_vessel", "ece_edge"]
    region_labels = ["Pooled", "Vessel px", "Edge band (±3px)"]
    x = np.arange(len(regions))
    width = 0.25
    for i, m in enumerate(methods):
        vals = [R.TABLE3[m][r] for r in regions]
        ax.bar(x + (i - 1) * width, vals, width=width, color=colors[i], label=m, zorder=3)
    ax.set_xticks(x)
    ax.set_xticklabels(region_labels, fontsize=10, color=INK_SECONDARY)
    ax.set_ylabel("ECE (lower is better)", fontsize=10, color=INK_SECONDARY)
    ax.set_title("ECE by pixel region (DRIVE)", fontsize=11.5, color=INK_PRIMARY)
    ax.legend(frameon=False, fontsize=8.5)
    style_axes(ax)

    ax = axes[1]
    metrics = ["auroc_err", "aurc"]
    x = np.arange(len(metrics))
    for i, m in enumerate(methods):
        vals = [R.TABLE3[m][k] for k in metrics]
        # AURC is displayed x10 so both bars are legible on one shared axis
        # (never a second y-scale); the x-tick label says so explicitly.
        display_vals = [vals[0], vals[1] * 10]
        ax.bar(x + (i - 1) * width, display_vals, width=width, color=colors[i], label=m, zorder=3)
    ax.set_xticks(x)
    ax.set_xticklabels(["AUROC-err", "AURC × 10"], fontsize=10, color=INK_SECONDARY)
    ax.set_title("Error-ranking quality (DRIVE)", fontsize=11.5, color=INK_PRIMARY)
    style_axes(ax)

    fig.suptitle("Fig. 5 — Table 3: calibration and uncertainty-ranking quality vs. MC dropout / deep ensemble",
                 fontsize=13, color=INK_PRIMARY)
    fig.tight_layout(rect=[0, 0, 1, 0.90])
    fig.savefig(FIG_DIR / "fig5_uncertainty_quality.png", dpi=DPI, facecolor=PAGE)
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Fig. 6: Table 4 -- reconnection recall / precision / false reconnections
# --------------------------------------------------------------------------- #
def fig6_reconnections():
    rows = [r for r in R.TABLE4 if r["precision"] is not None]
    labels = [f"{r['variant']}\n({r['region']})" for r in rows]
    fig, axes = plt.subplots(1, 3, figsize=(15, 5.5), facecolor=PAGE)
    x = np.arange(len(rows))
    colors = [OURS_COLOR if r["variant"] == "EviTopo-GNN" else BASELINE_COLOR for r in rows]

    panels = [("recall", "Recall (of introduced gaps)", axes[0]),
              ("precision", "Bridging precision", axes[1]),
              ("false_per_image", "False reconnections / image", axes[2])]
    for key, title, ax in panels:
        vals = [r[key] for r in rows]
        ax.bar(x, vals, color=colors, zorder=3, width=0.6)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, fontsize=7.5, color=INK_SECONDARY, rotation=20, ha="right")
        ax.set_title(title, fontsize=11, color=INK_PRIMARY)
        style_axes(ax)

    fig.suptitle("Fig. 6 — Table 4: controlled gap test, DRIVE (full model vs. geodesic gap edges, A4c)",
                 fontsize=13, color=INK_PRIMARY)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.savefig(FIG_DIR / "fig6_reconnections.png", dpi=DPI, facecolor=PAGE)
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Fig. 7a/b: Table 5 -- ablation progression
# --------------------------------------------------------------------------- #
def fig7_ablation():
    main_sequence_ids = ["A1", "A2", "A3", "A4a", "A4", "A5", "A6", "A7", "A8", "A9"]
    rows = {r["id"]: r for r in R.TABLE5}
    seq = [rows[i] for i in main_sequence_ids]
    x = np.arange(len(seq))

    fig, ax = plt.subplots(figsize=(10, 5.5), facecolor=PAGE)
    f1 = [r["drive_f1"] for r in seq]
    cld = [r["drive_cldice"] for r in seq]
    ax.plot(x, f1, "-o", color=CAT["blue"], label="DRIVE F1", lw=2, markersize=6, zorder=3)
    ax.plot(x, cld, "-o", color=CAT["orange"], label="DRIVE clDice", lw=2, markersize=6, zorder=3)
    ax.set_xticks(x)
    ax.set_xticklabels(main_sequence_ids, fontsize=9.5, color=INK_SECONDARY)
    ax.set_ylabel("Score", fontsize=10, color=INK_SECONDARY)
    ax.legend(frameon=False, fontsize=10)
    style_axes(ax)
    ax.grid(axis="y", color=GRIDLINE, linewidth=0.8)
    ax.set_title("Fig. 7a — Table 5: overlap/connectivity gains along the ablation sequence\n"
                 "(A1 encoder-only -> A9 full model)", fontsize=12, color=INK_PRIMARY)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig7a_ablation_overlap.png", dpi=DPI, facecolor=PAGE)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5.5), facecolor=PAGE)
    betti = [r["drive_betti0"] for r in seq]
    ece = [r["drive_ece"] for r in seq]
    ax.plot(x, betti, "-o", color=CAT["aqua"], label="DRIVE Betti-0 error", lw=2, markersize=6, zorder=3)
    ax.plot(x, ece, "-o", color=CAT["red"], label="DRIVE ECE", lw=2, markersize=6, zorder=3)
    ax.set_xticks(x)
    ax.set_xticklabels(main_sequence_ids, fontsize=9.5, color=INK_SECONDARY)
    ax.set_ylabel("Error (lower is better)", fontsize=10, color=INK_SECONDARY)
    ax.legend(frameon=False, fontsize=10)
    style_axes(ax)
    ax.grid(axis="y", color=GRIDLINE, linewidth=0.8)
    ax.set_title("Fig. 7b — Table 5: topology and calibration error along the ablation sequence",
                 fontsize=12, color=INK_PRIMARY)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig7b_ablation_topology.png", dpi=DPI, facecolor=PAGE)
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Fig. 8: Section 6.3 -- per-tile latency breakdown (stacked bar)
# --------------------------------------------------------------------------- #
def fig8_latency():
    fig, ax = plt.subplots(figsize=(7, 5.5), facecolor=PAGE)
    components = list(R.TILE_LATENCY_MS.keys())
    values = list(R.TILE_LATENCY_MS.values())
    colors = [CAT[c] for c in CAT_ORDER[: len(components)]]

    bottom = 0.0
    for comp, val, color in zip(components, values, colors):
        ax.bar([0], [val], bottom=[bottom], color=color, width=0.5, zorder=3,
               edgecolor=PAGE, linewidth=2, label=f"{comp} ({val:.1f} ms)")
        bottom += val

    ax.set_xlim(-0.6, 1.4)
    ax.set_xticks([0])
    ax.set_xticklabels(["512×512 tile, batch 1\n(RTX A6000)"], fontsize=9.5, color=INK_SECONDARY)
    ax.set_ylabel("Latency (ms)", fontsize=10, color=INK_SECONDARY)
    ax.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), frameon=False, fontsize=9)
    style_axes(ax)
    ax.grid(axis="x", visible=False)
    ax.set_title(f"Fig. 8 — Section 6.3: per-stage tile latency\n(sums to {sum(values):.1f} ms)",
                 fontsize=12, color=INK_PRIMARY)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig8_latency_breakdown.png", dpi=DPI, facecolor=PAGE, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    fig1_pipeline()
    fig2_table1()
    fig3_betti0_slope()
    fig4_forest()
    fig5_uncertainty()
    fig6_reconnections()
    fig7_ablation()
    fig8_latency()
    print(f"Wrote figures to {FIG_DIR}")
