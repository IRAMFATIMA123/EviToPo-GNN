#!/usr/bin/env python3
"""CLI entry point for training EviTopo-GNN on one dataset (Section 3.9).

    python scripts/train.py --config configs/drive.yaml --seed 0 \\
        --output runs/drive_seed0

Expects the dataset to already sit under ``<dataset.root>/<dataset.name>/``
in the layout documented in ``evitopo_gnn/data/datasets.py`` (this script
does not download data). See the top-level README's "Reproducing the
paper's tables and figures" section for the full, honest list of what
re-running real training would additionally require (compute, the
RETFound checkpoint, several days per dataset/seed).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import torch  # noqa: E402
from torch.utils.data import DataLoader  # noqa: E402

from evitopo_gnn.utils.config import load_config  # noqa: E402
from evitopo_gnn.utils.seed import set_seed  # noqa: E402
from evitopo_gnn.utils.checkpoint import save_checkpoint  # noqa: E402
from evitopo_gnn.models.hybrid_encoder import ViTConfig  # noqa: E402
from evitopo_gnn.models.evitopo_gnn import EviTopoGNN  # noqa: E402
from evitopo_gnn.engine.trainer import Trainer, TrainerConfig  # noqa: E402
from evitopo_gnn.engine.evaluator import Evaluator, aggregate_pooled_over_seeds  # noqa: E402
from evitopo_gnn.losses.combined_objective import StageSchedule  # noqa: E402
from evitopo_gnn.data.datasets import RetinalVesselDataset  # noqa: E402
from evitopo_gnn.data.transforms import TrainAugmentation, EvalTransform  # noqa: E402
from evitopo_gnn.data.splits import (  # noqa: E402
    fixed_train_val_test_split, leave_one_out_folds, k_fold_subject_disjoint, chase_db1_child_split,
)


def build_model(cfg: dict) -> EviTopoGNN:
    m = cfg["model"]
    vit_cfg = ViTConfig(**m["vit"])
    return EviTopoGNN(
        vit_cfg=vit_cfg,
        cnn_base_ch=m["encoder"]["cnn_base_ch"],
        fused_ch=m["encoder"]["fused_ch"],
        window=m["encoder"]["window"],
        decoded_feat_ch=m["decoded_feat_ch"],
        graph_node_spacing=m["graph"]["node_spacing"],
        graph_min_spur_len=m["graph"]["min_spur_len"],
        graph_gap_radius=m["graph"]["gap_radius"],
        graph_k_gap=m["graph"]["k_gap"],
        graph_tau_u=m["graph"]["tau_u"],
        graph_tau_c=m["graph"]["tau_c"],
        gnn_edge_dim=m["gnn"]["edge_dim"],
        gnn_hidden_dim=m["gnn"]["hidden_dim"],
        gnn_num_layers=m["gnn"]["num_layers"],
        gnn_gate_exponent=m["gnn"]["gate_exponent"],
        link_hidden_dim=m["link"]["hidden_dim"],
        decoder_channels=m["decoder"]["channels"],
        contrastive_proj_dim=m["contrastive"]["proj_dim"],
        tau_link=m["link"]["tau_link"],
    )


def build_split(cfg: dict):
    d = cfg["dataset"]
    root = d["root"]
    all_stems = [p.stem for p in (Path(root) / d["name"] / "images").glob("*.*")]
    if d["split"] == "fixed":
        return fixed_train_val_test_split(all_stems, d.get("val_frac", 0.1), d.get("test_frac", 0.2), d.get("seed", 0))
    if d["split"] == "leave_one_out":
        folds = leave_one_out_folds(all_stems, d.get("n_val", 2), d.get("seed", 0))
        return folds[0]  # caller loops folds externally for the full protocol
    if d["split"] == "k_fold_subject_disjoint":
        folds = k_fold_subject_disjoint(all_stems, d["k"], d.get("n_val_subjects", 1), d.get("seed", 0))
        return folds[0]
    if d["split"] == "chase_child":
        raise NotImplementedError("Populate configs/chase_db1.yaml's val_children/test_children first.")
    raise ValueError(f"Unknown split type: {d['split']}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output", default="runs/exp")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--epochs", type=int, default=None, help="Override schedule.full_end for a quick run")
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_seed(args.seed)

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "config.resolved.json").write_text(json.dumps(cfg, indent=2))

    model = build_model(cfg).to(args.device)

    split = build_split(cfg)
    train_ds = RetinalVesselDataset(cfg["dataset"]["root"], cfg["dataset"]["name"], split.train,
                                     transform=TrainAugmentation(patch_size=cfg["data"]["patch_size"], seed=args.seed))
    val_ds = RetinalVesselDataset(cfg["dataset"]["root"], cfg["dataset"]["name"], split.val, transform=EvalTransform())

    train_loader = DataLoader(train_ds, batch_size=cfg["data"]["batch_size"], shuffle=True, num_workers=2)

    schedule = StageSchedule(**cfg["schedule"])
    total_epochs = args.epochs or schedule.full_end
    trainer_cfg = TrainerConfig(
        total_epochs=total_epochs, base_lr=cfg["optim"]["base_lr"], weight_decay=cfg["optim"]["weight_decay"],
        tau_link=cfg["model"]["link"]["tau_link"], link_positive_weight=cfg["loss"]["link_positive_weight"],
        grad_clip_norm=cfg["optim"]["grad_clip_norm"], schedule=schedule,
    )
    trainer = Trainer(model, trainer_cfg, device=args.device)
    evaluator = Evaluator(model, device=args.device, window=cfg["inference"]["window"],
                           stride=cfg["inference"]["stride"], threshold=cfg["inference"]["threshold"])

    best_score = -1.0
    for epoch in range(1, total_epochs + 1):
        stats = trainer.train_one_epoch(train_loader, epoch)
        print(f"[epoch {epoch}/{total_epochs}] stage={stats['stage']} loss={stats['mean_total_loss']:.4f}")

        if epoch % 10 == 0 or epoch == total_epochs:
            results = evaluator.evaluate_dataset(val_ds)
            agg = aggregate_pooled_over_seeds([results])
            score = 0.5 * (agg["f1_mean"] + agg["cldice_mean"])  # Section 3.9 checkpoint rule
            print(f"  val F1={agg['f1_mean']:.4f} clDice={agg['cldice_mean']:.4f} score={score:.4f}")
            if score > best_score:
                best_score = score
                save_checkpoint(str(out_dir / "best.pt"), model, trainer.optimizer, epoch, {"val_score": score})

        save_checkpoint(str(out_dir / "last.pt"), model, trainer.optimizer, epoch, {})

    print(f"Done. Best validation score: {best_score:.4f}. Checkpoints in {out_dir}")


if __name__ == "__main__":
    main()
