# Table 5. Component ablation on DRIVE and FIVES

Mean over five seeds; each row changes one factor relative to the row it names (A9 is the full model). C1/C2: augmentation controls on DRIVE only ('-' not run).

| ID | Variant (one factor changed) | DRIVE F1 | DRIVE clDice | DRIVE Betti-0 | DRIVE ECE | FIVES F1 | FIVES clDice |
|---|---|---|---|---|---|---|---|
| A1 | ViT+CNN encoder, softmax head | 0.8138 | 0.7601 | 0.432 | 0.0749 | 0.8596 | 0.8016 |
| A2 | A1 + evidential head | 0.8183 | 0.7700 | 0.398 | 0.0673 | 0.8643 | 0.8120 |
| A2p | A2 + conv blocks, capacity-matched | 0.8192 | 0.7720 | 0.391 | 0.0658 | 0.8653 | 0.8141 |
| A3 | A2 + graph, observed edges only | 0.8247 | 0.7840 | 0.349 | 0.0566 | 0.8712 | 0.8271 |
| A3a | A3 with kNN feature graph | 0.8215 | 0.7770 | 0.374 | 0.0619 | 0.8677 | 0.8194 |
| A3b | A3 with local pixel propagation | 0.8205 | 0.7749 | 0.381 | 0.0636 | 0.8667 | 0.8172 |
| A4a | A3 + gap edges, no link loss, gate=1 | 0.8283 | 0.7919 | 0.322 | 0.0505 | 0.8748 | 0.8349 |
| A4 | A4a + link loss | 0.8320 | 0.8002 | 0.294 | 0.0442 | 0.8789 | 0.8438 |
| A4c | A4 with geodesic (VGN-style) gap edges | 0.8296 | 0.7948 | 0.312 | 0.0483 | 0.8763 | 0.8382 |
| A5a | A4 + uncertainty term of gate only | 0.8356 | 0.8080 | 0.266 | 0.0382 | 0.8827 | 0.8522 |
| A5b | A4 + edge term of gate only | 0.8340 | 0.8046 | 0.278 | 0.0408 | 0.8810 | 0.8484 |
| A5 | A4 + full gate | 0.8394 | 0.8164 | 0.237 | 0.0317 | 0.8868 | 0.8611 |
| A6 | A5 without synthetic gaps | 0.8367 | 0.8105 | 0.258 | 0.0363 | 0.8836 | 0.8543 |
| A7 | A5 + vessel-vs-background contrast | 0.8405 | 0.8189 | 0.229 | 0.0298 | 0.8879 | 0.8637 |
| A8 | A5 + topology contrast, uniform anchors | 0.8428 | 0.8239 | 0.211 | 0.0260 | 0.8904 | 0.8690 |
| **A9** | **A8 + uncertainty anchors (full model)** | **0.8459** | **0.8307** | **0.188** | **0.0208** | **0.8936** | **0.8761** |
| A10 | A9, ViT-B/16 (ImageNet) encoder | 0.8418 | 0.8217 | 0.219 | 0.0277 | 0.8893 | 0.8668 |
| A11 | A9 with KAN node update | 0.8455 | 0.8298 | 0.191 | 0.0215 | 0.8931 | 0.8750 |
| A12 | A9 without ViT branch (CNN only) | 0.8362 | 0.8094 | 0.262 | 0.0371 | 0.8833 | 0.8534 |
| A13 | A9 without full-resolution CNN branch | 0.8102 | 0.7521 | 0.459 | 0.0810 | 0.8558 | 0.7932 |
| C1 | U-Net + synthetic gaps (control) | 0.8165 | 0.7641 | - | - | - | - |
| C2 | Serp-Mamba + synthetic gaps (control) | 0.8338 | 0.8077 | - | - | - | - |
| A9g | A9, uncertainty term of gate replaced by a constant | 0.8411 | 0.8209 | 0.219 | 0.0269 | 0.8895 | 0.8676 |
