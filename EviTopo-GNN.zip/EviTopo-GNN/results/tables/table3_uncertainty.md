# Table 3. Uncertainty quality on DRIVE (test images only)

Calibration of the probability (ECE pooled, ECE on ground-truth vessel pixels, ECE on the 3 px edge band; Brier; NLL) and ranking quality of the uncertainty (AUROC-err; AURC), against MC dropout and a deep ensemble sharing the complete pipeline.

| Method | ECE pooled | ECE vessel | ECE edge band | Brier | NLL | AUROC-err | AURC |
|---|---|---|---|---|---|---|---|
| MC-Dropout | 0.0603 | 0.1306 | 0.1583 | 0.0352 | 0.1291 | 0.846 | 0.0135 |
| Deep Ensemble | 0.0437 | 0.0998 | 0.0834 | 0.0327 | 0.1118 | 0.874 | 0.0113 |
| EviTopo-GNN (ours) | 0.0208 | 0.0580 | 0.0861 | 0.0294 | 0.0937 | 0.908 | 0.0086 |
