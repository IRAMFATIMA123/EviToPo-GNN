# Table 2. Paired comparison with the strongest baseline

Delta: mean paired per-unit difference (EviTopo-GNN minus comparator); 95% CI from a paired bootstrap over test units (10,000 resamples); p: Holm-adjusted paired Wilcoxon signed-rank. Units are images, or children on CHASE_DB1 (descriptive only).

| Dataset (units), comparator | ΔF1 [95% CI] | p | ΔclDice [95% CI] | p | ΔECE [95% CI] | p | ECE comp.→ours | Betti-0 comp.→ours |
|---|---|---|---|---|---|---|---|---|
| DRIVE (20 images) Serp-Mamba | +0.0131 [-0.0026, +0.0300] | 0.359 | +0.0268 [+0.0173, +0.0364] | < 0.001 | -0.0306 [-0.0367, -0.0242] | < 0.001 | 0.0514 → 0.0208 | 0.268 → 0.188 |
| STARE (20 images) Serp-Mamba | +0.0155 [+0.0024, +0.0304] | 0.064 | +0.0337 [+0.0211, +0.0444] | < 0.001 | -0.0313 [-0.0366, -0.0261] | < 0.001 | 0.0537 → 0.0224 | 0.290 → 0.205 |
| CHASE (4 children) Serp-Mamba | +0.0191 [+0.0124, +0.0336] | 1.000 | +0.0391 [+0.0250, +0.0489] | 1.000 | -0.0375 [-0.0440, -0.0295] | 1.000 | 0.0616 → 0.0241 | 0.354 → 0.231 |
| HRF (45 images) DSCNet | +0.0043 [-0.0023, +0.0119] | 0.417 | +0.0229 [+0.0161, +0.0300] | < 0.001 | -0.0503 [-0.0536, -0.0471] | < 0.001 | 0.0766 → 0.0263 | 0.355 → 0.258 |
| FIVES (200 images) Serp-Mamba | +0.0075 [+0.0044, +0.0111] | < 0.001 | +0.0216 [+0.0189, +0.0244] | < 0.001 | -0.0222 [-0.0237, -0.0207] | < 0.001 | 0.0398 → 0.0176 | 0.184 → 0.142 |
