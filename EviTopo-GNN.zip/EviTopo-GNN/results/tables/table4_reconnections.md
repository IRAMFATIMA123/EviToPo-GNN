# Table 4. Correct and false reconnections in the controlled gap test (DRIVE)

Recall denominator: gaps introduced. Bridging precision: correct reconnections / reconnections made. A false reconnection joins endpoints in different ground-truth components or follows a path > 2 px from the degraded centreline.

| Variant | Region | Gaps | Recall | Bridging precision | False reconnections / image | clDice from bad bridges |
|---|---|---|---|---|---|---|
| EviTopo-GNN | All | 560 | 0.641 | 0.893 | 0.42 | 0.0021 |
| EviTopo-GNN | Crossing / bifurcation | 173 | 0.572 | 0.807 | 0.26 | 0.0014 |
| A4c geodesic gap edges | All | 560 | 0.487 | 0.742 | 0.91 | 0.0058 |
| A4c geodesic gap edges | Crossing / bifurcation | 173 | 0.402 | 0.613 | 0.58 | 0.0039 |
| A3 no gap edges | All | 560 | 0.286 | n/a | n/a | n/a |
